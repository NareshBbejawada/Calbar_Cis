# SQL Drive Capacity Report — SQL Server Database Mail edition

This is a separate variant of Send-SQLDriveCapacityReport.ps1. It preserves the
existing drive collection, thresholds, CSV export, and table colors. It replaces
PowerShell-to-SMTP delivery with a parameterized call to msdb.dbo.sp_send_dbmail.

Use ONE SQL instance with an existing, working Database Mail profile. It is not
necessary to configure Database Mail on every monitored SQL server. Simply
running the old SMTP script on a SQL host will not make it use Database Mail.

## Files

- Send-SQLDriveCapacityReport-DatabaseMail.ps1 — full reporting script.
- servers.example.txt — example only; preserve your existing servers.txt.
- Check-DatabaseMail.sql — read-only profile, status, and error checks.
- VALIDATION.txt — precisely what was and was not validated here.

## 1. Place the files

Use Windows PowerShell 5.1 (powershell.exe). Place the new .ps1 and your existing
servers.txt in D:\DBA\DriveSpaceReport on the execution server. The new filename
avoids overwriting your original script. No SqlServer/SQLPS module installation
is required; the sender uses the .NET Framework System.Data.SqlClient provider.

Running on the Windows host that owns the mail-enabled SQL instance is simplest,
especially when attaching CSV files. HTML-only sending also supports a remote
mail-enabled instance. The SQL instance must be reachable from the execution
server, and the execution identity must have SQL login/msdb/mail permissions.

The existing remote CIM/WMI permissions and connectivity are still required to
collect drives from the servers in servers.txt. Moving the script to a different
host does not automatically transfer those permissions or firewall approvals.

## 2. Identify the profile

Connect SSMS to the exact mail-enabled SQL instance and run:

```sql
EXEC msdb.dbo.sysmail_help_profile_sp;
```

Use the returned profile name, NOT the Database Mail account name or SQL Agent
operator name. If multiple profiles exist, use the approved working profile.

## 3. Configure the new script

Edit these entries in the existing $Config block; keep the other settings:

```powershell
MailSqlInstance = 'SQLMAIL01.yourcompany.com\DBAPPS1'
MailProfileName = 'DBA_Mail_Profile'
MailTo          = @('DBA-Team@yourcompany.com')
MailCc          = @()
AttachCsvFiles  = $false
```

Replace the example SQL instance, profile, and recipient with your real values.
For a default instance, omit \DBAPPS1. For a fixed TCP port, a data source can be
specified as 'tcp:SQLMAIL01.yourcompany.com,49285' using your actual port.
Use the SQL host name covered by its trusted certificate.

No SMTP hostname, SMTP password, MailFrom, EnableSsl, or
UseDefaultSmtpCredentials setting is used in this edition. The existing Database
Mail profile/account supplies the sender, SMTP configuration, and mail security.
Do not pass the old -SmtpCredential parameter; this version does not have it.

The Windows account running PowerShell authenticates to the mail SQL instance.
-CimCredential, when supplied, applies ONLY to remote drive collection, not SQL
or Database Mail. No SQL password is stored or requested by this implementation.

SQL connections explicitly use Encrypt=True and TrustServerCertificate=False.
If SQL connection certificate validation fails, verify the SQL endpoint name,
server certificate, and CA chain. Do not disable certificate validation or weaken
SMTP settings as a workaround. SMTP and SQL connection errors are distinct.

## 4. Syntax-only check (no scan, no SQL call, no email)

Run on your Windows server:

```powershell
$path = 'D:\DBA\DriveSpaceReport\Send-SQLDriveCapacityReport-DatabaseMail.ps1'
$tokens = $null
$parseErrors = $null
[void][System.Management.Automation.Language.Parser]::ParseFile(
    $path, [ref]$tokens, [ref]$parseErrors
)
if (@($parseErrors).Count -gt 0) {
    $parseErrors | Format-List Message, Extent
    throw 'PowerShell syntax check failed.'
}
'Syntax check passed.'
```

## 5. Test email without rescanning the servers

Temporarily set MailTo to your own mailbox, and run under the SAME Windows
identity intended for the scheduled task/job:

```powershell
Set-Location 'D:\DBA\DriveSpaceReport'
.\Send-SQLDriveCapacityReport-DatabaseMail.ps1 -TestEmailOnly
```

This sends ONE HTML test email. It does not read servers.txt or collect drives.
It does not test CSV attachments, even if AttachCsvFiles is enabled.
Do not combine -TestEmailOnly with -NoEmail, -OnlySendOnAlert, or -OpenReport.

The script logs QUEUED plus the mailitem_id. It saves Run.log,
DatabaseMailSubmission.json, and CheckMailStatus.sql in a new timestamped Reports
folder. A successful procedure call means queued, not confirmed delivery.
Confirm receipt and then change MailTo to the DBA team.

## 6. Run the full report

```powershell
# Collect and submit a report on every run.
.\Send-SQLDriveCapacityReport-DatabaseMail.ps1

# Submit only for below-threshold drives OR collection problems.
.\Send-SQLDriveCapacityReport-DatabaseMail.ps1 -OnlySendOnAlert

# Collect and preview locally without any SQL mail connection.
.\Send-SQLDriveCapacityReport-DatabaseMail.ps1 -NoEmail -OpenReport

# Optional existing collection setting, if DCOM is your approved transport.
.\Send-SQLDriveCapacityReport-DatabaseMail.ps1 -ConnectionProtocol DCOM
```

The alert threshold remains strictly below 20% free; below 10% is critical.
Unknown measurements and failed collections are not treated as healthy.
Unresolved conditions are emailed again on later runs; there is no suppression.

The local report folder contains DriveCapacityReport.html, AllDrives.csv,
ActionRequired.csv, CollectionIssues.csv, ServerCoverage.csv, and Run.log.
After a successful mail submission it also contains a submission receipt and
CheckMailStatus.sql for that exact mailitem_id.

HTML email includes ALL rows by default (MaxInlineRowsPerSection = 0). A positive
cap can be configured to reduce message size; every capped section is labeled.
Local HTML and CSV are complete. Your mail infrastructure's message-size limits
still apply. Plan approved retention for local output and Database Mail history;
the script never deletes either. Database Mail stores message content in msdb.

## 7. Optional CSV email attachments

After HTML-only email works, enable:

```powershell
AttachCsvFiles = $true
```

This implementation deliberately supports attachment files only when the script
runs on the Windows host currently running the mail SQL instance. It verifies
SERVERPROPERTY('ComputerNamePhysicalNetBIOS') before passing file paths to SQL.
It accepts only local, absolute drive-letter file paths, not UNC shares. This
avoids interpreting a collector's D:\ path as a different server's D:\ path.

Ensure the SQL Database Engine service account has read access to the report
folder/files. Also use a Windows execution account with appropriate local file
and SQL permissions. Grant only required access; the script changes no ACLs.
Database Mail's default limit is 1 MB per attachment; existing configured size
and prohibited-extension limits also apply. This script does not increase them.

All four CSV files are attached when enabled. A rejected attachment fails the
submission; the script does not silently drop it and send a partial package.
Files stay available locally even if email submission fails.

HTML-only mode avoids attachment path/ACL issues because PowerShell sends the
HTML string as a SQL parameter rather than asking SQL to read an HTML file.

## 8. Permissions — review with the SQL/security owner

A non-sysadmin execution identity requires an appropriate SQL login, an msdb
user, membership in msdb's DatabaseMailUserRole, and permission to the selected
mail profile. Do not grant sysadmin merely to send this report, and do not make a
private profile public just to resolve a permission error.

For a NEW dedicated domain account, the following is an example for an authorized
DBA to review and run ONCE. Omit CREATE statements for objects that already exist.
This changes permissions and is NOT executed by the reporting script. The last
statement makes the selected profile the default for this account only; review
existing default-profile associations before using it for an existing identity.

```sql
USE master;
CREATE LOGIN [YOURDOMAIN\svc_DBAReports] FROM WINDOWS;
GO
USE msdb;
CREATE USER [YOURDOMAIN\svc_DBAReports]
    FOR LOGIN [YOURDOMAIN\svc_DBAReports];
ALTER ROLE DatabaseMailUserRole ADD MEMBER [YOURDOMAIN\svc_DBAReports];
EXEC dbo.sysmail_add_principalprofile_sp
    @principal_name = N'YOURDOMAIN\svc_DBAReports',
    @profile_name = N'DBA_Mail_Profile',
    @is_default = 1;
GO
```

## 9. Schedule with SQL Server Agent

Create a job step with type Operating system (CmdExec), using an approved CmdExec
proxy identity with both remote collection and SQL mail permissions. Without a
proxy, CmdExec normally runs under the SQL Server Agent service account. A test
under your interactive account does not prove the scheduled identity can run it.

Command (one line):

```text
C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -NoProfile -NonInteractive -File "D:\DBA\DriveSpaceReport\Send-SQLDriveCapacityReport-DatabaseMail.ps1" -OnlySendOnAlert
```

Set success exit code to 0. Exit 1 = configuration/report/mail submission failure;
exit 2 = collection completed with partial/failed coverage. Low space alone does
not cause nonzero exit. Keep automatic job-step retries at 0 to avoid duplicate
emails after an uncertain submission. Measure scan duration before choosing a
schedule (for example, every 30 minutes); collection is sequential.

The script calls sp_send_dbmail directly. It does not need xp_cmdshell, SQL Agent
operator notifications, or SQL/Agent service restarts to send its report.
Task Scheduler can also run the same executable and arguments.

## 10. Troubleshooting

Open CheckMailStatus.sql from the run folder in SSMS connected to MailSqlInstance.
Use Check-DatabaseMail.sql for broader read-only checks.

- Login failed / execute denied: check the Windows execution identity, SQL login,
  msdb mapping, DatabaseMailUserRole, and profile permission.
- Profile name not valid: verify both the exact profile/instance and profile access.
- SQL certificate or connection SSPI failure: this is the PowerShell-to-SQL
  connection, not PowerShell-to-SMTP. Check the trusted SQL certificate, DNS/SPNs,
  authentication, connectivity, and full nested exception in Run.log as applicable.
- File inaccessible: leave attachments off until verified on the mail SQL host.
- Unsent/retrying/failed: use the exact mailitem_id to inspect Database Mail history
  and errors. No automatic queue restarts, deletions, or configuration changes.
- Sent but not received: Database Mail handed the message to SMTP; investigate
  transport logs, recipient restrictions, quarantine, and mailbox delivery.
- A SQL call times out: check mail history before rerunning; it may already be queued.

## Validation and safety

This edition was statically reviewed. Automated text comparisons verified that
the original collection/calculation/CSV functions and colored table renderers
were preserved. A Windows PowerShell runtime and your SQL/SMTP environment were
not available for execution testing here. Run the syntax check, email-only test,
and a small-server pilot before scheduling. No production validation is claimed.

Collection is read-only. Expected writes are local report/log files and Database
Mail's msdb queue/history. No monitored-server configuration changes, cleanup,
service restarts, or reboots are performed. Profile/security setup examples are
manual and separate from script execution.

## Microsoft references

- sp_send_dbmail (HTML, parameters, attachments, permissions):
  https://learn.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sp-send-dbmail-transact-sql
- Database Mail overview and service-account file access:
  https://learn.microsoft.com/en-us/sql/relational-databases/database-mail/database-mail
- List existing profiles:
  https://learn.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sysmail-help-profile-sp-transact-sql
- Grant profile access:
  https://learn.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sysmail-add-principalprofile-sp-transact-sql
- Mail status and queue diagnostics:
  https://learn.microsoft.com/en-us/sql/relational-databases/database-mail/database-mail-mail-queued-not-delivered
- CmdExec job steps and execution identity:
  https://learn.microsoft.com/en-us/ssms/agent/create-a-cmdexec-job-step
