/* READ-ONLY checks. Connect to the exact mail-enabled SQL instance.
   Run as an authorized DBA to see all profiles/messages. A non-sysadmin
   DatabaseMailUserRole user normally sees only mail they submitted.
   This script changes no Database Mail/SQL settings and sends no email. */
USE msdb;
GO
SELECT @@SERVERNAME AS SqlInstance,
       SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS SqlPhysicalHost,
       ORIGINAL_LOGIN() AS OriginalLogin,
       SUSER_SNAME() AS CurrentLogin;
EXEC dbo.sysmail_help_profile_sp;
GO
SELECT TOP (20)
       mailitem_id, subject, recipients, sent_status,
       send_request_date, sent_date, send_request_user
FROM dbo.sysmail_allitems
WHERE subject LIKE N'%SQL Drive Capacity%'
   OR subject LIKE N'%DBA Drive Capacity%'
ORDER BY mailitem_id DESC;
GO
-- Replace NULL with the exact mailitem_id printed by the script to filter.
DECLARE @MailItemId int = NULL;
SELECT TOP (50) log_date, event_type, mailitem_id, description
FROM dbo.sysmail_event_log
WHERE @MailItemId IS NULL OR mailitem_id = @MailItemId
ORDER BY log_id DESC;
GO
-- sent = submitted to SMTP, not proof of final mailbox delivery.
-- unsent/retrying/failed = inspect the errors above and transport health.
