USE CALBAR_SQL_CIS;
GO

/*
CAL Bar audit-only control catalog.
Every CheckQuery returns exactly one row and one column named ActualValue.
CheckType values supported by the CAL Bar runner:
  EQUALS, SET, MINIMUM, MAXIMUM
*/

MERGE cfg.CIS_Control_Definition AS target
USING
(
    VALUES
    /* Surface-area configuration */
    ('CALBAR-2.01','xp_cmdshell is disabled',
     'Reduces command-shell attack surface.','0','EQUALS',
     N'SELECT CAST(COALESCE(MAX(CONVERT(int,value_in_use)),-1) AS nvarchar(100)) AS ActualValue FROM sys.configurations WHERE name = ''xp_cmdshell'';',
     NULL,10,'Surface Area','High',0,NULL),

    ('CALBAR-2.02','CLR integration is disabled',
     'Prevents unmanaged or unapproved CLR execution unless explicitly required.','0','EQUALS',
     N'SELECT CAST(COALESCE(MAX(CONVERT(int,value_in_use)),-1) AS nvarchar(100)) AS ActualValue FROM sys.configurations WHERE name = ''clr enabled'';',
     NULL,20,'Surface Area','High',0,NULL),

    ('CALBAR-2.03','OLE Automation Procedures are disabled',
     'Reduces COM automation attack surface.','0','EQUALS',
     N'SELECT CAST(COALESCE(MAX(CONVERT(int,value_in_use)),-1) AS nvarchar(100)) AS ActualValue FROM sys.configurations WHERE name = ''Ole Automation Procedures'';',
     NULL,30,'Surface Area','High',0,NULL),

    ('CALBAR-2.04','Ad Hoc Distributed Queries are disabled',
     'Prevents unapproved OPENROWSET and OPENDATASOURCE usage.','0','EQUALS',
     N'SELECT CAST(COALESCE(MAX(CONVERT(int,value_in_use)),-1) AS nvarchar(100)) AS ActualValue FROM sys.configurations WHERE name = ''Ad Hoc Distributed Queries'';',
     NULL,40,'Surface Area','High',0,NULL),

    ('CALBAR-2.05','Remote access is disabled',
     'Disables legacy remote stored procedure access.','0','EQUALS',
     N'SELECT CAST(COALESCE(MAX(CONVERT(int,value_in_use)),-1) AS nvarchar(100)) AS ActualValue FROM sys.configurations WHERE name = ''remote access'';',
     NULL,50,'Surface Area','Medium',0,NULL),

    ('CALBAR-2.06','Remote admin connections are disabled',
     'Prevents remote DAC unless explicitly approved.','0','EQUALS',
     N'SELECT CAST(COALESCE(MAX(CONVERT(int,value_in_use)),-1) AS nvarchar(100)) AS ActualValue FROM sys.configurations WHERE name = ''remote admin connections'';',
     NULL,60,'Surface Area','Medium',0,NULL),

    ('CALBAR-2.07','Scan for startup procedures is disabled',
     'Prevents automatic execution of startup procedures.','0','EQUALS',
     N'SELECT CAST(COALESCE(MAX(CONVERT(int,value_in_use)),-1) AS nvarchar(100)) AS ActualValue FROM sys.configurations WHERE name = ''scan for startup procs'';',
     NULL,70,'Surface Area','High',0,NULL),

    ('CALBAR-2.08','Cross database ownership chaining is disabled',
     'Prevents instance-wide cross-database ownership chaining.','0','EQUALS',
     N'SELECT CAST(COALESCE(MAX(CONVERT(int,value_in_use)),-1) AS nvarchar(100)) AS ActualValue FROM sys.configurations WHERE name = ''cross db ownership chaining'';',
     NULL,80,'Surface Area','High',0,NULL),

    ('CALBAR-2.09','CLR strict security is enabled',
     'Treats SAFE and EXTERNAL_ACCESS assemblies as UNSAFE unless trusted.','1','EQUALS',
     N'SELECT CAST(COALESCE(MAX(CONVERT(int,value_in_use)),-1) AS nvarchar(100)) AS ActualValue FROM sys.configurations WHERE name = ''clr strict security'';',
     14,90,'Surface Area','High',0,'Applies to SQL Server 2017 and later.'),

    ('CALBAR-2.10','External scripts are disabled',
     'Disables SQL Server external scripting unless approved.','0','EQUALS',
     N'SELECT CAST(COALESCE(MAX(CONVERT(int,value_in_use)),-1) AS nvarchar(100)) AS ActualValue FROM sys.configurations WHERE name = ''external scripts enabled'';',
     13,100,'Surface Area','High',0,'Applies to SQL Server 2016 and later.'),

    ('CALBAR-2.11','Contained database authentication is disabled',
     'Disables contained authentication unless required by an approved application.','0','EQUALS',
     N'SELECT CAST(COALESCE(MAX(CONVERT(int,value_in_use)),-1) AS nvarchar(100)) AS ActualValue FROM sys.configurations WHERE name = ''contained database authentication'';',
     11,110,'Surface Area','Medium',0,NULL),

    ('CALBAR-2.12','Common Criteria compliance is disabled',
     'Common Criteria mode should remain off unless specifically required because it changes behavior.','0','EQUALS',
     N'SELECT CAST(COALESCE(MAX(CONVERT(int,value_in_use)),-1) AS nvarchar(100)) AS ActualValue FROM sys.configurations WHERE name = ''common criteria compliance enabled'';',
     NULL,120,'Surface Area','Medium',0,NULL),

    /* Auditing and logging */
    ('CALBAR-5.01','Default trace is enabled',
     'Retains basic configuration and security-change trace information.','1','EQUALS',
     N'SELECT CAST(COALESCE(MAX(CONVERT(int,value_in_use)),-1) AS nvarchar(100)) AS ActualValue FROM sys.configurations WHERE name = ''default trace enabled'';',
     NULL,130,'Auditing','Medium',0,NULL),

    ('CALBAR-5.02','Login auditing captures failed logins',
     'Audit level must be Failed logins or Both failed and successful logins.','2,3','SET',
     N'DECLARE @v int = NULL; EXEC master.sys.xp_instance_regread N''HKEY_LOCAL_MACHINE'',N''Software\Microsoft\MSSQLServer\MSSQLServer'',N''AuditLevel'',@v OUTPUT; SELECT CAST(COALESCE(@v,-1) AS nvarchar(100)) AS ActualValue;',
     NULL,140,'Auditing','High',0,'2 = failed logins; 3 = failed and successful logins.'),

    ('CALBAR-5.03','At least 20 SQL error logs are retained',
     'Retains sufficient SQL error-log history for investigation.','20','MINIMUM',
     N'DECLARE @v int = NULL; EXEC master.sys.xp_instance_regread N''HKEY_LOCAL_MACHINE'',N''Software\Microsoft\MSSQLServer\MSSQLServer'',N''NumErrorLogs'',@v OUTPUT; SELECT CAST(COALESCE(@v,6) AS nvarchar(100)) AS ActualValue;',
     NULL,150,'Auditing','Medium',0,NULL),

    /* Authentication and authorization */
    ('CALBAR-3.01','The built-in sa login is disabled',
     'The login with SID 0x01 must be disabled.','0','EQUALS',
     N'SELECT CAST(COUNT_BIG(*) AS nvarchar(100)) AS ActualValue FROM sys.server_principals WHERE sid = 0x01 AND is_disabled = 0;',
     NULL,160,'Authentication','Critical',0,NULL),

    ('CALBAR-3.02','The built-in sa login is renamed',
     'No login named sa should remain.','0','EQUALS',
     N'SELECT CAST(COUNT_BIG(*) AS nvarchar(100)) AS ActualValue FROM sys.server_principals WHERE name = N''sa'';',
     NULL,170,'Authentication','High',0,NULL),

    ('CALBAR-3.03','SQL logins enforce password policy',
     'All enabled SQL logins, excluding the SID 0x01 account, must have password policy enabled.','0','EQUALS',
     N'SELECT CAST(COUNT_BIG(*) AS nvarchar(100)) AS ActualValue FROM sys.sql_logins WHERE is_disabled = 0 AND sid <> 0x01 AND is_policy_checked = 0;',
     NULL,180,'Authentication','High',0,NULL),

    ('CALBAR-3.04','SQL logins enforce password expiration',
     'All enabled SQL logins, excluding the SID 0x01 account, must have password expiration enabled.','0','EQUALS',
     N'SELECT CAST(COUNT_BIG(*) AS nvarchar(100)) AS ActualValue FROM sys.sql_logins WHERE is_disabled = 0 AND sid <> 0x01 AND is_expiration_checked = 0;',
     NULL,190,'Authentication','Medium',0,'Disable this control if CAL Bar policy does not require SQL login password expiration.'),

    ('CALBAR-3.05','Public server role has no excessive grants',
     'The public server role should have no explicit server grants beyond baseline connectivity and metadata visibility.','0','EQUALS',
     N'SELECT CAST(COUNT_BIG(*) AS nvarchar(100)) AS ActualValue FROM sys.server_permissions p INNER JOIN sys.server_principals sp ON p.grantee_principal_id = sp.principal_id WHERE sp.name = N''public'' AND p.state_desc IN (''GRANT'',''GRANT_WITH_GRANT_OPTION'') AND p.permission_name NOT IN (''CONNECT SQL'',''VIEW ANY DATABASE'');',
     NULL,200,'Authorization','High',0,NULL),

    ('CALBAR-3.06','No unexpected members exist in msdb SQL Agent roles',
     'SQL Agent fixed database roles should not contain user-created members without review.','0','EQUALS',
     N'USE msdb; SELECT CAST(COUNT_BIG(*) AS nvarchar(100)) AS ActualValue FROM sys.database_role_members drm INNER JOIN sys.database_principals r ON drm.role_principal_id=r.principal_id INNER JOIN sys.database_principals m ON drm.member_principal_id=m.principal_id WHERE r.name IN (N''SQLAgentUserRole'',N''SQLAgentReaderRole'',N''SQLAgentOperatorRole'') AND m.name NOT IN (N''dbo'');',
     NULL,210,'Authorization','Medium',0,'Any returned membership should be reviewed and, when legitimate, documented as an exception.'),

    /* Database security */
    ('CALBAR-4.01','No unexpected TRUSTWORTHY user databases',
     'User databases must not have TRUSTWORTHY enabled.','0','EQUALS',
     N'SELECT CAST(COUNT_BIG(*) AS nvarchar(100)) AS ActualValue FROM sys.databases WHERE database_id > 4 AND state_desc = ''ONLINE'' AND is_trustworthy_on = 1;',
     NULL,220,'Database Security','Critical',0,NULL),

    ('CALBAR-4.02','No user databases have database chaining enabled',
     'Database-level cross-database ownership chaining must be disabled.','0','EQUALS',
     N'SELECT CAST(COUNT_BIG(*) AS nvarchar(100)) AS ActualValue FROM sys.databases WHERE database_id > 4 AND state_desc = ''ONLINE'' AND is_db_chaining_on = 1;',
     NULL,230,'Database Security','High',0,NULL),

    ('CALBAR-4.03','Guest CONNECT is revoked in user databases',
     'The guest user must not retain CONNECT in online user databases.','0','EQUALS',
     N'DECLARE @sql nvarchar(max)=N'''', @count bigint=0; SELECT @sql = STRING_AGG(CONVERT(nvarchar(max),N''USE ''+QUOTENAME(name)+N''; IF HAS_DBACCESS(DB_NAME())=1 BEGIN SELECT @c = @c + CASE WHEN EXISTS (SELECT 1 FROM sys.database_permissions p JOIN sys.database_principals dp ON p.grantee_principal_id=dp.principal_id WHERE dp.name=N''''guest'''' AND p.permission_name=N''''CONNECT'''' AND p.state IN (N''''G'''',N''''W'''')) THEN 1 ELSE 0 END; END''),N'' '') FROM sys.databases WHERE database_id>4 AND state_desc=N''ONLINE''; IF NULLIF(@sql,N'''') IS NOT NULL EXEC sys.sp_executesql @sql,N''@c bigint OUTPUT'',@c=@count OUTPUT; SELECT CAST(@count AS nvarchar(100)) AS ActualValue;',
     14,240,'Database Security','High',0,'Uses STRING_AGG and therefore applies to SQL Server 2017 and later.'),

    ('CALBAR-4.04','No orphaned SQL users exist in online user databases',
     'Database users mapped to SQL logins must have a matching server login.','0','EQUALS',
     N'DECLARE @sql nvarchar(max)=N'''', @count bigint=0; SELECT @sql = STRING_AGG(CONVERT(nvarchar(max),N''USE ''+QUOTENAME(name)+N''; IF HAS_DBACCESS(DB_NAME())=1 SELECT @c=@c+COUNT_BIG(*) FROM sys.database_principals dp WHERE dp.authentication_type=1 AND dp.sid IS NOT NULL AND dp.sid NOT IN (0x00,0x01) AND SUSER_SNAME(dp.sid) IS NULL;''),N'' '') FROM sys.databases WHERE database_id>4 AND state_desc=N''ONLINE''; IF NULLIF(@sql,N'''') IS NOT NULL EXEC sys.sp_executesql @sql,N''@c bigint OUTPUT'',@c=@count OUTPUT; SELECT CAST(@count AS nvarchar(100)) AS ActualValue;',
     14,250,'Database Security','Medium',0,'Uses STRING_AGG and therefore applies to SQL Server 2017 and later.'),

    ('CALBAR-4.05','No user databases are owned by unknown principals',
     'Every online user database owner SID must resolve to a server principal.','0','EQUALS',
     N'SELECT CAST(COUNT_BIG(*) AS nvarchar(100)) AS ActualValue FROM sys.databases WHERE database_id > 4 AND state_desc = ''ONLINE'' AND SUSER_SNAME(owner_sid) IS NULL;',
     NULL,260,'Database Security','High',0,NULL),

    /* Encryption and transport */
    ('CALBAR-6.01','Force Encryption is enabled',
     'SQL Server network encryption should be forced after certificate validation.','1','EQUALS',
     N'DECLARE @v int = NULL; EXEC master.sys.xp_instance_regread N''HKEY_LOCAL_MACHINE'',N''Software\Microsoft\MSSQLServer\MSSQLServer\SuperSocketNetLib'',N''ForceEncryption'',@v OUTPUT; SELECT CAST(COALESCE(@v,0) AS nvarchar(100)) AS ActualValue;',
     NULL,270,'Encryption','High',1,'Optional until CAL Bar completes SQL certificate deployment.'),

    ('CALBAR-6.02','All online user databases use encryption',
     'Counts online user databases that are not encrypted with TDE.','0','EQUALS',
     N'SELECT CAST(COUNT_BIG(*) AS nvarchar(100)) AS ActualValue FROM sys.databases WHERE database_id > 4 AND state_desc = ''ONLINE'' AND is_encrypted = 0;',
     NULL,280,'Encryption','High',1,'Optional because CAL Bar may phase TDE deployment or approve exceptions.'),

    /* Operational security */
    ('CALBAR-7.01','Backup compression default is enabled',
     'Reduces backup size and can improve backup throughput.','1','EQUALS',
     N'SELECT CAST(COALESCE(MAX(CONVERT(int,value_in_use)),-1) AS nvarchar(100)) AS ActualValue FROM sys.configurations WHERE name = ''backup compression default'';',
     NULL,290,'Operational Security','Low',0,NULL),

    ('CALBAR-7.02','Optimize for ad hoc workloads is enabled',
     'Reduces plan-cache pressure from single-use ad hoc plans.','1','EQUALS',
     N'SELECT CAST(COALESCE(MAX(CONVERT(int,value_in_use)),-1) AS nvarchar(100)) AS ActualValue FROM sys.configurations WHERE name = ''optimize for ad hoc workloads'';',
     NULL,300,'Operational Security','Low',0,NULL),

    ('CALBAR-7.03','Maximum server memory is explicitly configured',
     'The max server memory value must be below the SQL Server default maximum.','2147483646','MAXIMUM',
     N'SELECT CAST(COALESCE(MAX(CONVERT(bigint,value_in_use)),2147483647) AS nvarchar(100)) AS ActualValue FROM sys.configurations WHERE name = ''max server memory (MB)'';' ,
     NULL,310,'Operational Security','Medium',0,'This only confirms that a non-default ceiling exists; it does not calculate the ideal value.')
) AS source
(
    ControlCode,ControlName,Description,ExpectedValue,CheckType,CheckQuery,
    MinimumMajorVersion,SortOrder,Category,Severity,IsOptional,Notes
)
ON target.ControlCode = source.ControlCode
WHEN MATCHED THEN
    UPDATE SET
        ControlName = source.ControlName,
        Description = source.Description,
        ExpectedValue = source.ExpectedValue,
        CheckType = source.CheckType,
        CheckQuery = source.CheckQuery,
        MinimumMajorVersion = source.MinimumMajorVersion,
        SortOrder = source.SortOrder,
        Category = source.Category,
        Severity = source.Severity,
        IsOptional = source.IsOptional,
        Notes = source.Notes,
        IsEnabled = CASE WHEN source.IsOptional = 1 THEN target.IsEnabled ELSE 1 END
WHEN NOT MATCHED THEN
    INSERT
    (
        ControlCode,ControlName,Description,ExpectedValue,CheckType,CheckQuery,
        MinimumMajorVersion,SortOrder,Category,Severity,IsOptional,Notes,IsEnabled
    )
    VALUES
    (
        source.ControlCode,source.ControlName,source.Description,source.ExpectedValue,source.CheckType,source.CheckQuery,
        source.MinimumMajorVersion,source.SortOrder,source.Category,source.Severity,source.IsOptional,source.Notes,
        CASE WHEN source.IsOptional = 1 THEN 0 ELSE 1 END
    );
GO

/* Disable the original small seed set so each concept is not scanned twice. */
UPDATE cfg.CIS_Control_Definition
SET IsEnabled = 0
WHERE ControlCode LIKE 'CIS-%';
GO

SELECT
    Category,
    IsOptional,
    IsEnabled,
    COUNT(*) AS ControlCount
FROM cfg.CIS_Control_Definition
GROUP BY Category, IsOptional, IsEnabled
ORDER BY Category, IsOptional, IsEnabled;
GO
