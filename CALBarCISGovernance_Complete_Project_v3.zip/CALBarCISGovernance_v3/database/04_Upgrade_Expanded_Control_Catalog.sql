USE CALBAR_SQL_CIS;
GO

/* Expand the control catalog without breaking the existing website. */
IF COL_LENGTH('cfg.CIS_Control_Definition','Category') IS NULL
    ALTER TABLE cfg.CIS_Control_Definition ADD Category nvarchar(100) NULL;
IF COL_LENGTH('cfg.CIS_Control_Definition','Severity') IS NULL
    ALTER TABLE cfg.CIS_Control_Definition ADD Severity varchar(20) NULL;
IF COL_LENGTH('cfg.CIS_Control_Definition','IsOptional') IS NULL
    ALTER TABLE cfg.CIS_Control_Definition ADD IsOptional bit NOT NULL CONSTRAINT DF_CIS_Control_IsOptional DEFAULT(0);
IF COL_LENGTH('cfg.CIS_Control_Definition','Notes') IS NULL
    ALTER TABLE cfg.CIS_Control_Definition ADD Notes nvarchar(1000) NULL;
GO

/* Make Status large enough for future labels while remaining compatible with existing data. */
IF EXISTS
(
    SELECT 1
    FROM sys.columns
    WHERE object_id = OBJECT_ID('audit.CIS_Compliance_Result')
      AND name = 'Status'
      AND max_length < 20
)
BEGIN
    ALTER TABLE audit.CIS_Compliance_Result ALTER COLUMN Status varchar(20) NOT NULL;
END;
GO

/* Helpful run-level indexes for a larger control set. */
IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID('audit.CIS_Compliance_Result')
      AND name = 'IX_Result_Run'
)
CREATE INDEX IX_Result_Run
ON audit.CIS_Compliance_Result(RunId, Status)
INCLUDE(ServerId, ControlId, CheckedAtUtc);
GO
