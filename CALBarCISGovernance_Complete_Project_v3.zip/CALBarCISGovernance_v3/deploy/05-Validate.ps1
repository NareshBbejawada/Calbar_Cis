param
(
    [string]$RepositoryServer = 'LASQLCL3\ODYDEV',
    [string]$Url = 'http://azdbaprd01.calsb.org'
)

Import-Module SqlServer -ErrorAction Stop

Invoke-Sqlcmd `
    -ServerInstance $RepositoryServer `
    -Database CALBAR_SQL_CIS `
    -TrustServerCertificate `
    -Query @"
SELECT
    (SELECT COUNT(*) FROM inv.SQL_Server_Inventory WHERE IsEnabled=1) AS EnabledInventory,
    (SELECT COUNT(*) FROM cfg.CIS_Control_Definition WHERE IsEnabled=1 AND ISNULL(IsOptional,0)=0) AS EnabledBaselineControls,
    (SELECT COUNT(*) FROM cfg.CIS_Control_Definition WHERE IsEnabled=1 AND ISNULL(IsOptional,0)=1) AS EnabledOptionalControls,
    (SELECT COUNT(*) FROM audit.CIS_Compliance_Result) AS Results,
    (SELECT COUNT(*) FROM rpt.vw_CIS_Latest_Compliance_Result) AS Latest;
"@

Invoke-WebRequest $Url -UseDefaultCredentials |
    Select-Object StatusCode, StatusDescription
