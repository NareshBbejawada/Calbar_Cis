param
(
    [string]$RepositoryServer = 'LASQLCL3\ODYDEV',
    [string]$ProjectRoot = 'E:\CALBarCISGovernance'
)

$ErrorActionPreference = 'Stop'
Import-Module SqlServer -ErrorAction Stop

$databaseFolder = Join-Path $ProjectRoot 'Database'
$scripts = Get-ChildItem -Path $databaseFolder -Filter '*.sql' | Sort-Object Name

if (-not $scripts)
{
    throw "No SQL deployment scripts were found under $databaseFolder."
}

foreach ($script in $scripts)
{
    Write-Host "Executing $($script.Name)"

    $database = if ($script.Name -eq '01_Create_CALBAR_SQL_CIS.sql') { 'master' } else { 'CALBAR_SQL_CIS' }

    Invoke-Sqlcmd `
        -ServerInstance $RepositoryServer `
        -Database $database `
        -InputFile $script.FullName `
        -TrustServerCertificate `
        -AbortOnError `
        -ErrorAction Stop
}

Write-Host 'Database schema and expanded CAL Bar controls deployed.'
