/* =====================================================================
   07_alerts.sql  -  Phase 1 proactive monitoring
   Run on the LISTENER SFDBSLISTN01 (normal mode, not SQLCMD), AFTER
   01_schema.sql (Phase 1 tables) and 02_collect_proc.sql (calls these).
   Changes ONLY the billingdashboard database. Billing_V2 is only read.
   Safe to re-run.

   What it adds
     dbo.usp_CollectGatewayErrors  exceptionLog -> dbo.GatewayError
                                   (counts per web server per 5 min;
                                    Message is scanned for "timeout" /
                                    "connect" but NEVER stored)
     dbo.usp_EvaluateAlerts        9 rules, state, cooldown, RESOLVED
     dbo.usp_AlertNotify           AlertLog row + Database Mail
     dbo.usp_SendDailySummary      once a day at SummaryTime
   Mail goes out only when Config AlertMode = 'Send'. Default 'LogOnly':
   everything is evaluated and written to dbo.AlertLog, nothing is sent.
   ===================================================================== */
USE billingdashboard;
GO

CREATE OR ALTER FUNCTION dbo.fn_HtmlEsc (@s nvarchar(max))
RETURNS nvarchar(max)
AS
BEGIN
    RETURN REPLACE(REPLACE(REPLACE(ISNULL(@s, N''), N'&', N'&amp;'), N'<', N'&lt;'), N'>', N'&gt;');
END;
GO

/* =====================================================================
   1. Gateway errors per web server
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.usp_CollectGatewayErrors
    @now datetime2(0) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @now = ISNULL(@now, SYSDATETIME());

    DECLARE @q nvarchar(max) = dbo.fn_Cfg(N'GatewayErrorQuery');
    IF ISNULL(@q, N'') = N'' RETURN -1;

    /* Re-count the last 30 minutes every run (whole 5-minute buckets) */
    DECLARE @base  datetime2(0) = '2000-01-01';
    DECLARE @since datetime2(0) =
        DATEADD(MINUTE, (DATEDIFF(MINUTE, @base, DATEADD(MINUTE, -30, @now)) / 5) * 5, @base);
    DECLARE @rows int;

    CREATE TABLE #g (BucketTs datetime2(0) NULL, HostName nvarchar(128) NULL,
                     Kind varchar(20) NULL, ErrorCount int NULL);
    INSERT #g (BucketTs, HostName, Kind, ErrorCount)
    EXEC sys.sp_executesql @q, N'@since datetime2(0)', @since = @since;

    BEGIN TRY
        BEGIN TRAN;
        DELETE dbo.GatewayError WHERE BucketTs >= @since;
        INSERT dbo.GatewayError (BucketTs, HostName, Kind, ErrorCount)
        SELECT BucketTs, ISNULL(NULLIF(HostName, N''), N'(unknown)'), ISNULL(Kind, 'Other'), SUM(ErrorCount)
        FROM #g
        WHERE BucketTs >= @since
        GROUP BY BucketTs, ISNULL(NULLIF(HostName, N''), N'(unknown)'), ISNULL(Kind, 'Other');
        SET @rows = @@ROWCOUNT;
        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH;
    RETURN @rows;
END;
GO

/* =====================================================================
   2. Notify: one AlertLog row, and an email when AlertMode = 'Send'
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.usp_AlertNotify
    @RuleKey  varchar(40),
    @Kind     varchar(10),          -- RAISED / REMINDER / RESOLVED / SUPPRESSED / SUMMARY
    @Severity varchar(10),
    @Audience varchar(10),          -- IT / IT+MGMT
    @Subject  nvarchar(255),
    @Detail   nvarchar(2000),
    @BodyHtml nvarchar(max),
    @Send     bit,                  -- 0 = log only, whatever the mode
    @now      datetime2(0)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @mode    varchar(10)    = ISNULL(dbo.fn_Cfg(N'AlertMode'), 'LogOnly'),
            @profile sysname        = dbo.fn_Cfg(N'MailProfile'),
            @to      nvarchar(1000) = NULLIF(LTRIM(RTRIM(dbo.fn_Cfg(N'AlertRecipientsIT'))), N''),
            @mg      nvarchar(1000) = NULLIF(LTRIM(RTRIM(dbo.fn_Cfg(N'AlertRecipientsMgmt'))), N''),
            @imp     varchar(6),
            @note    nvarchar(400),
            @sent    bit = 0,
            @mailId  int = NULL;

    IF @Audience = 'IT+MGMT' AND @mg IS NOT NULL SET @to = CONCAT(@to + N';', @mg);
    SET @imp = CASE WHEN @Severity = 'critical' AND @Kind IN ('RAISED', 'REMINDER') THEN 'High' ELSE 'Normal' END;

    IF @Send = 0
        SET @note = CASE WHEN @Kind = 'SUPPRESSED' THEN N'Within cooldown of the previous email - not emailed'
                         ELSE N'No email was sent for this episode - not emailed' END;
    ELSE IF @mode <> 'Send'
        SET @note = N'LogOnly mode - not emailed';
    ELSE IF @to IS NULL
        SET @note = N'No recipients configured (Config AlertRecipientsIT)';
    ELSE
    BEGIN
        BEGIN TRY
            EXEC msdb.dbo.sp_send_dbmail
                 @profile_name = @profile,
                 @recipients   = @to,
                 @subject      = @Subject,
                 @body         = @BodyHtml,
                 @body_format  = 'HTML',
                 @importance   = @imp,
                 @mailitem_id  = @mailId OUTPUT;
            SET @sent = 1;
            SET @note = CONCAT(N'Queued to Database Mail, mail item ', @mailId);
        END TRY
        BEGIN CATCH
            SET @note = LEFT(N'Send failed: ' + ERROR_MESSAGE(), 400);
        END CATCH;
    END;

    INSERT dbo.AlertLog (LogTs, RuleKey, Kind, Severity, Subject, Detail, Recipients, Sent, SendNote, MailItemId)
    VALUES (@now, @RuleKey, @Kind, @Severity, LEFT(@Subject, 200), @Detail, @to, @sent, @note, @mailId);
END;
GO

/* =====================================================================
   3. Rule evaluation (called by usp_Collect every 2 minutes)
      Returns the number of rules firing, or -1 when AlertMode = Off.
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.usp_EvaluateAlerts
    @now datetime2(0) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET @now = ISNULL(@now, SYSDATETIME());

    DECLARE @mode varchar(10) = ISNULL(dbo.fn_Cfg(N'AlertMode'), 'LogOnly');
    IF @mode = 'Off' RETURN -1;

    DECLARE @quietMin int           = ISNULL(TRY_CAST(dbo.fn_Cfg(N'QuietMinutes')            AS int), 20),
            @bWeeks   int           = ISNULL(TRY_CAST(dbo.fn_Cfg(N'QuietBaselineWeeks')      AS int), 4),
            @bPct     decimal(9,2)  = ISNULL(TRY_CAST(dbo.fn_Cfg(N'QuietBaselinePct')        AS decimal(9,2)), 40),
            @bMin     decimal(9,2)  = ISNULL(TRY_CAST(dbo.fn_Cfg(N'QuietMinBaselinePerHour') AS decimal(9,2)), 30),
            @sys15    int           = ISNULL(TRY_CAST(dbo.fn_Cfg(N'SystemFailCount15m')      AS int), 5),
            @decMin   int           = ISNULL(TRY_CAST(dbo.fn_Cfg(N'DeclineMinAttempts60m')   AS int), 30),
            @decPct   decimal(9,2)  = ISNULL(TRY_CAST(dbo.fn_Cfg(N'FailRateCritPct')         AS decimal(9,2)), 15),
            @gw15     int           = ISNULL(TRY_CAST(dbo.fn_Cfg(N'GatewayErrCount15m')      AS int), 10),
            @stuckMin int           = ISNULL(TRY_CAST(dbo.fn_Cfg(N'StuckPendingMinutes')     AS int), 30),
            @stuckCnt int           = ISNULL(TRY_CAST(dbo.fn_Cfg(N'StuckAlertCount')         AS int), 5),
            @pings    int           = ISNULL(TRY_CAST(dbo.fn_Cfg(N'GeorgeDownPings')         AS int), 3),
            @agDbs    nvarchar(500) = N',' + REPLACE(ISNULL(dbo.fn_Cfg(N'AlertAgDatabases'), N'Billing_V2'), N' ', N'') + N',',
            @url      nvarchar(400) = ISNULL(dbo.fn_Cfg(N'DashboardUrl'), N'');
    IF @bWeeks NOT BETWEEN 1 AND 8 SET @bWeeks = 4;

    CREATE TABLE #ev (
        RuleKey varchar(40)    NOT NULL PRIMARY KEY,
        Firing  bit            NOT NULL,
        Value   decimal(18,2)  NULL,
        Subject nvarchar(200)  NULL,
        Detail  nvarchar(2000) NULL
    );

    /* ---------- payment volume vs same weekday/hour in previous weeks -- */
    DECLARE @first datetime2(0) = (SELECT MIN(TranTs) FROM dbo.PaymentTxn);
    DECLARE @c60 int, @base decimal(18,2), @lastC datetime2(0), @txnOk bit;

    SELECT w.k,
           c = (SELECT COUNT(*)
                FROM dbo.PaymentTxn p
                JOIN dbo.StatusMap sm ON sm.StatusCode = p.StatusCode AND sm.Category = 'Completed'
                WHERE p.TranTs >= DATEADD(MINUTE, -60, DATEADD(DAY, -7 * w.k, @now))
                  AND p.TranTs <  DATEADD(DAY, -7 * w.k, @now))
    INTO #cw
    FROM (VALUES (0),(1),(2),(3),(4),(5),(6),(7),(8)) w (k)
    WHERE w.k <= @bWeeks
      AND (w.k = 0 OR DATEADD(MINUTE, -60, DATEADD(DAY, -7 * w.k, @now)) >= @first);

    SELECT @c60 = c FROM #cw WHERE k = 0;
    SELECT @base = AVG(CAST(c AS decimal(18,2))) FROM #cw WHERE k > 0;     -- NULL = no history yet

    SELECT @lastC = MAX(p.TranTs)
    FROM dbo.PaymentTxn p
    JOIN dbo.StatusMap sm ON sm.StatusCode = p.StatusCode AND sm.Category = 'Completed'
    WHERE p.TranTs >= DATEADD(DAY, -3, @now);

    /* Volume rules only trust the data when the last transaction read worked */
    SET @txnOk = CASE WHEN EXISTS (SELECT 1 FROM dbo.CollectLog
                                   WHERE Step = 'Txn' AND Status = 'OK' AND RunTs >= DATEADD(MINUTE, -10, @now))
                      THEN 1 ELSE 0 END;

    DECLARE @quietFire bit = CASE WHEN @txnOk = 1 AND @base >= @bMin
                                   AND (@lastC IS NULL OR @lastC < DATEADD(MINUTE, -@quietMin, @now))
                                  THEN 1 ELSE 0 END;
    INSERT #ev (RuleKey, Firing, Value, Subject, Detail)
    SELECT 'NO_PAYMENTS', @quietFire, DATEDIFF(MINUTE, @lastC, @now),
           CASE WHEN @lastC IS NULL THEN N'No completed payments in the last 3 days'
                ELSE CONCAT(N'No completed payments for ', DATEDIFF(MINUTE, @lastC, @now), N' minutes') END,
           CONCAT(N'Last completed payment: ', ISNULL(FORMAT(@lastC, N'ddd MMM d HH:mm'), N'none in 3 days'),
                  N'. The same hour in the previous ', @bWeeks, N' weeks averaged ',
                  FORMAT(ISNULL(@base, 0), N'N0'), N' completed payments. ',
                  N'Check the payment pages, the payment gateway, and the gateway errors panel on the dashboard.');

    INSERT #ev (RuleKey, Firing, Value, Subject, Detail)
    SELECT 'LOW_VOLUME',
           CASE WHEN @txnOk = 1 AND @quietFire = 0 AND @base >= @bMin AND @c60 < @base * @bPct / 100.0
                THEN 1 ELSE 0 END,
           CASE WHEN @base > 0 THEN @c60 * 100.0 / @base END,
           CONCAT(N'Payment volume at ', FORMAT(CASE WHEN @base > 0 THEN @c60 * 100.0 / @base ELSE 0 END, N'N0'),
                  N'% of normal for this hour'),
           CONCAT(FORMAT(@c60, N'N0'), N' completed payments in the last 60 minutes; the same hour in the previous ',
                  @bWeeks, N' weeks averaged ', FORMAT(ISNULL(@base, 0), N'N0'),
                  N'. Alert threshold: below ', FORMAT(@bPct, N'N0'), N'%.');

    /* ---------- failures: system vs customer --------------------------- */
    SELECT p.ErrorCode, p.TranTs, sm.Category,
           Class = CASE WHEN sm.Category = 'Failed' THEN ISNULL(rc.Class, 'Customer') END
    INTO   #f
    FROM   dbo.PaymentTxn p
    JOIN   dbo.StatusMap sm ON sm.StatusCode = p.StatusCode
    LEFT JOIN dbo.ReasonClass rc ON rc.ReasonCode = ISNULL(p.ErrorCode, N'(no code)')
    WHERE  p.TranTs >= DATEADD(MINUTE, -60, @now)
      AND  sm.Category IN ('Completed', 'Failed');

    DECLARE @sysCnt int = (SELECT COUNT(*) FROM #f WHERE Class = 'System' AND TranTs >= DATEADD(MINUTE, -15, @now));
    DECLARE @sysTop nvarchar(1000) = STUFF((
        SELECT TOP (5) N', code ' + ISNULL(x.ErrorCode, N'(none)') + N' x' + CAST(COUNT(*) AS nvarchar(10))
                       + ISNULL(N' (' + MAX(rc.Description) + N')', N'')
        FROM #f x
        LEFT JOIN dbo.ReasonClass rc ON rc.ReasonCode = ISNULL(x.ErrorCode, N'(no code)')
        WHERE x.Class = 'System' AND x.TranTs >= DATEADD(MINUTE, -15, @now)
        GROUP BY x.ErrorCode
        ORDER BY COUNT(*) DESC
        FOR XML PATH(''), TYPE).value('.', 'nvarchar(1000)'), 1, 2, N'');

    INSERT #ev (RuleKey, Firing, Value, Subject, Detail)
    SELECT 'SYSTEM_FAILURES', CASE WHEN @sysCnt >= @sys15 THEN 1 ELSE 0 END, @sysCnt,
           CONCAT(@sysCnt, N' system payment failures in the last 15 minutes'),
           CONCAT(N'Gateway or processor failures (not customer declines): ', ISNULL(@sysTop, N'none'),
                  N'. Threshold: ', @sys15, N' in 15 minutes.');

    DECLARE @att int = (SELECT COUNT(*) FROM #f),
            @dec int = (SELECT COUNT(*) FROM #f WHERE Class = 'Customer');
    INSERT #ev (RuleKey, Firing, Value, Subject, Detail)
    SELECT 'DECLINE_RATE',
           CASE WHEN @att >= @decMin AND @dec * 100.0 / NULLIF(@att, 0) >= @decPct THEN 1 ELSE 0 END,
           @dec * 100.0 / NULLIF(@att, 0),
           CONCAT(N'Customer decline rate ', FORMAT(ISNULL(@dec * 100.0 / NULLIF(@att, 0), 0), N'N1'), N'% in the last hour'),
           CONCAT(@dec, N' of ', @att, N' payment attempts declined in the last 60 minutes (threshold ',
                  FORMAT(@decPct, N'N0'), N'%). A sudden rise can mean card testing or an issuer problem. ',
                  N'See Top failure reasons on the dashboard.');

    /* ---------- gateway errors per web server -------------------------- */
    DECLARE @gwMax int, @gwList nvarchar(1000);
    SELECT h.HostName, h.n, h.kinds
    INTO   #gw
    FROM (
        SELECT g.HostName, n = SUM(g.ErrorCount),
               kinds = STUFF((SELECT N', ' + g2.Kind + N' ' + CAST(SUM(g2.ErrorCount) AS nvarchar(10))
                              FROM dbo.GatewayError g2
                              WHERE g2.HostName = g.HostName AND g2.BucketTs >= DATEADD(MINUTE, -15, @now)
                              GROUP BY g2.Kind ORDER BY SUM(g2.ErrorCount) DESC
                              FOR XML PATH(''), TYPE).value('.', 'nvarchar(400)'), 1, 2, N'')
        FROM dbo.GatewayError g
        WHERE g.BucketTs >= DATEADD(MINUTE, -15, @now)
        GROUP BY g.HostName) h;
    SET @gwMax = (SELECT MAX(n) FROM #gw);
    SET @gwList = STUFF((
        SELECT N'; ' + x.HostName + ISNULL(N' (' + z.Zone + N')', N'') + N': ' + CAST(x.n AS nvarchar(10))
               + N' [' + x.kinds + N']'
        FROM #gw x LEFT JOIN dbo.ZoneMap z ON z.HostName = x.HostName
        WHERE x.n >= @gw15
        ORDER BY x.n DESC
        FOR XML PATH(''), TYPE).value('.', 'nvarchar(1000)'), 1, 2, N'');

    INSERT #ev (RuleKey, Firing, Value, Subject, Detail)
    SELECT 'GATEWAY_ERRORS', CASE WHEN @gwMax >= @gw15 THEN 1 ELSE 0 END, @gwMax,
           CONCAT(N'Payment gateway errors on ',
                  (SELECT COUNT(*) FROM #gw WHERE n >= @gw15), N' web server(s)'),
           CONCAT(N'Errors in the last 15 minutes (Billing_V2 exceptionLog): ', ISNULL(@gwList, N'none'),
                  N'. Threshold: ', @gw15, N' per server. If one server stands out, consider taking it out of rotation.');

    /* ---------- stuck pending ------------------------------------------ */
    DECLARE @stuck int, @stuckOld int;
    SELECT @stuck = COUNT(*), @stuckOld = MAX(DATEDIFF(MINUTE, p.TranTs, @now))
    FROM dbo.PaymentTxn p
    LEFT JOIN dbo.StatusMap sm ON sm.StatusCode = p.StatusCode
    WHERE ISNULL(sm.Category, 'Pending') = 'Pending'
      AND p.TranTs <  DATEADD(MINUTE, -@stuckMin, @now)
      AND p.TranTs >= DATEADD(DAY, -3, @now);
    INSERT #ev (RuleKey, Firing, Value, Subject, Detail)
    SELECT 'STUCK_PENDING', CASE WHEN @stuck >= @stuckCnt THEN 1 ELSE 0 END, @stuck,
           CONCAT(@stuck, N' payments stuck in pending'),
           CONCAT(@stuck, N' payments have been pending for more than ', @stuckMin, N' minutes (oldest ',
                  ISNULL(@stuckOld, 0), N' minutes). Possible missed gateway response or session lost on return.');

    /* ---------- GEORGE linked server ----------------------------------- */
    DECLARE @pn int, @pf int, @perr nvarchar(400);
    SELECT @pn = COUNT(*), @pf = SUM(CASE WHEN x.Success = 0 THEN 1 ELSE 0 END)
    FROM (SELECT TOP (@pings) Success FROM dbo.LinkedServerPing ORDER BY PingTs DESC) x;
    SELECT TOP (1) @perr = ErrorText FROM dbo.LinkedServerPing ORDER BY PingTs DESC;
    INSERT #ev (RuleKey, Firing, Value, Subject, Detail)
    SELECT 'GEORGE_DOWN', CASE WHEN @pn = @pings AND @pf = @pings THEN 1 ELSE 0 END, @pf,
           N'GEORGE linked server is not responding',
           CONCAT(N'The last ', @pings, N' pings of linked server ', dbo.fn_Cfg(N'GeorgeLinkedServer'),
                  N' failed. Billing progress (BMMASTP) is not updating. Last error: ', ISNULL(@perr, N'(none)'));

    /* ---------- availability group ------------------------------------- */
    DECLARE @agTs datetime2(0) = (SELECT MAX(SnapTs) FROM dbo.AgSnapshot);
    DECLARE @agBad int, @agList nvarchar(1000);
    SELECT @agBad = COUNT(*) FROM dbo.AgSnapshot a
    WHERE a.SnapTs = @agTs AND @agDbs LIKE N'%,' + a.DbName + N',%' AND ISNULL(a.SyncHealth, N'') <> N'HEALTHY';
    SET @agList = STUFF((
        SELECT N'; ' + a.ReplicaServer + N' / ' + a.DbName + N': ' + ISNULL(a.SyncHealth, N'?') + N' (' + ISNULL(a.SyncState, N'?') + N')'
        FROM dbo.AgSnapshot a
        WHERE a.SnapTs = @agTs AND @agDbs LIKE N'%,' + a.DbName + N',%' AND ISNULL(a.SyncHealth, N'') <> N'HEALTHY'
        FOR XML PATH(''), TYPE).value('.', 'nvarchar(1000)'), 1, 2, N'');
    INSERT #ev (RuleKey, Firing, Value, Subject, Detail)
    SELECT 'AG_UNHEALTHY', CASE WHEN @agBad > 0 THEN 1 ELSE 0 END, @agBad,
           CONCAT(N'Availability group: ', @agBad, N' replica database(s) not healthy'),
           CONCAT(N'As of ', FORMAT(@agTs, N'HH:mm'), N': ', ISNULL(@agList, N'all healthy'));

    /* ---------- collector ---------------------------------------------- */
    DECLARE @cn int, @cf int, @cerr nvarchar(2000);
    SELECT @cn = COUNT(*), @cf = SUM(CASE WHEN x.Status = 'ERROR' THEN 1 ELSE 0 END)
    FROM (SELECT TOP (3) Status FROM dbo.CollectLog WHERE Step = 'Txn' ORDER BY LogId DESC) x;
    SELECT TOP (1) @cerr = Message FROM dbo.CollectLog WHERE Step = 'Txn' ORDER BY LogId DESC;
    INSERT #ev (RuleKey, Firing, Value, Subject, Detail)
    SELECT 'COLLECTOR_FAILING', CASE WHEN @cn = 3 AND @cf = 3 THEN 1 ELSE 0 END, @cf,
           N'Dashboard cannot read Billing_V2 payment transactions',
           CONCAT(N'The last 3 reads failed, so payment alerts are blind. Last error: ', LEFT(ISNULL(@cerr, N''), 1500));

    /* =================================================================
       State machine: RAISED -> REMINDER (every CooldownMinutes) -> RESOLVED
       ================================================================= */
    INSERT dbo.AlertState (RuleKey, IsActive)
    SELECT r.RuleKey, 0 FROM dbo.AlertRule r
    WHERE NOT EXISTS (SELECT 1 FROM dbo.AlertState s WHERE s.RuleKey = r.RuleKey);

    /* A rule switched off while active is simply cleared (no RESOLVED email) */
    UPDATE s SET IsActive = 0, SinceTs = NULL, LastEvalTs = @now
    FROM dbo.AlertState s JOIN dbo.AlertRule r ON r.RuleKey = s.RuleKey
    WHERE r.Enabled = 0 AND s.IsActive = 1;

    DECLARE @rk varchar(40), @fire bit, @val decimal(18,2), @subj nvarchar(200), @det nvarchar(2000),
            @sev varchar(10), @aud varchar(10), @cool int, @title nvarchar(100),
            @active bit, @lastSent datetime2(0), @lastKind varchar(10), @sinceTs datetime2(0),
            @kind varchar(10), @send bit, @mSubj nvarchar(255), @mDet nvarchar(2000), @body nvarchar(max),
            @color varchar(10), @firing int = 0;

    DECLARE c CURSOR LOCAL FAST_FORWARD FOR
        SELECT e.RuleKey, e.Firing, e.Value, e.Subject, e.Detail,
               r.Severity, r.Audience, r.CooldownMinutes, r.Title,
               s.IsActive, s.LastSentTs, s.LastSentKind, s.SinceTs
        FROM #ev e
        JOIN dbo.AlertRule  r ON r.RuleKey = e.RuleKey AND r.Enabled = 1
        JOIN dbo.AlertState s ON s.RuleKey = e.RuleKey;
    OPEN c;
    FETCH NEXT FROM c INTO @rk, @fire, @val, @subj, @det, @sev, @aud, @cool, @title,
                           @active, @lastSent, @lastKind, @sinceTs;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @kind = NULL;
        IF @fire = 1 SET @firing += 1;

        IF @fire = 1 AND @active = 0
            SET @kind = CASE WHEN @lastSent >= DATEADD(MINUTE, -@cool, @now) THEN 'SUPPRESSED' ELSE 'RAISED' END;
        ELSE IF @fire = 1 AND @active = 1 AND (@lastSent IS NULL OR @lastSent < DATEADD(MINUTE, -@cool, @now))
            SET @kind = 'REMINDER';
        ELSE IF @fire = 0 AND @active = 1
            SET @kind = 'RESOLVED';

        UPDATE dbo.AlertState
        SET IsActive   = @fire,
            SinceTs    = CASE WHEN @fire = 1 AND @active = 0 THEN @now
                              WHEN @fire = 0 THEN NULL ELSE SinceTs END,
            LastEvalTs = @now,
            LastValue  = @val,
            Subject    = CASE WHEN @fire = 1 THEN @subj ELSE Subject END,
            Detail     = CASE WHEN @fire = 1 THEN @det  ELSE Detail  END
        WHERE RuleKey = @rk;

        IF @kind IS NOT NULL
        BEGIN
            SET @send = CASE WHEN @kind IN ('RAISED', 'REMINDER') THEN 1
                             WHEN @kind = 'RESOLVED' AND @lastKind IN ('RAISED', 'REMINDER') THEN 1
                             ELSE 0 END;
            IF @kind = 'RESOLVED'
            BEGIN
                SET @mSubj = CONCAT(N'[billingdashboard] RESOLVED: ', @title);
                SET @mDet  = CONCAT(N'Cleared at ', FORMAT(@now, N'HH:mm'), N' after ',
                                    DATEDIFF(MINUTE, @sinceTs, @now), N' minutes. Current value: ',
                                    ISNULL(FORMAT(@val, N'N0'), N'-'), N'.');
                SET @color = '#0ca30c';
            END
            ELSE
            BEGIN
                SET @mSubj = CONCAT(N'[billingdashboard] ', UPPER(@sev), CASE WHEN @kind = 'REMINDER' THEN N' (still active)' ELSE N'' END,
                                    N': ', @subj);
                SET @mDet  = CASE WHEN @kind = 'REMINDER'
                                  THEN CONCAT(N'Active since ', FORMAT(@sinceTs, N'HH:mm'), N' (',
                                              DATEDIFF(MINUTE, @sinceTs, @now), N' min). ', @det)
                                  ELSE @det END;
                SET @color = CASE @sev WHEN 'critical' THEN '#d03b3b' WHEN 'serious' THEN '#ec835a' ELSE '#fab219' END;
            END;

            SET @body = CONCAT(
                N'<div style="font:14px Segoe UI,Arial,sans-serif;color:#0b0b0b">',
                N'<div style="border-left:6px solid ', @color, N';padding:8px 14px;background:#f9f9f7">',
                N'<div style="font-size:16px;font-weight:600">', dbo.fn_HtmlEsc(CASE WHEN @kind = 'RESOLVED' THEN N'Resolved: ' + @title ELSE @subj END), N'</div>',
                N'<div style="margin-top:6px">', dbo.fn_HtmlEsc(@mDet), N'</div></div>',
                N'<p style="font-size:12px;color:#52514e">Rule ', @rk, N' &middot; ', dbo.fn_HtmlEsc(@title),
                N' &middot; evaluated ', FORMAT(@now, N'ddd MMM d HH:mm'), N' on ', dbo.fn_HtmlEsc(@@SERVERNAME), N'<br>',
                CASE WHEN @url <> N'' THEN CONCAT(N'Dashboard: <a href="', dbo.fn_HtmlEsc(@url), N'">', dbo.fn_HtmlEsc(@url), N'</a><br>') ELSE N'' END,
                N'Thresholds: billingdashboard.dbo.Config &middot; rule settings: billingdashboard.dbo.AlertRule</p></div>');

            EXEC dbo.usp_AlertNotify @RuleKey = @rk, @Kind = @kind, @Severity = @sev, @Audience = @aud,
                 @Subject = @mSubj, @Detail = @mDet, @BodyHtml = @body, @Send = @send, @now = @now;

            /* LogOnly counts as "sent" too, so the log shows the real email cadence */
            IF @send = 1
                UPDATE dbo.AlertState SET LastSentTs = @now, LastSentKind = @kind WHERE RuleKey = @rk;
        END;

        FETCH NEXT FROM c INTO @rk, @fire, @val, @subj, @det, @sev, @aud, @cool, @title,
                               @active, @lastSent, @lastKind, @sinceTs;
    END;
    CLOSE c; DEALLOCATE c;

    RETURN @firing;
END;
GO

/* =====================================================================
   4. Daily summary (once a day, SummaryTime .. +4 h)
      @Preview = 1 returns the HTML instead of logging / sending.
      @Force   = 1 ignores the time window and the once-a-day check.
      Returns 1 when a summary was produced.
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.usp_SendDailySummary
    @now     datetime2(0) = NULL,
    @Preview bit = 0,
    @Force   bit = 0
AS
BEGIN
    SET NOCOUNT ON;
    SET @now = ISNULL(@now, SYSDATETIME());

    IF ISNULL(dbo.fn_Cfg(N'AlertMode'), 'LogOnly') = 'Off' AND @Preview = 0 AND @Force = 0 RETURN 0;

    DECLARE @aud varchar(10), @enabled bit;
    SELECT @aud = Audience, @enabled = Enabled FROM dbo.AlertRule WHERE RuleKey = 'DAILY_SUMMARY';
    IF ISNULL(@enabled, 0) = 0 AND @Preview = 0 AND @Force = 0 RETURN 0;

    DECLARE @today date         = CAST(@now AS date);
    DECLARE @st    time(0)      = ISNULL(TRY_CAST(dbo.fn_Cfg(N'SummaryTime') AS time(0)), '08:30');
    DECLARE @due   datetime2(0) = DATEADD(SECOND, DATEDIFF(SECOND, CAST('00:00' AS time(0)), @st), CAST(@today AS datetime2(0)));

    IF @Preview = 0 AND @Force = 0
    BEGIN
        IF @now < @due OR @now > DATEADD(HOUR, 4, @due) RETURN 0;
        IF EXISTS (SELECT 1 FROM dbo.AlertLog
                   WHERE RuleKey = 'DAILY_SUMMARY' AND Kind = 'SUMMARY'
                     AND LogTs >= CAST(@today AS datetime2(0))) RETURN 0;
    END;

    DECLARE @d0 datetime2(0) = CAST(DATEADD(DAY, -1, @today) AS datetime2(0)),
            @d1 datetime2(0) = CAST(@today AS datetime2(0)),
            @url nvarchar(400) = ISNULL(dbo.fn_Cfg(N'DashboardUrl'), N'');

    /* Yesterday and the same weekday one week earlier */
    SELECT Wk = CASE WHEN p.TranTs >= @d0 THEN 0 ELSE 1 END,
           p.TranTs, AppCode = ISNULL(p.AppCode, N'OTHER'), p.Amount,
           Cat   = ISNULL(sm.Category, 'Pending'),
           Class = CASE WHEN sm.Category = 'Failed' THEN ISNULL(rc.Class, 'Customer') END
    INTO   #s
    FROM   dbo.PaymentTxn p
    LEFT JOIN dbo.StatusMap   sm ON sm.StatusCode = p.StatusCode
    LEFT JOIN dbo.ReasonClass rc ON rc.ReasonCode = ISNULL(p.ErrorCode, N'(no code)')
    WHERE (p.TranTs >= @d0 AND p.TranTs < @d1)
       OR (p.TranTs >= DATEADD(DAY, -7, @d0) AND p.TranTs < DATEADD(DAY, -7, @d1));

    DECLARE @cmp int, @amt decimal(14,2), @custF int, @sysF int, @pend int,
            @cmpW int, @amtW decimal(14,2), @peakH int, @peakN int;
    SELECT @cmp   = SUM(CASE WHEN Wk = 0 AND Cat = 'Completed' THEN 1 ELSE 0 END),
           @amt   = SUM(CASE WHEN Wk = 0 AND Cat = 'Completed' THEN Amount ELSE 0 END),
           @custF = SUM(CASE WHEN Wk = 0 AND Class = 'Customer' THEN 1 ELSE 0 END),
           @sysF  = SUM(CASE WHEN Wk = 0 AND Class = 'System'   THEN 1 ELSE 0 END),
           @pend  = SUM(CASE WHEN Wk = 0 AND Cat = 'Pending'    THEN 1 ELSE 0 END),
           @cmpW  = SUM(CASE WHEN Wk = 1 AND Cat = 'Completed' THEN 1 ELSE 0 END),
           @amtW  = SUM(CASE WHEN Wk = 1 AND Cat = 'Completed' THEN Amount ELSE 0 END)
    FROM #s;
    SELECT TOP (1) @peakH = DATEPART(HOUR, TranTs), @peakN = COUNT(*)
    FROM #s WHERE Wk = 0 AND Cat = 'Completed'
    GROUP BY DATEPART(HOUR, TranTs) ORDER BY COUNT(*) DESC;

    DECLARE @succ decimal(9,2) = ISNULL(@cmp, 0) * 100.0 / NULLIF(ISNULL(@cmp, 0) + ISNULL(@custF, 0) + ISNULL(@sysF, 0), 0);

    /* Billing progress: now vs ~24 h ago */
    DECLARE @mb int, @mp int, @ab decimal(14,2), @ap decimal(14,2), @pts datetime2(0), @mpY int;
    SELECT TOP (1) @pts = SnapTs, @mb = MembersBilled, @mp = MembersPaid, @ab = AmountBilled, @ap = AmountPaid
    FROM dbo.BillingProgress ORDER BY SnapTs DESC;
    SELECT TOP (1) @mpY = MembersPaid FROM dbo.BillingProgress
    WHERE SnapTs <= DATEADD(HOUR, -24, @now) ORDER BY SnapTs DESC;

    /* ---------- HTML pieces ------------------------------------------- */
    DECLARE @th  nvarchar(200) = N'<th style="text-align:left;border-bottom:1px solid #c3c2b7;padding:4px 10px">',
            @thr nvarchar(200) = N'<th style="text-align:right;border-bottom:1px solid #c3c2b7;padding:4px 10px">',
            @tbl nvarchar(200) = N'<table style="border-collapse:collapse;font:13px Segoe UI,Arial,sans-serif;margin:4px 0 14px">',
            @td  nvarchar(100) = N'<td style="padding:4px 10px;border-bottom:1px solid #e1e0d9">',
            @tdr nvarchar(100) = N'<td style="padding:4px 10px;border-bottom:1px solid #e1e0d9;text-align:right">',
            @h2  nvarchar(100) = N'<div style="font-weight:600;font-size:14px;margin-top:10px">';

    DECLARE @kpi nvarchar(max) = CONCAT(@tbl,
        N'<tr>', @td, N'Payments completed</td>', @tdr, FORMAT(ISNULL(@cmp, 0), N'N0'), N'</td>',
                 @td, N'same day last week: ', FORMAT(ISNULL(@cmpW, 0), N'N0'), N'</td></tr>',
        N'<tr>', @td, N'Amount collected</td>', @tdr, FORMAT(ISNULL(@amt, 0), N'C0', N'en-US'), N'</td>',
                 @td, N'same day last week: ', FORMAT(ISNULL(@amtW, 0), N'C0', N'en-US'), N'</td></tr>',
        N'<tr>', @td, N'Success rate</td>', @tdr, ISNULL(FORMAT(@succ, N'N1') + N'%', N'-'), N'</td>', @td, N'</td></tr>',
        N'<tr>', @td, N'Customer declines</td>', @tdr, FORMAT(ISNULL(@custF, 0), N'N0'), N'</td>', @td, N'card declined, AVS, insufficient funds ...</td></tr>',
        N'<tr>', @td, N'System failures</td>', @tdr, FORMAT(ISNULL(@sysF, 0), N'N0'), N'</td>', @td, N'gateway / processor errors</td></tr>',
        N'<tr>', @td, N'Still pending</td>', @tdr, FORMAT(ISNULL(@pend, 0), N'N0'), N'</td>', @td, N'started yesterday, no final result yet</td></tr>',
        N'<tr>', @td, N'Busiest hour</td>', @tdr, ISNULL(RIGHT(N'0' + CAST(@peakH AS nvarchar(2)), 2) + N':00', N'-'), N'</td>',
                 @td, ISNULL(FORMAT(@peakN, N'N0') + N' completed', N''), N'</td></tr>',
        N'</table>');

    DECLARE @apps nvarchar(max) = CONCAT(@tbl, N'<tr>', @th, N'Application</th>', @thr, N'Completed</th>', @thr, N'Amount</th>',
        @thr, N'Declines</th>', @thr, N'System failures</th></tr>',
        (SELECT CONCAT(N'<tr>', @td, dbo.fn_HtmlEsc(ISNULL(m.AppName, x.AppCode)), N'</td>',
                       @tdr, FORMAT(x.c, N'N0'), N'</td>', @tdr, FORMAT(x.a, N'C0', N'en-US'), N'</td>',
                       @tdr, FORMAT(x.cf, N'N0'), N'</td>', @tdr, FORMAT(x.sf, N'N0'), N'</td></tr>')
         FROM (SELECT AppCode,
                      c  = SUM(CASE WHEN Cat = 'Completed' THEN 1 ELSE 0 END),
                      a  = SUM(CASE WHEN Cat = 'Completed' THEN Amount ELSE 0 END),
                      cf = SUM(CASE WHEN Class = 'Customer' THEN 1 ELSE 0 END),
                      sf = SUM(CASE WHEN Class = 'System' THEN 1 ELSE 0 END)
               FROM #s WHERE Wk = 0 GROUP BY AppCode) x
         LEFT JOIN dbo.AppMap m ON m.AppCode = x.AppCode
         ORDER BY ISNULL(m.SortOrder, 99), x.AppCode
         FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'),
        N'</table>');

    DECLARE @prog nvarchar(max) = CASE WHEN @mb > 0 THEN CONCAT(
        N'<p style="margin:4px 0 14px">', FORMAT(@mp, N'N0'), N' of ', FORMAT(@mb, N'N0'), N' billed members paid (',
        FORMAT(@mp * 100.0 / @mb, N'N1'), N'%)',
        CASE WHEN @mpY IS NOT NULL THEN CONCAT(N', ', CASE WHEN @mp >= @mpY THEN N'+' ELSE N'' END, FORMAT(@mp - @mpY, N'N0'), N' in the last 24 hours') ELSE N'' END,
        N'. ', FORMAT(ISNULL(@ap, 0), N'C0', N'en-US'), N' paid of ', FORMAT(ISNULL(@ab, 0), N'C0', N'en-US'), N' billed. ',
        N'<span style="color:#898781">GEORGE BMMASTP, ', FORMAT(@pts, N'MMM d HH:mm'), N'</span></p>')
        ELSE N'<p style="margin:4px 0 14px;color:#898781">No billing progress snapshot yet.</p>' END;

    DECLARE @jobs nvarchar(max) = CONCAT(@tbl, N'<tr>', @th, N'Job</th>', @th, N'Result</th>', @th, N'Last run</th>', @th, N'Note</th></tr>',
        (SELECT CONCAT(N'<tr>', @td, dbo.fn_HtmlEsc(j.JobName), N'</td>',
                       @td, CASE WHEN j.Status = 'Failed' THEN N'<b style="color:#d03b3b">Failed</b>' ELSE dbo.fn_HtmlEsc(j.Status) END, N'</td>',
                       @td, FORMAT(j.RunStart, N'ddd HH:mm'), N'</td>',
                       @td, dbo.fn_HtmlEsc(LEFT(ISNULL(j.Message, N''), 200)), N'</td></tr>')
         FROM (SELECT *, rn = ROW_NUMBER() OVER (PARTITION BY Source, JobName ORDER BY RunStart DESC)
               FROM dbo.JobRun WHERE RunStart >= DATEADD(DAY, -2, @now)) j
         WHERE j.rn = 1
         ORDER BY j.JobName
         FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'),
        N'</table>');

    DECLARE @alrt nvarchar(max) = ISNULL(
        CONCAT(@tbl, N'<tr>', @th, N'Alert</th>', @thr, N'Times raised</th>', @th, N'Now</th></tr>',
            (SELECT CONCAT(N'<tr>', @td, dbo.fn_HtmlEsc(r.Title), N'</td>', @tdr, CAST(x.n AS nvarchar(10)), N'</td>',
                           @td, CASE WHEN s.IsActive = 1 THEN N'<b style="color:#d03b3b">Active</b>' ELSE N'Cleared' END, N'</td></tr>')
             FROM (SELECT RuleKey, n = COUNT(*) FROM dbo.AlertLog
                   WHERE LogTs >= DATEADD(HOUR, -24, @now) AND Kind IN ('RAISED', 'SUPPRESSED')
                   GROUP BY RuleKey) x
             JOIN dbo.AlertRule r ON r.RuleKey = x.RuleKey
             LEFT JOIN dbo.AlertState s ON s.RuleKey = x.RuleKey
             ORDER BY x.n DESC
             FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'),
            N'</table>'), N'');
    IF @alrt NOT LIKE N'%<td%' SET @alrt = N'<p style="margin:4px 0 14px">No alerts in the last 24 hours.</p>';

    DECLARE @dayTxt nvarchar(40) = FORMAT(@d0, N'dddd MMM d');
    DECLARE @subject nvarchar(255) = CONCAT(N'[billingdashboard] Daily summary for ', @dayTxt, N': ',
        FORMAT(ISNULL(@cmp, 0), N'N0'), N' payments, ', FORMAT(ISNULL(@amt, 0), N'C0', N'en-US'), N' collected',
        CASE WHEN EXISTS (SELECT 1 FROM dbo.AlertState WHERE IsActive = 1 AND RuleKey <> 'DAILY_SUMMARY')
             THEN N' - alerts active' ELSE N'' END);

    DECLARE @body nvarchar(max) = CONCAT(
        N'<div style="font:14px Segoe UI,Arial,sans-serif;color:#0b0b0b">',
        N'<div style="font-size:18px;font-weight:600">Online fee payments: ', @dayTxt, N'</div>',
        @h2, N'Yesterday</div>', @kpi,
        @h2, N'By application</div>', @apps,
        @h2, N'Billing progress (all channels)</div>', @prog,
        @h2, N'Processing jobs (latest run)</div>', @jobs,
        @h2, N'Alerts in the last 24 hours</div>', @alrt,
        N'<p style="font-size:12px;color:#52514e">Counts only; no cardholder data is included. ',
        CASE WHEN @url <> N'' THEN CONCAT(N'Dashboard: <a href="', dbo.fn_HtmlEsc(@url), N'">', dbo.fn_HtmlEsc(@url), N'</a>. ') ELSE N'' END,
        N'Generated ', FORMAT(@now, N'ddd MMM d HH:mm'), N' on ', dbo.fn_HtmlEsc(@@SERVERNAME), N'.</p></div>');

    IF @Preview = 1
    BEGIN
        SELECT Subject = @subject, BodyHtml = @body;
        RETURN 0;
    END;

    DECLARE @det nvarchar(2000) = CONCAT(FORMAT(ISNULL(@cmp, 0), N'N0'), N' completed, ',
        FORMAT(ISNULL(@amt, 0), N'C0', N'en-US'), N', ', ISNULL(@custF, 0), N' declines, ',
        ISNULL(@sysF, 0), N' system failures, ', ISNULL(@pend, 0), N' pending');
    EXEC dbo.usp_AlertNotify @RuleKey = 'DAILY_SUMMARY', @Kind = 'SUMMARY', @Severity = NULL,
         @Audience = @aud, @Subject = @subject, @Detail = @det, @BodyHtml = @body, @Send = 1, @now = @now;
    RETURN 1;
END;
GO

/* =====================================================================
   5. Build GatewayErrorQuery from the real exceptionLog columns
      (identity key, timestamp, MachineName, Message). Reads only the
      newest 5,000 rows by the key, never the whole table.
   ===================================================================== */
DECLARE @obj int = OBJECT_ID(N'Billing_V2.dbo.exceptionLog');
DECLARE @id sysname, @ts sysname, @mach sysname, @msg sysname, @q nvarchar(max), @utc bit = 0,
        @latest datetime2(0), @probe nvarchar(max);

IF @obj IS NULL
    PRINT N'!! Billing_V2.dbo.exceptionLog not found - GATEWAY_ERRORS stays off.';
ELSE
BEGIN
    SELECT @id = c.name FROM Billing_V2.sys.identity_columns c WHERE c.object_id = @obj;
    SELECT TOP (1) @ts = c.name
    FROM Billing_V2.sys.columns c
    JOIN Billing_V2.sys.types ty ON ty.user_type_id = c.user_type_id
    WHERE c.object_id = @obj AND ty.name IN (N'datetime', N'datetime2', N'smalldatetime', N'datetimeoffset')
    ORDER BY CASE WHEN c.name LIKE N'%creat%' OR c.name LIKE N'%timestamp%' OR c.name LIKE N'%log%date%'
                    OR c.name LIKE N'%log%time%' OR c.name LIKE N'%exception%date%' THEN 0
                  WHEN c.name LIKE N'%modif%' OR c.name LIKE N'%updat%' THEN 2 ELSE 1 END, c.column_id;
    SELECT TOP (1) @mach = c.name FROM Billing_V2.sys.columns c
    WHERE c.object_id = @obj AND c.name LIKE N'%machine%' ORDER BY c.column_id;
    SELECT TOP (1) @msg = c.name FROM Billing_V2.sys.columns c
    WHERE c.object_id = @obj AND c.name LIKE N'%message%'
    ORDER BY CASE WHEN c.name = N'Message' THEN 0 ELSE 1 END, c.column_id;

    PRINT CONCAT(N'exceptionLog columns: key=', ISNULL(@id, N'(none)'), N', time=', ISNULL(@ts, N'(none)'),
                 N', machine=', ISNULL(@mach, N'(none)'), N', message=', ISNULL(@msg, N'(none)'));

    IF @ts IS NULL OR @mach IS NULL
        PRINT N'!! No timestamp or MachineName column found - GATEWAY_ERRORS stays off. Send me the column list.';
    ELSE
    BEGIN
        /* Is the timestamp UTC? (newest row more than 1 hour in the future = UTC) */
        SET @probe = N'SELECT @latest = MAX(x.t) FROM (SELECT TOP (50) CAST(e.' + QUOTENAME(@ts) + N' AS datetime2(0)) AS t
                       FROM Billing_V2.dbo.exceptionLog e WITH (NOLOCK) ORDER BY '
                   + QUOTENAME(ISNULL(@id, @ts)) + N' DESC) x';
        EXEC sys.sp_executesql @probe, N'@latest datetime2(0) OUTPUT', @latest = @latest OUTPUT;
        IF @latest > DATEADD(HOUR, 1, SYSDATETIME()) SET @utc = 1;
        PRINT CONCAT(N'Newest exceptionLog row: ', ISNULL(CONVERT(nvarchar(19), @latest, 120), N'(none)'),
                     N' (server time now ', CONVERT(nvarchar(19), SYSDATETIME(), 120), N') -> ',
                     CASE WHEN @utc = 1 THEN N'treated as UTC' ELSE N'treated as local time' END);

        SET @q = N'SELECT b.BucketTs AS BUCKET_TS, b.HostName AS HOST_NAME, b.Kind AS KIND, COUNT(*) AS ERROR_COUNT
FROM (SELECT TOP (5000) '
 + CASE WHEN @utc = 1
        THEN N'DATEADD(MINUTE, DATEDIFF(MINUTE, SYSUTCDATETIME(), SYSDATETIME()), CAST(e.' + QUOTENAME(@ts) + N' AS datetime2(0)))'
        ELSE N'CAST(e.' + QUOTENAME(@ts) + N' AS datetime2(0))' END + N' AS ts,
             CAST(e.' + QUOTENAME(@mach) + N' AS nvarchar(128)) AS mach,
             ' + CASE WHEN @msg IS NULL THEN N'CAST(NULL AS nvarchar(1))'
                      ELSE N'LEFT(CAST(e.' + QUOTENAME(@msg) + N' AS nvarchar(max)), 2000)' END + N' AS msg
      FROM Billing_V2.dbo.exceptionLog e WITH (NOLOCK)
      ' + CASE WHEN @id IS NOT NULL THEN N'ORDER BY e.' + QUOTENAME(@id) + N' DESC'
               ELSE N'WHERE e.' + QUOTENAME(@ts) + N' >= DATEADD(HOUR, -12, @since) ORDER BY e.' + QUOTENAME(@ts) + N' DESC' END + N') x
CROSS APPLY (SELECT BucketTs = DATEADD(MINUTE, (DATEDIFF(MINUTE, CAST(''2000-01-01'' AS datetime2(0)), x.ts) / 5) * 5,
                                       CAST(''2000-01-01'' AS datetime2(0))),
                    HostName = UPPER(LEFT(ISNULL(NULLIF(LTRIM(RTRIM(x.mach)), N''''), N''(unknown)''), 128)),
                    Kind = CASE WHEN x.msg LIKE N''%timeout%'' OR x.msg LIKE N''%timed out%'' THEN ''Timeout''
                                WHEN x.msg LIKE N''%connect%'' OR x.msg LIKE N''%SSL%'' OR x.msg LIKE N''%TLS%''
                                  OR x.msg LIKE N''%could not be resolved%'' THEN ''Connection''
                                ELSE ''Other'' END) b
WHERE x.ts >= @since
GROUP BY b.BucketTs, b.HostName, b.Kind';

        UPDATE dbo.Config SET ConfigValue = @q WHERE ConfigKey = N'GatewayErrorQuery';
        PRINT N'GatewayErrorQuery configured.';
    END;
END;
GO

/* =====================================================================
   6. CHECKS (read only, except one collection + one evaluation run)
   ===================================================================== */
-- 6a. Failure reason codes in the last 30 days and how they are classed.
--     Anything System-like still showing "Customer"? Add it to dbo.ReasonClass.
SELECT ISNULL(p.ErrorCode, N'(no code)') AS reason_code,
       ISNULL(rc.Class, 'Customer (default)') AS class,
       COUNT(*) AS failures, MAX(p.ErrorText) AS sample_text, MAX(p.TranTs) AS last_seen
FROM dbo.PaymentTxn p
JOIN dbo.StatusMap sm ON sm.StatusCode = p.StatusCode AND sm.Category = 'Failed'
LEFT JOIN dbo.ReasonClass rc ON rc.ReasonCode = ISNULL(p.ErrorCode, N'(no code)')
WHERE p.TranTs >= DATEADD(DAY, -30, SYSDATETIME())
GROUP BY ISNULL(p.ErrorCode, N'(no code)'), ISNULL(rc.Class, 'Customer (default)')
ORDER BY failures DESC;

-- 6b. Gateway errors: collect once, then per server per day for the last 7 days
--     (the collector only re-reads 30 minutes; this check reads 7 days ONCE)
DECLARE @r int;
EXEC @r = dbo.usp_CollectGatewayErrors;
SELECT CONCAT(N'usp_CollectGatewayErrors returned ', @r, N' (-1 = not configured)') AS gateway_collect;

DECLARE @q7 nvarchar(max) = REPLACE(REPLACE(dbo.fn_Cfg(N'GatewayErrorQuery'), N'TOP (5000)', N'TOP (50000)'),
                                    N'DATEADD(HOUR, -12, @since)', N'@since');
IF ISNULL(@q7, N'') <> N''
BEGIN
    CREATE TABLE #g7 (BucketTs datetime2(0), HostName nvarchar(128), Kind varchar(20), ErrorCount int);
    DECLARE @s7 datetime2(0) = DATEADD(DAY, -7, SYSDATETIME());
    INSERT #g7 EXEC sys.sp_executesql @q7, N'@since datetime2(0)', @since = @s7;
    SELECT CAST(BucketTs AS date) AS day, HostName, Kind, SUM(ErrorCount) AS errors,
           MAX(ErrorCount) AS worst_5min_bucket
    FROM #g7 GROUP BY CAST(BucketTs AS date), HostName, Kind
    ORDER BY day DESC, HostName, Kind;
    DROP TABLE #g7;
END;

-- 6c. Baseline the volume rules will compare against (completed per hour,
--     same weekday, previous 4 weeks). Rules stay quiet below QuietMinBaselinePerHour.
SELECT DATEPART(WEEKDAY, p.TranTs) AS weekday_num, DATENAME(WEEKDAY, p.TranTs) AS weekday,
       DATEPART(HOUR, p.TranTs) AS hour, COUNT(*) / 4.0 AS avg_completed_per_hour
FROM dbo.PaymentTxn p
JOIN dbo.StatusMap sm ON sm.StatusCode = p.StatusCode AND sm.Category = 'Completed'
WHERE p.TranTs >= DATEADD(DAY, -28, CAST(CAST(SYSDATETIME() AS date) AS datetime2(0)))
  AND p.TranTs <  CAST(CAST(SYSDATETIME() AS date) AS datetime2(0))
GROUP BY DATEPART(WEEKDAY, p.TranTs), DATENAME(WEEKDAY, p.TranTs), DATEPART(HOUR, p.TranTs)
HAVING COUNT(*) / 4.0 >= 5
ORDER BY weekday_num, hour;

-- 6d. Evaluate all rules once in the current AlertMode (LogOnly = nothing is emailed)
SELECT ConfigKey, ConfigValue FROM dbo.Config WHERE ConfigKey IN (N'AlertMode', N'MailProfile', N'AlertRecipientsIT', N'AlertRecipientsMgmt');
EXEC @r = dbo.usp_EvaluateAlerts;
SELECT CONCAT(@r, N' rule(s) firing right now') AS evaluate_result;
SELECT s.RuleKey, r.Severity, r.Audience, s.IsActive, s.SinceTs, s.LastValue, s.Subject
FROM dbo.AlertState s JOIN dbo.AlertRule r ON r.RuleKey = s.RuleKey ORDER BY s.IsActive DESC, s.RuleKey;
SELECT TOP (20) LogTs, RuleKey, Kind, Subject, Sent, SendNote FROM dbo.AlertLog ORDER BY AlertId DESC;

-- 6e. Preview of tomorrow's 8:30 summary (copy BodyHtml into a .html file to view it)
EXEC dbo.usp_SendDailySummary @Preview = 1;
