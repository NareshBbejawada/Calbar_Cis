/* =====================================================================
   02_collect_proc.sql  -  dbo.usp_Collect
   Run every 2-5 minutes from SQL Agent (05_agent_job.sql).
   Each step is isolated in TRY/CATCH and logged to dbo.CollectLog, so a
   linked-server outage does not stop the SQL-side health collection.
   ===================================================================== */
USE billingdashboard;
GO
CREATE OR ALTER PROCEDURE dbo.usp_Collect
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;

    /* Only collect on the AG primary of billingdashboard (NULL = not in an AG) */
    IF ISNULL(sys.fn_hadr_is_primary_replica(N'billingdashboard'), 1) = 0
    BEGIN
        RETURN;
    END;

    DECLARE @now   datetime2(0) = SYSDATETIME(),
            @t0    datetime2(3),
            @rows  int,
            @sql   nvarchar(max),
            @q     nvarchar(max),
            @ls    sysname,
            @err   nvarchar(2000);

    SELECT @ls = ConfigValue FROM dbo.Config WHERE ConfigKey = N'GeorgeLinkedServer';

    /* ---------------------------------------------------------------
       STEP 1  Online payment transactions
               Primary source: Billing_V2 (Online Payment Service tables,
               local and real-time) via LocalTxnQuery.
               Fallback: GEORGE pass-through via GeorgeTxnQuery.
       --------------------------------------------------------------- */
    SET @t0 = SYSDATETIME();
    BEGIN TRY
        DECLARE @lookback int =
            TRY_CAST((SELECT ConfigValue FROM dbo.Config WHERE ConfigKey = N'TxnLookbackHours') AS int);
        DECLARE @since datetime2(0) = DATEADD(HOUR, -ISNULL(@lookback, 6), @now);
        DECLARE @lq nvarchar(max) = (SELECT ConfigValue FROM dbo.Config WHERE ConfigKey = N'LocalTxnQuery');

        CREATE TABLE #stage (
            TranId     nvarchar(64)  NOT NULL,
            TranTs     datetime2(0)  NULL,
            AppCode    nvarchar(50)  NULL,
            StatusCode nvarchar(50)  NULL,
            Amount     decimal(12,2) NULL,
            ErrorCode  nvarchar(100) NULL,
            ErrorText  nvarchar(400) NULL
        );

        IF ISNULL(@lq, N'') <> N'' AND @lq NOT LIKE N'%<%_COL>%'
        BEGIN
            /* Local T-SQL: must return the 7 columns in order and filter on @since */
            INSERT #stage (TranId, TranTs, AppCode, StatusCode, Amount, ErrorCode, ErrorText)
            EXEC sys.sp_executesql @lq, N'@since datetime2(0)', @since = @since;
        END
        ELSE
        BEGIN
            SELECT @q = ConfigValue FROM dbo.Config WHERE ConfigKey = N'GeorgeTxnQuery';
            IF ISNULL(@q, N'') = N'' OR @q LIKE N'%<%_COL>%'
                THROW 50010, N'Neither LocalTxnQuery nor GeorgeTxnQuery is configured - edit dbo.Config.', 1;

            SET @q = REPLACE(@q, N'{SINCE_TS}',
                        N'''' + FORMAT(@since, N'yyyy-MM-dd-HH.mm.ss') + N'''');
            SET @q = REPLACE(@q, N'{SINCE_DATE8}', FORMAT(@since, N'yyyyMMdd'));

            SET @sql = N'INSERT INTO #stage (TranId, TranTs, AppCode, StatusCode, Amount, ErrorCode, ErrorText)
SELECT LTRIM(RTRIM(CAST(TRAN_ID AS nvarchar(64)))),
       TRY_CAST(TRAN_TS AS datetime2(0)),
       LTRIM(RTRIM(CAST(APP_CODE AS nvarchar(50)))),
       LTRIM(RTRIM(CAST(STATUS_CODE AS nvarchar(50)))),
       TRY_CAST(AMOUNT AS decimal(12,2)),
       NULLIF(LTRIM(RTRIM(CAST(ERROR_CODE AS nvarchar(100)))), N''''),
       NULLIF(LTRIM(RTRIM(CAST(ERROR_TEXT AS nvarchar(400)))), N'''')
FROM OPENQUERY(' + QUOTENAME(@ls) + N', N''' + REPLACE(@q, N'''', N'''''') + N''');';
            EXEC sys.sp_executesql @sql;
        END;

        /* keep the newest row per TranId in case the source returns duplicates */
        ;WITH d AS (
            SELECT *, rn = ROW_NUMBER() OVER (PARTITION BY TranId ORDER BY TranTs DESC)
            FROM #stage WHERE TranTs IS NOT NULL)
        MERGE dbo.PaymentTxn AS t
        USING (SELECT * FROM d WHERE rn = 1) AS s
           ON t.TranId = s.TranId
        WHEN MATCHED AND (   ISNULL(t.StatusCode,N'') <> ISNULL(s.StatusCode,N'')
                          OR ISNULL(t.ErrorCode, N'') <> ISNULL(s.ErrorCode, N'')
                          OR ISNULL(t.Amount, -1)     <> ISNULL(s.Amount, -1))
            THEN UPDATE SET StatusCode = s.StatusCode, ErrorCode = s.ErrorCode,
                            ErrorText = s.ErrorText, Amount = s.Amount,
                            AppCode = s.AppCode, LastSeenTs = @now
        WHEN NOT MATCHED BY TARGET
            THEN INSERT (TranId, TranTs, AppCode, StatusCode, Amount, ErrorCode, ErrorText, FirstSeenTs, LastSeenTs)
                 VALUES (s.TranId, s.TranTs, s.AppCode, s.StatusCode, s.Amount, s.ErrorCode, s.ErrorText, @now, @now);
        SET @rows = @@ROWCOUNT;

        INSERT dbo.CollectLog (RunTs, Step, Status, RowsAff, DurationMs, Message)
        VALUES (@now, 'Txn', 'OK', @rows, DATEDIFF(MILLISECOND, @t0, SYSDATETIME()),
                CONCAT(N'Read ', (SELECT COUNT(*) FROM #stage), N' rows since ', FORMAT(@since, N'yyyy-MM-dd HH:mm')));
        DROP TABLE #stage;
    END TRY
    BEGIN CATCH
        SET @err = ERROR_MESSAGE();
        IF OBJECT_ID(N'tempdb..#stage') IS NOT NULL DROP TABLE #stage;
        INSERT dbo.CollectLog (RunTs, Step, Status, DurationMs, Message)
        VALUES (@now, 'Txn', 'ERROR', DATEDIFF(MILLISECOND, @t0, SYSDATETIME()), @err);
    END CATCH;

    /* ---------------------------------------------------------------
       STEP 2  Linked server round-trip time
       --------------------------------------------------------------- */
    SET @t0 = SYSDATETIME();
    BEGIN TRY
        SELECT @q = ConfigValue FROM dbo.Config WHERE ConfigKey = N'GeorgePingQuery';
        CREATE TABLE #ping (OK int NULL);
        SET @sql = N'INSERT INTO #ping SELECT * FROM OPENQUERY(' + QUOTENAME(@ls) + N', N'''
                 + REPLACE(@q, N'''', N'''''') + N''');';
        EXEC sys.sp_executesql @sql;
        DROP TABLE #ping;
        INSERT dbo.LinkedServerPing (PingTs, LinkedServer, DurationMs, Success)
        VALUES (@now, @ls, DATEDIFF(MILLISECOND, @t0, SYSDATETIME()), 1);
    END TRY
    BEGIN CATCH
        SET @err = ERROR_MESSAGE();
        IF OBJECT_ID(N'tempdb..#ping') IS NOT NULL DROP TABLE #ping;
        INSERT dbo.LinkedServerPing (PingTs, LinkedServer, DurationMs, Success, ErrorText)
        VALUES (@now, @ls, DATEDIFF(MILLISECOND, @t0, SYSDATETIME()), 0, LEFT(@err, 400));
    END CATCH;

    /* ---------------------------------------------------------------
       STEP 3  Billing progress (BMMASTP) - every N minutes
       --------------------------------------------------------------- */
    SET @t0 = SYSDATETIME();
    BEGIN TRY
        DECLARE @every int = ISNULL(TRY_CAST((SELECT ConfigValue FROM dbo.Config
                                WHERE ConfigKey = N'ProgressEveryMinutes') AS int), 30);
        SELECT @q = ConfigValue FROM dbo.Config WHERE ConfigKey = N'GeorgeProgressQuery';

        IF ISNULL(@q, N'') = N'' OR @q LIKE N'%<%_COL>%'
            INSERT dbo.CollectLog (RunTs, Step, Status, Message)
            VALUES (@now, 'Progress', 'SKIP', N'GeorgeProgressQuery not configured');
        ELSE IF NOT EXISTS (SELECT 1 FROM dbo.BillingProgress
                            WHERE SnapTs > DATEADD(MINUTE, -@every, @now))
        BEGIN
            DECLARE @cy nvarchar(4) = ISNULL((SELECT ConfigValue FROM dbo.Config WHERE ConfigKey = N'BillingYear'),
                                          LEFT((SELECT ConfigValue FROM dbo.Config WHERE ConfigKey = N'CycleStart'), 4));
            SET @q = REPLACE(@q, N'{CYCLE_YEAR}', @cy);
            SET @sql = N'INSERT dbo.BillingProgress (SnapTs, MembersBilled, MembersPaid, AmountBilled, AmountPaid)
SELECT @now, MEMBERS_BILLED, MEMBERS_PAID, AMOUNT_BILLED, AMOUNT_PAID
FROM OPENQUERY(' + QUOTENAME(@ls) + N', N''' + REPLACE(@q, N'''', N'''''') + N''');';
            EXEC sys.sp_executesql @sql, N'@now datetime2(0)', @now = @now;
            INSERT dbo.CollectLog (RunTs, Step, Status, RowsAff, DurationMs)
            VALUES (@now, 'Progress', 'OK', @@ROWCOUNT, DATEDIFF(MILLISECOND, @t0, SYSDATETIME()));
        END;
    END TRY
    BEGIN CATCH
        INSERT dbo.CollectLog (RunTs, Step, Status, DurationMs, Message)
        VALUES (@now, 'Progress', 'ERROR', DATEDIFF(MILLISECOND, @t0, SYSDATETIME()), ERROR_MESSAGE());
    END CATCH;

    /* ---------------------------------------------------------------
       STEP 4  Job runs (.NET job log in Billing_V2 + SQL Agent)
       --------------------------------------------------------------- */
    SET @t0 = SYSDATETIME();
    BEGIN TRY
        CREATE TABLE #jobs (JOB_NAME nvarchar(200), RUN_START datetime2(0), RUN_END datetime2(0),
                            STATUS varchar(20), ROWS_PROCESSED int, MESSAGE nvarchar(1000));
        SELECT @q = ConfigValue FROM dbo.Config WHERE ConfigKey = N'AppJobLogQuery';
        IF ISNULL(@q, N'') <> N'' AND @q NOT LIKE N'%<%_COL>%'
        BEGIN
            INSERT #jobs EXEC sys.sp_executesql @q;
            MERGE dbo.JobRun AS t
            USING (SELECT DISTINCT 'AppLog' AS Source, JOB_NAME, RUN_START, RUN_END, STATUS, ROWS_PROCESSED, MESSAGE
                   FROM #jobs WHERE JOB_NAME IS NOT NULL AND RUN_START IS NOT NULL) AS s
               ON t.Source = s.Source AND t.JobName = s.JOB_NAME AND t.RunStart = s.RUN_START
            WHEN MATCHED THEN UPDATE SET RunEnd = s.RUN_END, Status = s.STATUS,
                                         RowsProcessed = s.ROWS_PROCESSED, Message = s.MESSAGE
            WHEN NOT MATCHED THEN INSERT (Source, JobName, RunStart, RunEnd, Status, RowsProcessed, Message)
                 VALUES (s.Source, s.JOB_NAME, s.RUN_START, s.RUN_END, s.STATUS, s.ROWS_PROCESSED, s.MESSAGE);
        END;
        DROP TABLE #jobs;

        DECLARE @like nvarchar(200) = (SELECT ConfigValue FROM dbo.Config WHERE ConfigKey = N'AgentJobNameLike');
        IF ISNULL(@like, N'') <> N''
        BEGIN
            ;WITH h AS (
                SELECT j.name AS JobName,
                       msdb.dbo.agent_datetime(h.run_date, h.run_time) AS RunStart,
                       DATEADD(SECOND, (h.run_duration / 10000) * 3600 + (h.run_duration / 100 % 100) * 60
                                      + (h.run_duration % 100), msdb.dbo.agent_datetime(h.run_date, h.run_time)) AS RunEnd,
                       CASE h.run_status WHEN 1 THEN 'Succeeded' WHEN 4 THEN 'Running' ELSE 'Failed' END AS Status,
                       LEFT(h.message, 1000) AS Message
                FROM msdb.dbo.sysjobs j
                JOIN msdb.dbo.sysjobhistory h ON h.job_id = j.job_id AND h.step_id = 0
                WHERE j.name LIKE @like
                  AND j.name <> N'billingdashboard - Collect'
                  AND h.run_date >= CONVERT(int, FORMAT(DATEADD(DAY, -2, @now), 'yyyyMMdd')))
            MERGE dbo.JobRun AS t
            USING (SELECT 'SQLAgent' AS Source, JobName, RunStart, MAX(RunEnd) AS RunEnd,
                          MAX(Status) AS Status, MAX(Message) AS Message
                   FROM h GROUP BY JobName, RunStart) AS s
               ON t.Source = s.Source AND t.JobName = s.JobName AND t.RunStart = s.RunStart
            WHEN MATCHED THEN UPDATE SET RunEnd = s.RunEnd, Status = s.Status, Message = s.Message
            WHEN NOT MATCHED THEN INSERT (Source, JobName, RunStart, RunEnd, Status, Message)
                 VALUES (s.Source, s.JobName, s.RunStart, s.RunEnd, s.Status, s.Message);
        END;
        INSERT dbo.CollectLog (RunTs, Step, Status, DurationMs)
        VALUES (@now, 'Jobs', 'OK', DATEDIFF(MILLISECOND, @t0, SYSDATETIME()));
    END TRY
    BEGIN CATCH
        IF OBJECT_ID(N'tempdb..#jobs') IS NOT NULL DROP TABLE #jobs;
        INSERT dbo.CollectLog (RunTs, Step, Status, DurationMs, Message)
        VALUES (@now, 'Jobs', 'ERROR', DATEDIFF(MILLISECOND, @t0, SYSDATETIME()), ERROR_MESSAGE());
    END CATCH;

    /* ---------------------------------------------------------------
       STEP 5  SQL-side health: web node connections, AG, blocking, waits
       --------------------------------------------------------------- */
    SET @t0 = SYSDATETIME();
    BEGIN TRY
        /* Which DMZ servers are talking to this instance right now */
        INSERT dbo.WebNodeSnapshot (SnapTs, HostName, ProgramName, DbName, Sessions, ActiveRequests, CpuMs)
        SELECT @now, UPPER(s.host_name), LEFT(ISNULL(s.program_name, N'(unknown)'), 128),
               ISNULL(DB_NAME(s.database_id), N'(none)'),
               COUNT(*), COUNT(r.session_id), SUM(CAST(s.cpu_time AS bigint))
        FROM sys.dm_exec_sessions s
        JOIN dbo.ZoneMap z ON z.HostName = UPPER(s.host_name)
        LEFT JOIN sys.dm_exec_requests r ON r.session_id = s.session_id
        WHERE s.is_user_process = 1
        GROUP BY UPPER(s.host_name), LEFT(ISNULL(s.program_name, N'(unknown)'), 128),
                 ISNULL(DB_NAME(s.database_id), N'(none)');

        /* AG replica health (all AGs on this instance) */
        INSERT dbo.AgSnapshot (SnapTs, AgName, ReplicaServer, DbName, RoleDesc, AvailMode,
                               SyncState, SyncHealth, LogSendQueueKb, RedoQueueKb)
        SELECT @now, ag.name, ar.replica_server_name, DB_NAME(drs.database_id),
               ars.role_desc, ar.availability_mode_desc,
               drs.synchronization_state_desc, drs.synchronization_health_desc,
               drs.log_send_queue_size, drs.redo_queue_size
        FROM sys.dm_hadr_database_replica_states drs
        JOIN sys.availability_replicas ar ON ar.replica_id = drs.replica_id
        JOIN sys.availability_groups  ag ON ag.group_id = drs.group_id
        LEFT JOIN sys.dm_hadr_availability_replica_states ars ON ars.replica_id = drs.replica_id;

        /* Blocking */
        INSERT dbo.InstanceSnapshot (SnapTs, ActiveRequests, BlockedSessions, LongestBlockSec)
        SELECT @now,
               COUNT(*),
               SUM(CASE WHEN r.blocking_session_id <> 0 THEN 1 ELSE 0 END),
               ISNULL(MAX(CASE WHEN r.blocking_session_id <> 0 THEN r.wait_time END), 0) / 1000
        FROM sys.dm_exec_requests r
        JOIN sys.dm_exec_sessions s ON s.session_id = r.session_id
        WHERE s.is_user_process = 1 AND r.session_id <> @@SPID;

        /* Top cumulative waits, benign ones excluded */
        INSERT dbo.WaitSnapshot (SnapTs, WaitType, WaitMs, Tasks)
        SELECT TOP (40) @now, wait_type, wait_time_ms, waiting_tasks_count
        FROM sys.dm_os_wait_stats
        WHERE wait_time_ms > 0
          AND wait_type NOT IN (
            N'BROKER_EVENTHANDLER',N'BROKER_RECEIVE_WAITFOR',N'BROKER_TASK_STOP',N'BROKER_TO_FLUSH',
            N'BROKER_TRANSMITTER',N'CHECKPOINT_QUEUE',N'CHKPT',N'CLR_AUTO_EVENT',N'CLR_MANUAL_EVENT',
            N'CLR_SEMAPHORE',N'DBMIRROR_DBM_EVENT',N'DBMIRROR_EVENTS_QUEUE',N'DBMIRROR_WORKER_QUEUE',
            N'DBMIRRORING_CMD',N'DIRTY_PAGE_POLL',N'DISPATCHER_QUEUE_SEMAPHORE',N'EXECSYNC',N'FSAGENT',
            N'FT_IFTS_SCHEDULER_IDLE_WAIT',N'FT_IFTSHC_MUTEX',N'HADR_CLUSAPI_CALL',
            N'HADR_FILESTREAM_IOMGR_IOCOMPLETION',N'HADR_LOGCAPTURE_WAIT',N'HADR_NOTIFICATION_DEQUEUE',
            N'HADR_TIMER_TASK',N'HADR_WORK_QUEUE',N'KSOURCE_WAKEUP',N'LAZYWRITER_SLEEP',N'LOGMGR_QUEUE',
            N'MEMORY_ALLOCATION_EXT',N'ONDEMAND_TASK_QUEUE',N'PARALLEL_REDO_DRAIN_WORKER',
            N'PARALLEL_REDO_LOG_CACHE',N'PARALLEL_REDO_TRAN_LIST',N'PARALLEL_REDO_WORKER_SYNC',
            N'PARALLEL_REDO_WORKER_WAIT_WORK',N'PREEMPTIVE_XE_GETTARGETSTATE',N'PWAIT_ALL_COMPONENTS_INITIALIZED',
            N'PWAIT_DIRECTLOGCONSUMER_GETNEXT',N'QDS_PERSIST_TASK_MAIN_LOOP_SLEEP',N'QDS_ASYNC_QUEUE',
            N'QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP',N'QDS_SHUTDOWN_QUEUE',N'REDO_THREAD_PENDING_WORK',
            N'REQUEST_FOR_DEADLOCK_SEARCH',N'RESOURCE_QUEUE',N'SERVER_IDLE_CHECK',N'SLEEP_BPOOL_FLUSH',
            N'SLEEP_DBSTARTUP',N'SLEEP_DCOMSTARTUP',N'SLEEP_MASTERDBREADY',N'SLEEP_MASTERMDREADY',
            N'SLEEP_MASTERUPGRADED',N'SLEEP_MSDBSTARTUP',N'SLEEP_SYSTEMTASK',N'SLEEP_TASK',N'SLEEP_TEMPDBSTARTUP',
            N'SNI_HTTP_ACCEPT',N'SOS_WORK_DISPATCHER',N'SP_SERVER_DIAGNOSTICS_SLEEP',N'SQLTRACE_BUFFER_FLUSH',
            N'SQLTRACE_INCREMENTAL_FLUSH_SLEEP',N'SQLTRACE_WAIT_ENTRIES',N'UCS_SESSION_REGISTRATION',
            N'VDI_CLIENT_OTHER',N'WAIT_FOR_RESULTS',N'WAITFOR',N'WAITFOR_TASKSHUTDOWN',N'WAIT_XTP_RECOVERY',
            N'WAIT_XTP_HOST_WAIT',N'WAIT_XTP_OFFLINE_CKPT_NEW_LOG',N'WAIT_XTP_CKPT_CLOSE',
            N'XE_DISPATCHER_JOIN',N'XE_DISPATCHER_WAIT',N'XE_TIMER_EVENT',N'XE_LIVE_TARGET_TVF')
        ORDER BY wait_time_ms DESC;

        INSERT dbo.CollectLog (RunTs, Step, Status, DurationMs)
        VALUES (@now, 'SqlHealth', 'OK', DATEDIFF(MILLISECOND, @t0, SYSDATETIME()));
    END TRY
    BEGIN CATCH
        INSERT dbo.CollectLog (RunTs, Step, Status, DurationMs, Message)
        VALUES (@now, 'SqlHealth', 'ERROR', DATEDIFF(MILLISECOND, @t0, SYSDATETIME()), ERROR_MESSAGE());
    END CATCH;

    /* ---------------------------------------------------------------
       STEP 7  Payment gateway errors per web server (exceptionLog,
               counts only) - procedure from 07_alerts.sql
       --------------------------------------------------------------- */
    IF OBJECT_ID(N'dbo.usp_CollectGatewayErrors') IS NOT NULL
    BEGIN
        SET @t0 = SYSDATETIME();
        BEGIN TRY
            EXEC @rows = dbo.usp_CollectGatewayErrors @now = @now;
            INSERT dbo.CollectLog (RunTs, Step, Status, RowsAff, DurationMs, Message)
            VALUES (@now, 'GatewayErr', CASE WHEN @rows < 0 THEN 'SKIP' ELSE 'OK' END,
                    NULLIF(@rows, -1), DATEDIFF(MILLISECOND, @t0, SYSDATETIME()),
                    CASE WHEN @rows < 0 THEN N'GatewayErrorQuery not configured (run 07_alerts.sql)' END);
        END TRY
        BEGIN CATCH
            INSERT dbo.CollectLog (RunTs, Step, Status, DurationMs, Message)
            VALUES (@now, 'GatewayErr', 'ERROR', DATEDIFF(MILLISECOND, @t0, SYSDATETIME()), ERROR_MESSAGE());
        END CATCH;
    END;

    /* ---------------------------------------------------------------
       STEP 8  Alert rules + daily summary (07_alerts.sql).
               Runs last so it sees this run's data.
       --------------------------------------------------------------- */
    IF OBJECT_ID(N'dbo.usp_EvaluateAlerts') IS NOT NULL
    BEGIN
        SET @t0 = SYSDATETIME();
        BEGIN TRY
            EXEC @rows = dbo.usp_EvaluateAlerts @now = @now;
            INSERT dbo.CollectLog (RunTs, Step, Status, RowsAff, DurationMs, Message)
            VALUES (@now, 'Alerts', CASE WHEN @rows < 0 THEN 'SKIP' ELSE 'OK' END,
                    NULLIF(@rows, -1), DATEDIFF(MILLISECOND, @t0, SYSDATETIME()),
                    CASE WHEN @rows < 0 THEN N'AlertMode = Off' ELSE CONCAT(@rows, N' rule(s) firing') END);
        END TRY
        BEGIN CATCH
            INSERT dbo.CollectLog (RunTs, Step, Status, DurationMs, Message)
            VALUES (@now, 'Alerts', 'ERROR', DATEDIFF(MILLISECOND, @t0, SYSDATETIME()), ERROR_MESSAGE());
        END CATCH;
    END;

    IF OBJECT_ID(N'dbo.usp_SendDailySummary') IS NOT NULL
    BEGIN
        SET @t0 = SYSDATETIME();
        BEGIN TRY
            EXEC @rows = dbo.usp_SendDailySummary @now = @now;
            IF @rows = 1
                INSERT dbo.CollectLog (RunTs, Step, Status, DurationMs, Message)
                VALUES (@now, 'Summary', 'OK', DATEDIFF(MILLISECOND, @t0, SYSDATETIME()), N'Daily summary produced');
        END TRY
        BEGIN CATCH
            INSERT dbo.CollectLog (RunTs, Step, Status, DurationMs, Message)
            VALUES (@now, 'Summary', 'ERROR', DATEDIFF(MILLISECOND, @t0, SYSDATETIME()), ERROR_MESSAGE());
        END CATCH;
    END;

    /* ---------------------------------------------------------------
       STEP 6  Retention (cheap; once an hour)
       --------------------------------------------------------------- */
    IF DATEPART(MINUTE, @now) < 5
    BEGIN
        DECLARE @keep int = ISNULL(TRY_CAST((SELECT ConfigValue FROM dbo.Config
                                WHERE ConfigKey = N'RetentionDays') AS int), 400);
        DECLARE @cut datetime2(0) = DATEADD(DAY, -@keep, @now);
        DECLARE @cutShort datetime2(0) = DATEADD(DAY, -14, @now);   -- high-frequency snapshots
        DELETE TOP (50000) FROM dbo.PaymentTxn       WHERE TranTs < @cut;
        DELETE TOP (50000) FROM dbo.BillingProgress  WHERE SnapTs < @cut;
        DELETE TOP (50000) FROM dbo.JobRun           WHERE RunStart < @cut;
        DELETE TOP (50000) FROM dbo.LinkedServerPing WHERE PingTs < @cutShort;
        DELETE TOP (50000) FROM dbo.WebNodeSnapshot  WHERE SnapTs < @cutShort;
        DELETE TOP (50000) FROM dbo.AgSnapshot       WHERE SnapTs < @cutShort;
        DELETE TOP (50000) FROM dbo.InstanceSnapshot WHERE SnapTs < @cutShort;
        DELETE TOP (50000) FROM dbo.WaitSnapshot     WHERE SnapTs < @cutShort;
        DELETE TOP (50000) FROM dbo.CollectLog       WHERE RunTs  < @cutShort;
        IF OBJECT_ID(N'dbo.GatewayError') IS NOT NULL
            DELETE TOP (50000) FROM dbo.GatewayError WHERE BucketTs < @cut;
        IF OBJECT_ID(N'dbo.AlertLog') IS NOT NULL
            DELETE TOP (50000) FROM dbo.AlertLog     WHERE LogTs    < @cut;
    END;
END;
GO
