/* =====================================================================
   01_schema.sql  -  Billing cycle monitoring schema
   Target : NEW database billingdashboard via listener SFDBSLISTN01
            (created by install_billingdashboard.sql). Billing_V2 is never changed.
   Needs  : SQL Server 2016+ (FOR JSON, STRING_AGG not required)
   Safe to re-run: objects are created only if missing; config rows are
   inserted only if missing (your edits are kept).
   ===================================================================== */
USE billingdashboard;
GO

/* ---------- Configuration ------------------------------------------- */
IF OBJECT_ID(N'dbo.Config') IS NULL
CREATE TABLE dbo.Config (
    ConfigKey   sysname        NOT NULL CONSTRAINT PK_bd_Config PRIMARY KEY,
    ConfigValue nvarchar(max)  NOT NULL,
    Notes       nvarchar(500)  NULL
);
GO

/* Application codes as they appear in GEORGE -> friendly names */
IF OBJECT_ID(N'dbo.AppMap') IS NULL
CREATE TABLE dbo.AppMap (
    AppCode   nvarchar(50)  NOT NULL CONSTRAINT PK_bd_AppMap PRIMARY KEY,
    AppName   nvarchar(100) NOT NULL,
    SortOrder int           NOT NULL DEFAULT (99)
);
GO

/* Transaction status codes in GEORGE -> dashboard category */
IF OBJECT_ID(N'dbo.StatusMap') IS NULL
CREATE TABLE dbo.StatusMap (
    StatusCode  nvarchar(50)  NOT NULL CONSTRAINT PK_bd_StatusMap PRIMARY KEY,
    Category    varchar(20)   NOT NULL
        CONSTRAINT CK_bd_StatusMap_Cat CHECK (Category IN ('Completed','Failed','Pending','Cancelled')),
    Description nvarchar(200) NULL
);
GO

/* DMZ web servers -> zone */
IF OBJECT_ID(N'dbo.ZoneMap') IS NULL
CREATE TABLE dbo.ZoneMap (
    HostName sysname     NOT NULL CONSTRAINT PK_bd_ZoneMap PRIMARY KEY,
    Zone     varchar(30) NOT NULL
);
GO

/* ---------- Collected data ------------------------------------------ */
/* Local copy of recent GEORGE payment transactions (keeps dashboard
   queries off the linked server during peak load)                     */
IF OBJECT_ID(N'dbo.PaymentTxn') IS NULL
CREATE TABLE dbo.PaymentTxn (
    TranId       nvarchar(64)  NOT NULL CONSTRAINT PK_bd_PaymentTxn PRIMARY KEY,
    TranTs       datetime2(0)  NOT NULL,
    AppCode      nvarchar(50)  NULL,
    StatusCode   nvarchar(50)  NULL,
    Amount       decimal(12,2) NULL,
    ErrorCode    nvarchar(100) NULL,
    ErrorText    nvarchar(400) NULL,
    FirstSeenTs  datetime2(0)  NOT NULL DEFAULT (SYSDATETIME()),
    LastSeenTs   datetime2(0)  NOT NULL DEFAULT (SYSDATETIME())
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_bd_PaymentTxn_TranTs')
CREATE INDEX IX_bd_PaymentTxn_TranTs ON dbo.PaymentTxn (TranTs)
    INCLUDE (AppCode, StatusCode, Amount, ErrorCode);
GO

IF OBJECT_ID(N'dbo.BillingProgress') IS NULL
CREATE TABLE dbo.BillingProgress (
    SnapTs        datetime2(0)  NOT NULL CONSTRAINT PK_bd_BillingProgress PRIMARY KEY,
    MembersBilled int           NULL,
    MembersPaid   int           NULL,
    AmountBilled  decimal(14,2) NULL,
    AmountPaid    decimal(14,2) NULL
);
GO

IF OBJECT_ID(N'dbo.JobRun') IS NULL
CREATE TABLE dbo.JobRun (
    Source        varchar(20)    NOT NULL,     -- 'AppLog' (Billing_V2) or 'SQLAgent'
    JobName       nvarchar(200)  NOT NULL,
    RunStart      datetime2(0)   NOT NULL,
    RunEnd        datetime2(0)   NULL,
    Status        varchar(20)    NOT NULL,     -- Succeeded / Failed / Running
    RowsProcessed int            NULL,
    Message       nvarchar(1000) NULL,
    CONSTRAINT PK_bd_JobRun PRIMARY KEY (Source, JobName, RunStart)
);
GO

IF OBJECT_ID(N'dbo.LinkedServerPing') IS NULL
CREATE TABLE dbo.LinkedServerPing (
    PingTs       datetime2(0)  NOT NULL,
    LinkedServer sysname       NOT NULL,
    DurationMs   int           NULL,
    Success      bit           NOT NULL,
    ErrorText    nvarchar(400) NULL,
    CONSTRAINT PK_bd_LinkedServerPing PRIMARY KEY (PingTs, LinkedServer)
);
GO

IF OBJECT_ID(N'dbo.WebNodeSnapshot') IS NULL
CREATE TABLE dbo.WebNodeSnapshot (
    SnapTs         datetime2(0) NOT NULL,
    HostName       sysname      NOT NULL,
    ProgramName    nvarchar(128) NOT NULL,
    DbName         sysname      NOT NULL,
    Sessions       int          NOT NULL,
    ActiveRequests int          NOT NULL,
    CpuMs          bigint       NOT NULL,
    CONSTRAINT PK_bd_WebNodeSnapshot PRIMARY KEY (SnapTs, HostName, ProgramName, DbName)
);
GO

IF OBJECT_ID(N'dbo.AgSnapshot') IS NULL
CREATE TABLE dbo.AgSnapshot (
    SnapTs         datetime2(0) NOT NULL,
    AgName         sysname      NOT NULL,
    ReplicaServer  sysname      NOT NULL,
    DbName         sysname      NOT NULL,
    RoleDesc       varchar(20)  NULL,
    AvailMode      varchar(30)  NULL,
    SyncState      varchar(30)  NULL,
    SyncHealth     varchar(30)  NULL,
    LogSendQueueKb bigint       NULL,
    RedoQueueKb    bigint       NULL,
    CONSTRAINT PK_bd_AgSnapshot PRIMARY KEY (SnapTs, AgName, ReplicaServer, DbName)
);
GO

IF OBJECT_ID(N'dbo.InstanceSnapshot') IS NULL
CREATE TABLE dbo.InstanceSnapshot (
    SnapTs          datetime2(0) NOT NULL CONSTRAINT PK_bd_InstanceSnapshot PRIMARY KEY,
    ActiveRequests  int NOT NULL,
    BlockedSessions int NOT NULL,
    LongestBlockSec int NOT NULL
);
GO

/* Cumulative wait stats (top N each run); deltas computed at read time */
IF OBJECT_ID(N'dbo.WaitSnapshot') IS NULL
CREATE TABLE dbo.WaitSnapshot (
    SnapTs   datetime2(0) NOT NULL,
    WaitType nvarchar(60) NOT NULL,
    WaitMs   bigint       NOT NULL,
    Tasks    bigint       NOT NULL,
    CONSTRAINT PK_bd_WaitSnapshot PRIMARY KEY (SnapTs, WaitType)
);
GO

IF OBJECT_ID(N'dbo.CollectLog') IS NULL
CREATE TABLE dbo.CollectLog (
    LogId      int IDENTITY(1,1) NOT NULL CONSTRAINT PK_bd_CollectLog PRIMARY KEY,
    RunTs      datetime2(0)   NOT NULL,
    Step       varchar(40)    NOT NULL,
    Status     varchar(10)    NOT NULL,   -- OK / ERROR / SKIP
    RowsAff    int            NULL,
    DurationMs int            NULL,
    Message    nvarchar(2000) NULL
);
GO

/* =====================================================================
   Seed data - EDIT THESE after running 00a_discover_george.sql
   ===================================================================== */
MERGE dbo.Config AS t
USING (VALUES
 (N'CycleStart',        N'2027-01-01', N'First day of the billing cycle (local time)'),
 (N'CycleEnd',          N'2027-02-28', N'Last day of the billing cycle'),
 (N'GeorgeLinkedServer',N'George_PRDT', N'Linked server name used by OPENQUERY'),
 /* --- PRIMARY transaction source: local Billing_V2 tables ---------------
    T-SQL run in the billingdashboard database with parameter @since
    datetime2(0). Read Billing_V2 with three-part names (read only).
    Must return: TRAN_ID, TRAN_TS, APP_CODE, STATUS_CODE, AMOUNT,
                 ERROR_CODE, ERROR_TEXT (in that order).
    The final version comes from the 00b_discover_billing_v2.sql output.  */
 (N'LocalTxnQuery', N'SELECT CAST(t.<ID_COL> AS nvarchar(64)), t.<CREATED_COL>, CAST(a.<APP_CODE_COL> AS nvarchar(50)),
       CAST(t.<STATUS_ID_COL> AS nvarchar(50)), t.<AMOUNT_COL>,
       CAST(t.<REASON_ID_COL> AS nvarchar(100)), LEFT(r.<REASON_TEXT_COL>, 400)
FROM Billing_V2.dbo.[transaction] t WITH (NOLOCK)
LEFT JOIN Billing_V2.dbo.application a       ON a.<APP_ID_COL> = t.<APP_ID_COL>
LEFT JOIN Billing_V2.dbo.transactionReason r ON r.<REASON_ID_COL> = t.<REASON_ID_COL>
WHERE t.<CREATED_COL> >= @since OR t.<UPDATED_COL> >= @since', N'Online Payment Service transactions (Billing_V2.dbo.transaction)'),
 (N'BillingYear', N'2027', N'GEORGE billing year (BMBLYR / HPBLYR) being monitored'),
 (N'TxnLookbackHours',  N'6',  N'Each run re-reads this many hours of GEORGE transactions, so status changes (pending -> completed) are picked up'),

 /* --- The ONE query you must adapt -------------------------------------
    Runs on GEORGE (pass-through, DB2 SQL dialect). It must return exactly
    these 7 columns, in this order:
        TRAN_ID, TRAN_TS (timestamp), APP_CODE, STATUS_CODE, AMOUNT,
        ERROR_CODE, ERROR_TEXT
    Tokens replaced at run time:
        {SINCE_TS}    -> '2027-01-20-08.00.00'  (DB2 timestamp literal)
        {SINCE_DATE8} -> 20270120               (for YYYYMMDD numeric dates)
    If BMTRANP stores date and time as numbers (common on IBM i), build the
    timestamp with TIMESTAMP_FORMAT(DIGITS(dt)||DIGITS(tm),'YYYYMMDDHH24MISS')
    and filter on the date column with {SINCE_DATE8} so the index is used.  */
 (N'GeorgeTxnQuery', N'SELECT T.<TRAN_ID_COL>                         AS TRAN_ID,
       TIMESTAMP_FORMAT(DIGITS(T.<TRAN_DATE_COL>) || DIGITS(T.<TRAN_TIME_COL>), ''YYYYMMDDHH24MISS'') AS TRAN_TS,
       T.<SOURCE_APP_COL>                                  AS APP_CODE,
       T.<STATUS_COL>                                      AS STATUS_CODE,
       T.<AMOUNT_COL>                                      AS AMOUNT,
       T.<ERROR_CODE_COL>                                  AS ERROR_CODE,
       T.<ERROR_TEXT_COL>                                  AS ERROR_TEXT
FROM   PRDT.BMTRANP T
WHERE  T.<TRAN_DATE_COL> >= {SINCE_DATE8}', N'Pass-through query against BMTRANP (join BMADPNDP / BMCITMP here if status or app lives there)'),

 /* Billing progress: who has been billed vs who has paid (BMMASTP).
    Must return MEMBERS_BILLED, MEMBERS_PAID, AMOUNT_BILLED, AMOUNT_PAID.
    Set to an empty string to disable.                                    */
 (N'GeorgeProgressQuery', N'SELECT COUNT(*)                                              AS MEMBERS_BILLED,
       SUM(CASE WHEN M.<BALANCE_COL> <= 0 THEN 1 ELSE 0 END) AS MEMBERS_PAID,
       SUM(M.<BILLED_AMT_COL>)                               AS AMOUNT_BILLED,
       SUM(M.<PAID_AMT_COL>)                                 AS AMOUNT_PAID
FROM   PRDT.BMMASTP M
WHERE  M.<BILL_YEAR_COL> = {CYCLE_YEAR}', N'Runs every ProgressEveryMinutes'),
 (N'ProgressEveryMinutes', N'30', NULL),

 (N'GeorgePingQuery', N'SELECT 1 AS OK FROM SYSIBM.SYSDUMMY1', N'Cheap round-trip used to time the linked server'),

 /* .NET billing job log in Billing_V2 (local T-SQL). Must return
    JOB_NAME, RUN_START, RUN_END, STATUS (Succeeded/Failed/Running),
    ROWS_PROCESSED, MESSAGE. Empty string = disabled.                   */
 (N'AppJobLogQuery', N'SELECT TOP (200)
       L.<JOB_NAME_COL>   AS JOB_NAME,
       L.<START_COL>      AS RUN_START,
       L.<END_COL>        AS RUN_END,
       CASE WHEN L.<STATUS_COL> IN (''S'',''Success'') THEN ''Succeeded''
            WHEN L.<END_COL> IS NULL THEN ''Running'' ELSE ''Failed'' END AS STATUS,
       L.<ROWS_COL>       AS ROWS_PROCESSED,
       LEFT(L.<MSG_COL>, 1000) AS MESSAGE
FROM   Billing_V2.dbo.<JOB_LOG_TABLE> L WITH (NOLOCK)
WHERE  L.<START_COL> >= DATEADD(DAY, -2, SYSDATETIME())
ORDER BY L.<START_COL> DESC', N'Billing_V2 log table for the .NET payment jobs'),
 (N'AgentJobNameLike', N'%Billing%', N'SQL Agent jobs whose name matches are also shown. Empty = none'),

 /* Alert thresholds (used by the dashboard) */
 (N'FailRateWarnPct',      N'5',      NULL),
 (N'FailRateCritPct',      N'15',     NULL),
 (N'StuckPendingMinutes',  N'30',     N'Pending longer than this = stuck'),
 (N'PingWarnMs',           N'500',    NULL),
 (N'PingCritMs',           N'2000',   NULL),
 (N'RedoQueueWarnKb',      N'102400', NULL),
 (N'BlockWarnSec',         N'30',     NULL),
 (N'RetentionDays',        N'400',    N'Keeps last year''s cycle for comparison')
) AS s (ConfigKey, ConfigValue, Notes)
ON t.ConfigKey = s.ConfigKey
WHEN NOT MATCHED THEN INSERT (ConfigKey, ConfigValue, Notes) VALUES (s.ConfigKey, s.ConfigValue, s.Notes);
GO

MERGE dbo.ZoneMap AS t
USING (VALUES (N'SFWEBPRD11','Western'), (N'SFWEBPRD12','Western'),
              (N'SFWEBPRD13','Western'), (N'SFWEBPRD14','South Central')) AS s (HostName, Zone)
ON t.HostName = s.HostName
WHEN NOT MATCHED THEN INSERT (HostName, Zone) VALUES (s.HostName, s.Zone);
GO

/* Placeholder app codes - only loaded into an EMPTY table, so re-running
   this script never brings back placeholders after 06 has replaced them */
IF NOT EXISTS (SELECT 1 FROM dbo.AppMap)
MERGE dbo.AppMap AS t
USING (VALUES (N'MSBP', N'My State Bar Profile', 1),
              (N'AGB',  N'Agency Billing',        2),
              (N'COS',  N'Certificate of Standing',3),
              (N'CRS',  N'Course Registration',   4),
              (N'MAW',  N'Members Admin (internal)',5)) AS s (AppCode, AppName, SortOrder)
ON t.AppCode = s.AppCode
WHEN NOT MATCHED THEN INSERT (AppCode, AppName, SortOrder) VALUES (s.AppCode, s.AppName, s.SortOrder);
GO

/* Placeholder status codes - only loaded into an EMPTY table (see above) */
IF NOT EXISTS (SELECT 1 FROM dbo.StatusMap)
MERGE dbo.StatusMap AS t
USING (VALUES (N'C', 'Completed', N'Payment posted'),
              (N'F', 'Failed',    N'Payment failed'),
              (N'P', 'Pending',   N'Awaiting gateway response'),
              (N'X', 'Cancelled', N'Abandoned / cancelled by user')) AS s (StatusCode, Category, Description)
ON t.StatusCode = s.StatusCode
WHEN NOT MATCHED THEN INSERT (StatusCode, Category, Description) VALUES (s.StatusCode, s.Category, s.Description);
GO

/* =====================================================================
   PHASE 1 - proactive alerts (added 2026-11-14)
   Tables are used by 07_alerts.sql. Safe to re-run.
   ===================================================================== */

/* Gateway reason code -> System (our side / gateway / processor) or
   Customer (card declined, AVS, insufficient funds ...).
   Codes not listed count as Customer. Edit freely.                    */
IF OBJECT_ID(N'dbo.ReasonClass') IS NULL
CREATE TABLE dbo.ReasonClass (
    ReasonCode  nvarchar(100) NOT NULL CONSTRAINT PK_bd_ReasonClass PRIMARY KEY,
    Class       varchar(10)   NOT NULL
        CONSTRAINT CK_bd_ReasonClass_Class CHECK (Class IN ('System','Customer')),
    Description nvarchar(200) NULL
);
GO

/* Payment gateway errors per web server, 5-minute buckets.
   COUNTS ONLY - exceptionLog.Message holds names and addresses and is
   never stored; it is only scanned for the words timeout / connection. */
IF OBJECT_ID(N'dbo.GatewayError') IS NULL
CREATE TABLE dbo.GatewayError (
    BucketTs   datetime2(0) NOT NULL,
    HostName   sysname      NOT NULL,
    Kind       varchar(20)  NOT NULL,          -- Timeout / Connection / Other
    ErrorCount int          NOT NULL,
    CONSTRAINT PK_bd_GatewayError PRIMARY KEY (BucketTs, HostName, Kind)
);
GO

/* One row per alert rule: on/off, severity, who gets it, cooldown */
IF OBJECT_ID(N'dbo.AlertRule') IS NULL
CREATE TABLE dbo.AlertRule (
    RuleKey         varchar(40)   NOT NULL CONSTRAINT PK_bd_AlertRule PRIMARY KEY,
    Enabled         bit           NOT NULL DEFAULT (1),
    Severity        varchar(10)   NOT NULL
        CONSTRAINT CK_bd_AlertRule_Sev CHECK (Severity IN ('critical','serious','warning')),
    Audience        varchar(10)   NOT NULL DEFAULT ('IT')
        CONSTRAINT CK_bd_AlertRule_Aud CHECK (Audience IN ('IT','IT+MGMT')),
    CooldownMinutes int           NOT NULL DEFAULT (30),
    Title           nvarchar(100) NOT NULL,
    Description     nvarchar(500) NULL
);
GO

/* Current state per rule (drives cooldown and RESOLVED messages) */
IF OBJECT_ID(N'dbo.AlertState') IS NULL
CREATE TABLE dbo.AlertState (
    RuleKey      varchar(40)    NOT NULL CONSTRAINT PK_bd_AlertState PRIMARY KEY,
    IsActive     bit            NOT NULL DEFAULT (0),
    SinceTs      datetime2(0)   NULL,
    LastEvalTs   datetime2(0)   NULL,
    LastSentTs   datetime2(0)   NULL,
    LastSentKind varchar(10)    NULL,          -- RAISED / REMINDER / RESOLVED / SUMMARY
    LastValue    decimal(18,2)  NULL,
    Subject      nvarchar(200)  NULL,
    Detail       nvarchar(2000) NULL
);
GO

/* Every raise / reminder / resolve / daily summary, sent or not */
IF OBJECT_ID(N'dbo.AlertLog') IS NULL
CREATE TABLE dbo.AlertLog (
    AlertId    int IDENTITY(1,1) NOT NULL CONSTRAINT PK_bd_AlertLog PRIMARY KEY,
    LogTs      datetime2(0)   NOT NULL,
    RuleKey    varchar(40)    NOT NULL,
    Kind       varchar(10)    NOT NULL,        -- RAISED / REMINDER / RESOLVED / SUPPRESSED / SUMMARY
    Severity   varchar(10)    NULL,
    Subject    nvarchar(200)  NOT NULL,
    Detail     nvarchar(2000) NULL,
    Recipients nvarchar(1000) NULL,
    Sent       bit            NOT NULL DEFAULT (0),
    SendNote   nvarchar(400)  NULL,            -- LogOnly / mail item id / error text
    MailItemId int            NULL
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_bd_AlertLog_LogTs')
CREATE INDEX IX_bd_AlertLog_LogTs ON dbo.AlertLog (LogTs) INCLUDE (RuleKey, Kind, Severity);
GO

/* ---------- Phase 1 seed data (inserted only if missing) ------------ */
MERGE dbo.Config AS t
USING (VALUES
 (N'AlertMode',               N'LogOnly', N'Off = no evaluation; LogOnly = evaluate and record in AlertLog, no email; Send = email'),
 (N'MailProfile',             N'billingdashboard', N'Database Mail profile used by sp_send_dbmail (must exist on all 4 AG nodes)'),
 (N'AlertRecipientsIT',       N'', N'Semicolon-separated addresses for IT alerts'),
 (N'AlertRecipientsMgmt',     N'', N'Semicolon-separated addresses added for IT+MGMT rules and the daily summary'),
 (N'DashboardUrl',            N'http://azdbaprd01/billingdashboard/', N'Link placed in alert emails'),
 (N'QuietMinutes',            N'20',  N'NO_PAYMENTS: no completed payment for this many minutes'),
 (N'QuietBaselineWeeks',      N'4',   N'Baseline = same weekday and hour, averaged over this many previous weeks'),
 (N'QuietBaselinePct',        N'40',  N'LOW_VOLUME: completed in the last 60 min below this % of baseline'),
 (N'QuietMinBaselinePerHour', N'30',  N'Volume rules only run when the baseline expects at least this many completed payments per hour (keeps nights and weekends quiet)'),
 (N'SystemFailCount15m',      N'5',   N'SYSTEM_FAILURES: system-class failures in the last 15 minutes'),
 (N'DeclineMinAttempts60m',   N'30',  N'DECLINE_RATE: only evaluated with at least this many attempts in 60 min (uses FailRateCritPct)'),
 (N'GatewayErrCount15m',      N'10',  N'GATEWAY_ERRORS: exceptionLog rows from one web server in the last 15 minutes'),
 (N'StuckAlertCount',         N'5',   N'STUCK_PENDING: at least this many payments pending longer than StuckPendingMinutes'),
 (N'GeorgeDownPings',         N'3',   N'GEORGE_DOWN: this many consecutive failed linked-server pings'),
 (N'AlertAgDatabases',        N'Billing_V2,billingdashboard', N'AG_UNHEALTHY watches these databases only'),
 (N'SummaryTime',             N'08:30', N'Daily summary send time (after the 08:00 card/ACH reports and ~08:15 GEORGE posting)'),
 (N'GatewayErrorQuery',       N'',    N'Set by 07_alerts.sql from the exceptionLog columns. Returns BUCKET_TS, HOST_NAME, KIND, ERROR_COUNT')
) AS s (ConfigKey, ConfigValue, Notes)
ON t.ConfigKey = s.ConfigKey
WHEN NOT MATCHED THEN INSERT (ConfigKey, ConfigValue, Notes) VALUES (s.ConfigKey, s.ConfigValue, s.Notes);
GO

/* CyberSource reason codes that mean "our side / gateway / processor" */
MERGE dbo.ReasonClass AS t
USING (VALUES
 (N'150',       'System',   N'General system failure (gateway)'),
 (N'151',       'System',   N'Server timeout (gateway)'),
 (N'152',       'System',   N'Service did not finish in time (gateway)'),
 (N'207',       'System',   N'Issuing bank unavailable'),
 (N'236',       'System',   N'Processor failure'),
 (N'250',       'System',   N'Timeout at the payment processor'),
 (N'(no code)', 'System',   N'Failed with no gateway reason code'),
 (N'RETURNED',  'Customer', N'Accepted, later rejected (ACH return / settlement)')
) AS s (ReasonCode, Class, Description)
ON t.ReasonCode = s.ReasonCode
WHEN NOT MATCHED THEN INSERT (ReasonCode, Class, Description) VALUES (s.ReasonCode, s.Class, s.Description);
GO

MERGE dbo.AlertRule AS t
USING (VALUES
 ('NO_PAYMENTS',       'critical', 'IT+MGMT', 30, N'No completed payments',
      N'No completed payment for QuietMinutes while the 4-week baseline for this hour expects at least QuietMinBaselinePerHour'),
 ('LOW_VOLUME',        'warning',  'IT',      60, N'Payment volume unusually low',
      N'Completed payments in the last 60 min below QuietBaselinePct % of the same hour in previous weeks'),
 ('SYSTEM_FAILURES',   'critical', 'IT+MGMT', 30, N'System payment failures',
      N'Gateway / processor failures (ReasonClass = System) in the last 15 min at or above SystemFailCount15m'),
 ('DECLINE_RATE',      'warning',  'IT',      60, N'High customer decline rate',
      N'Customer declines in the last 60 min at or above FailRateCritPct % (possible card testing or an issuer problem)'),
 ('GATEWAY_ERRORS',    'serious',  'IT',      30, N'Payment gateway errors on a web server',
      N'exceptionLog rows from one web server in the last 15 min at or above GatewayErrCount15m'),
 ('STUCK_PENDING',     'serious',  'IT',      60, N'Payments stuck in pending',
      N'At least StuckAlertCount payments pending longer than StuckPendingMinutes'),
 ('GEORGE_DOWN',       'critical', 'IT',      30, N'GEORGE linked server not responding',
      N'GeorgeDownPings consecutive failed pings of the linked server'),
 ('AG_UNHEALTHY',      'critical', 'IT',      30, N'Availability group not healthy',
      N'A replica of a database in AlertAgDatabases is not HEALTHY'),
 ('COLLECTOR_FAILING', 'serious',  'IT',      60, N'Payment collector failing',
      N'The last 3 reads of Billing_V2 payment transactions failed'),
 ('DAILY_SUMMARY',     'warning',  'IT',    1440, N'Daily billing summary',
      N'Sent once a day at SummaryTime. Change Audience to IT+MGMT to include management')
) AS s (RuleKey, Severity, Audience, CooldownMinutes, Title, Description)
ON t.RuleKey = s.RuleKey
WHEN NOT MATCHED THEN INSERT (RuleKey, Severity, Audience, CooldownMinutes, Title, Description)
                      VALUES (s.RuleKey, s.Severity, s.Audience, s.CooldownMinutes, s.Title, s.Description);
GO
