[CmdletBinding()]
param
(
    [string]$RepositoryServer = 'LASQLCL3\ODYDEV',
    [string]$RepositoryDatabase = 'CALBAR_SQL_CIS',
    [string]$LogFolder = 'E:\CALBarCISGovernance\Runner\Logs',
    [string]$ServerName,
    [string]$ControlCode,
    [int]$QueryTimeoutSeconds = 60,
    [int]$ConnectionTimeoutSeconds = 10,
    [switch]$IncludeOptionalControls
)

$ErrorActionPreference = 'Stop'
Import-Module SqlServer -ErrorAction Stop
New-Item -Path $LogFolder -ItemType Directory -Force | Out-Null

$LogFile = Join-Path $LogFolder ("CISRunner_{0:yyyyMMdd_HHmmss}.log" -f (Get-Date))
Start-Transcript -Path $LogFile -Append

function ConvertFrom-DbValue
{
    param([AllowNull()][object]$Value)

    if ($null -eq $Value -or $Value -is [System.DBNull])
    {
        return $null
    }

    return $Value
}

function ConvertTo-SqlUnicodeLiteral
{
    param
    (
        [AllowNull()][object]$Value,
        [int]$MaximumLength = 4000
    )

    $cleanValue = ConvertFrom-DbValue -Value $Value

    if ($null -eq $cleanValue)
    {
        return 'NULL'
    }

    $text = [string]$cleanValue

    if ($text.Length -gt $MaximumLength)
    {
        $text = $text.Substring(0, $MaximumLength)
    }

    return "N'" + $text.Replace("'", "''") + "'"
}

function Get-FirstDataRow
{
    param([AllowNull()][object]$Result)

    if ($null -eq $Result)
    {
        return $null
    }

    return @($Result) | Select-Object -First 1
}

function Get-ScalarValue
{
    param([AllowNull()][object]$Result)

    $row = Get-FirstDataRow -Result $Result

    if ($null -eq $row)
    {
        return $null
    }

    $actualProperty = $row.PSObject.Properties['ActualValue']

    if ($null -ne $actualProperty)
    {
        return ConvertFrom-DbValue -Value $actualProperty.Value
    }

    $property = $row.PSObject.Properties |
        Where-Object {
            $_.Name -notin @('RowError','RowState','Table','ItemArray','HasErrors')
        } |
        Select-Object -First 1

    if ($null -eq $property)
    {
        return $null
    }

    return ConvertFrom-DbValue -Value $property.Value
}

function Invoke-CalBarSql
{
    param
    (
        [Parameter(Mandatory)][string]$ServerInstance,
        [string]$Database = 'master',
        [Parameter(Mandatory)][string]$Query,
        [int]$QueryTimeout = 60
    )

    $command = Get-Command Invoke-Sqlcmd -ErrorAction Stop

    $parameters = @{
        ServerInstance         = $ServerInstance
        Database               = $Database
        Query                  = $Query
        ErrorAction            = 'Stop'
    }

    if ($command.Parameters.ContainsKey('TrustServerCertificate'))
    {
        $parameters.TrustServerCertificate = $true
    }

    if ($command.Parameters.ContainsKey('QueryTimeout'))
    {
        $parameters.QueryTimeout = $QueryTimeout
    }

    if ($command.Parameters.ContainsKey('ConnectionTimeout'))
    {
        $parameters.ConnectionTimeout = $ConnectionTimeoutSeconds
    }

    Invoke-Sqlcmd @parameters
}

function ConvertTo-NullableInt
{
    param([AllowNull()][object]$Value)

    $clean = ConvertFrom-DbValue -Value $Value

    if ($null -eq $clean -or [string]::IsNullOrWhiteSpace([string]$clean))
    {
        return $null
    }

    $parsed = 0

    if (-not [int]::TryParse(([string]$clean).Trim(), [ref]$parsed))
    {
        throw "Value '$clean' cannot be converted to Int32."
    }

    return $parsed
}

function Test-ControlResult
{
    param
    (
        [Parameter(Mandatory)][string]$CheckType,
        [AllowNull()][object]$ActualValue,
        [AllowNull()][object]$ExpectedValue
    )

    $actual = if ($null -eq (ConvertFrom-DbValue $ActualValue)) { $null } else { ([string]$ActualValue).Trim() }
    $expected = if ($null -eq (ConvertFrom-DbValue $ExpectedValue)) { $null } else { ([string]$ExpectedValue).Trim() }

    if ([string]::IsNullOrWhiteSpace($actual))
    {
        throw 'The check returned NULL or blank ActualValue.'
    }

    if ([string]::IsNullOrWhiteSpace($expected))
    {
        throw 'ExpectedValue is NULL or blank.'
    }

    switch ($CheckType.Trim().ToUpperInvariant())
    {
        'MINIMUM'
        {
            $actualNumber = [decimal]0
            $expectedNumber = [decimal]0

            if (-not [decimal]::TryParse($actual, [ref]$actualNumber))
            {
                throw "ActualValue '$actual' is not numeric."
            }

            if (-not [decimal]::TryParse($expected, [ref]$expectedNumber))
            {
                throw "ExpectedValue '$expected' is not numeric."
            }

            return ($actualNumber -ge $expectedNumber)
        }

        'MAXIMUM'
        {
            $actualNumber = [decimal]0
            $expectedNumber = [decimal]0

            if (-not [decimal]::TryParse($actual, [ref]$actualNumber))
            {
                throw "ActualValue '$actual' is not numeric."
            }

            if (-not [decimal]::TryParse($expected, [ref]$expectedNumber))
            {
                throw "ExpectedValue '$expected' is not numeric."
            }

            return ($actualNumber -le $expectedNumber)
        }

        'SET'
        {
            $allowed = @(
                $expected -split ',' |
                ForEach-Object { $_.Trim() } |
                Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
            )

            return ($allowed -contains $actual)
        }

        default
        {
            return ($actual -eq $expected)
        }
    }
}

function Write-ServerConnectionError
{
    param
    (
        [long]$RunId,
        [int]$ServerId,
        [Parameter(Mandatory)][string]$ServerInstance,
        [Parameter(Mandatory)][string]$ErrorCategory,
        [AllowNull()][string]$ErrorMessage
    )

    $instanceSql = ConvertTo-SqlUnicodeLiteral -Value $ServerInstance -MaximumLength 256
    $categorySql = ConvertTo-SqlUnicodeLiteral -Value $ErrorCategory -MaximumLength 50
    $errorSql = ConvertTo-SqlUnicodeLiteral -Value $ErrorMessage

    $insert = @"
INSERT audit.CIS_Server_Connection_Error
(
    RunId,
    ServerId,
    ServerInstance,
    ErrorCategory,
    ErrorMessage
)
VALUES
(
    $RunId,
    $ServerId,
    $instanceSql,
    $categorySql,
    $errorSql
);
"@

    Invoke-CalBarSql `
        -ServerInstance $RepositoryServer `
        -Database $RepositoryDatabase `
        -Query $insert `
        -QueryTimeout $QueryTimeoutSeconds | Out-Null
}

function Write-ComplianceResult
{
    param
    (
        [long]$RunId,
        [int]$ServerId,
        [int]$ControlId,
        [string]$Status,
        [AllowNull()][object]$ActualValue,
        [AllowNull()][object]$ExpectedValue,
        [AllowNull()][string]$ErrorMessage
    )

    $actualSql = ConvertTo-SqlUnicodeLiteral -Value $ActualValue
    $expectedSql = ConvertTo-SqlUnicodeLiteral -Value $ExpectedValue -MaximumLength 100
    $errorSql = ConvertTo-SqlUnicodeLiteral -Value $ErrorMessage

    $insert = @"
INSERT audit.CIS_Compliance_Result
(
    RunId, ServerId, ControlId, Status,
    ActualValue, ExpectedValue, ErrorMessage
)
VALUES
(
    $RunId, $ServerId, $ControlId, '$Status',
    $actualSql, $expectedSql, $errorSql
);
"@

    Invoke-CalBarSql `
        -ServerInstance $RepositoryServer `
        -Database $RepositoryDatabase `
        -Query $insert `
        -QueryTimeout $QueryTimeoutSeconds | Out-Null
}

$runId = $null

try
{
    $runResult = Invoke-CalBarSql `
        -ServerInstance $RepositoryServer `
        -Database $RepositoryDatabase `
        -Query @"
INSERT audit.CIS_Run(StartedBy)
OUTPUT inserted.RunId
VALUES(SUSER_SNAME());
"@ `
        -QueryTimeout $QueryTimeoutSeconds

    $runIdValue = Get-ScalarValue -Result $runResult

    if ($null -eq $runIdValue)
    {
        throw 'Repository did not return a RunId.'
    }

    $runId = [long]$runIdValue

    $serverFilter = ''

    if (-not [string]::IsNullOrWhiteSpace($ServerName))
    {
        $safeServer = $ServerName.Replace("'","''")
        $serverFilter = " AND ServerInstance = N'$safeServer'"
    }

    $servers = @(
        Invoke-CalBarSql `
            -ServerInstance $RepositoryServer `
            -Database $RepositoryDatabase `
            -Query @"
SELECT ServerId, ServerInstance
FROM inv.SQL_Server_Inventory
WHERE IsEnabled = 1
$serverFilter
ORDER BY ServerInstance;
"@ `
            -QueryTimeout $QueryTimeoutSeconds
    )

    $controlFilter = ''

    if (-not [string]::IsNullOrWhiteSpace($ControlCode))
    {
        $safeControl = $ControlCode.Replace("'","''")
        $controlFilter += " AND ControlCode = '$safeControl'"
    }

    if (-not $IncludeOptionalControls.IsPresent)
    {
        $controlFilter += " AND ISNULL(IsOptional,0) = 0"
    }

    $controls = @(
        Invoke-CalBarSql `
            -ServerInstance $RepositoryServer `
            -Database $RepositoryDatabase `
            -Query @"
SELECT
    ControlId,
    ControlCode,
    ControlName,
    ExpectedValue,
    CheckType,
    CheckQuery,
    MinimumMajorVersion,
    ISNULL(IsOptional,0) AS IsOptional
FROM cfg.CIS_Control_Definition
WHERE IsEnabled = 1
$controlFilter
ORDER BY SortOrder, ControlCode;
"@ `
            -QueryTimeout $QueryTimeoutSeconds
    )

    Write-Host "RunId: $runId"
    Write-Host "Servers selected: $($servers.Count)"
    Write-Host "Controls selected: $($controls.Count)"

    if ($servers.Count -eq 0)
    {
        throw 'No enabled inventory servers were selected.'
    }

    if ($controls.Count -eq 0)
    {
        throw 'No enabled controls were selected.'
    }

    $resultCount = 0
    $connectionFailureCount = 0

    foreach ($server in $servers)
    {
        $serverId = ConvertTo-NullableInt -Value $server.ServerId
        $targetInstance = ([string](ConvertFrom-DbValue $server.ServerInstance)).Trim()

        Write-Host ''
        Write-Host "Scanning $targetInstance"

        $majorVersion = $null

        try
        {
            $versionResult = Invoke-CalBarSql `
                -ServerInstance $targetInstance `
                -Database 'master' `
                -Query "SELECT CONVERT(int,SERVERPROPERTY('ProductMajorVersion')) AS ActualValue;" `
                -QueryTimeout 20

            $majorVersion = ConvertTo-NullableInt -Value (Get-ScalarValue -Result $versionResult)

            if ($null -eq $majorVersion)
            {
                throw 'Connected to SQL Server, but ProductMajorVersion returned NULL.'
            }

            Write-Host "  Connected. SQL major version: $majorVersion"
        }
        catch
        {
            $connectionError = $_.Exception.Message
            $errorCategory = if ($connectionError -match 'Login failed|authentication|principal') {
                'AuthenticationFailed'
            }
            elseif ($connectionError -match 'network-related|instance-specific|server was not found|actively refused|timeout|timed out|error: 26|error: 40|No such host') {
                'ConnectionFailed'
            }
            else {
                'ConnectionOrVersionCheckFailed'
            }

            Write-Host "  Server unavailable. Logging one connection failure and skipping all controls."
            Write-Host "  Error: $connectionError"

            Write-ServerConnectionError `
                -RunId $runId `
                -ServerId $serverId `
                -ServerInstance $targetInstance `
                -ErrorCategory $errorCategory `
                -ErrorMessage $connectionError

            $connectionFailureCount++
            continue
        }

        foreach ($control in $controls)
        {
            $controlId = ConvertTo-NullableInt -Value $control.ControlId
            $code = [string](ConvertFrom-DbValue $control.ControlCode)
            $name = [string](ConvertFrom-DbValue $control.ControlName)
            $expected = ConvertFrom-DbValue $control.ExpectedValue
            $status = 'ERROR'
            $actual = $null
            $errorMessage = $null

            try
            {
                $minimumVersion = ConvertTo-NullableInt -Value $control.MinimumMajorVersion

                if ($null -ne $minimumVersion -and $majorVersion -lt $minimumVersion)
                {
                    $status = 'SKIP'
                    $actual = "Not applicable to SQL major version $majorVersion"
                }
                else
                {
                    $checkQuery = [string](ConvertFrom-DbValue $control.CheckQuery)

                    if ([string]::IsNullOrWhiteSpace($checkQuery))
                    {
                        throw 'CheckQuery is NULL or blank.'
                    }

                    $checkResult = Invoke-CalBarSql `
                        -ServerInstance $targetInstance `
                        -Database 'master' `
                        -Query $checkQuery `
                        -QueryTimeout $QueryTimeoutSeconds

                    $actual = Get-ScalarValue -Result $checkResult

                    $isCompliant = Test-ControlResult `
                        -CheckType ([string]$control.CheckType) `
                        -ActualValue $actual `
                        -ExpectedValue $expected

                    $status = if ($isCompliant) { 'PASS' } else { 'FAIL' }
                }
            }
            catch
            {
                $status = 'ERROR'
                $errorMessage = $_.Exception.Message
            }

            Write-ComplianceResult `
                -RunId $runId `
                -ServerId $serverId `
                -ControlId $controlId `
                -Status $status `
                -ActualValue $actual `
                -ExpectedValue $expected `
                -ErrorMessage $errorMessage

            $resultCount++
            Write-Host "  $code - $name : $status; Actual=$actual Expected=$expected"

            if ($errorMessage)
            {
                Write-Host "      Error: $errorMessage"
            }
        }
    }

    $serverCount = $servers.Count

    Invoke-CalBarSql `
        -ServerInstance $RepositoryServer `
        -Database $RepositoryDatabase `
        -Query @"
UPDATE audit.CIS_Run
SET
    CompletedAtUtc = SYSUTCDATETIME(),
    ServerCount = $serverCount,
    ResultCount = $resultCount,
    RunStatus = 'COMPLETED'
WHERE RunId = $runId;
"@ `
        -QueryTimeout $QueryTimeoutSeconds | Out-Null

    Write-Host ''
    Write-Host "Completed run $runId with $resultCount control results across $serverCount selected servers."
    Write-Host "Server connection failures logged: $connectionFailureCount"
}
catch
{
    if ($null -ne $runId)
    {
        Invoke-CalBarSql `
            -ServerInstance $RepositoryServer `
            -Database $RepositoryDatabase `
            -Query @"
UPDATE audit.CIS_Run
SET
    CompletedAtUtc = SYSUTCDATETIME(),
    RunStatus = 'FAILED'
WHERE RunId = $runId;
"@ `
            -QueryTimeout $QueryTimeoutSeconds | Out-Null
    }

    throw
}
finally
{
    Stop-Transcript
}
