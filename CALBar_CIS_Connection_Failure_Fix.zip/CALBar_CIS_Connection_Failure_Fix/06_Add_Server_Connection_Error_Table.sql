USE CALBAR_SQL_CIS;
GO

IF OBJECT_ID(N'audit.CIS_Server_Connection_Error', N'U') IS NULL
BEGIN
    CREATE TABLE audit.CIS_Server_Connection_Error
    (
        ConnectionErrorId BIGINT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_CIS_Server_Connection_Error PRIMARY KEY,
        RunId BIGINT NOT NULL,
        ServerId INT NOT NULL,
        ServerInstance NVARCHAR(256) NOT NULL,
        ErrorCategory VARCHAR(50) NOT NULL,
        ErrorMessage NVARCHAR(4000) NULL,
        AttemptedAtUtc DATETIME2(0) NOT NULL
            CONSTRAINT DF_CIS_Server_Connection_Error_AttemptedAtUtc
            DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_CIS_Server_Connection_Error_Run
            FOREIGN KEY (RunId) REFERENCES audit.CIS_Run(RunId),
        CONSTRAINT FK_CIS_Server_Connection_Error_Server
            FOREIGN KEY (ServerId) REFERENCES inv.SQL_Server_Inventory(ServerId)
    );
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'audit.CIS_Server_Connection_Error')
      AND name = N'IX_CIS_Server_Connection_Error_RunId'
)
BEGIN
    CREATE INDEX IX_CIS_Server_Connection_Error_RunId
        ON audit.CIS_Server_Connection_Error(RunId, ServerId);
END;
GO

CREATE OR ALTER VIEW rpt.vw_CIS_Latest_Server_Connection_Error
AS
WITH RankedErrors AS
(
    SELECT
        e.ConnectionErrorId,
        e.RunId,
        e.ServerId,
        e.ServerInstance,
        e.ErrorCategory,
        e.ErrorMessage,
        e.AttemptedAtUtc,
        rn = ROW_NUMBER() OVER
        (
            PARTITION BY e.ServerId
            ORDER BY e.AttemptedAtUtc DESC, e.ConnectionErrorId DESC
        )
    FROM audit.CIS_Server_Connection_Error AS e
)
SELECT
    ConnectionErrorId,
    RunId,
    ServerId,
    ServerInstance,
    ErrorCategory,
    ErrorMessage,
    AttemptedAtUtc
FROM RankedErrors
WHERE rn = 1;
GO
