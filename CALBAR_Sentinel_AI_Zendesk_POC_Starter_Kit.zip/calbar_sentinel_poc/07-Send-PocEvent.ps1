#requires -Version 5.1
<#
.SYNOPSIS
Send a bounded synthetic event to the protected POC ingress endpoint.
The callback URL may contain a secret. Set CBAR_POC_INGRESS_URL securely;
this script does not print it. Do not include it in committed files or logs.
A repeated invocation with the same episode and state must not create another ticket.
#>
[CmdletBinding()]
param(
    [ValidatePattern('^[A-Za-z0-9_-]{1,60}$')][string]$SourceInstance='CALBAR-SW-POC',
    [ValidatePattern('^[0-9]{1,20}$')][string]$AlertRuleId='101',
    [ValidatePattern('^[0-9]{1,20}$')][string]$AlertObjectId='1001',
    [ValidatePattern('^[0-9]{1,20}$')][string]$SourceOccurrenceId=([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds().ToString()),
    [ValidateSet('triggered','reset')][string]$EventType='triggered',
    [ValidateRange(1,100)][int]$Repeat=1,
    [ValidateLength(0,2000)][string]$SourceSummary='Synthetic POC test. No production outage.'
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$url=$env:CBAR_POC_INGRESS_URL
if ([string]::IsNullOrWhiteSpace($url)) { throw 'Set CBAR_POC_INGRESS_URL to the approved callback URL before running.' }
$uri=$null
if (-not [Uri]::TryCreate($url,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -ne 'https') {
    throw 'POC ingress must use a valid HTTPS URL.'
}
if ($PSVersionTable.PSVersion.Major -lt 6) {
    [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
}
$payload=[ordered]@{
    SourceInstance=$SourceInstance; AlertRuleId=$AlertRuleId; AlertObjectId=$AlertObjectId
    SourceOccurrenceId=$SourceOccurrenceId; EventType=$EventType; SourceSummary=$SourceSummary
}
$body=$payload | ConvertTo-Json -Compress
$episode="$SourceInstance|$AlertRuleId|$AlertObjectId|$SourceOccurrenceId"
for($i=1;$i -le $Repeat;$i++) {
    try {
        $r=Invoke-WebRequest -Uri $url -Method Post -ContentType 'application/json' `
            -Body ([Text.Encoding]::UTF8.GetBytes($body)) -UseBasicParsing -TimeoutSec 60
        if ([int]$r.StatusCode -ne 202) { throw 'Ingress did not return HTTP 202.' }
        [pscustomobject]@{EpisodeKey=$episode; EventType=$EventType; Delivery=$i; HttpStatus=[int]$r.StatusCode}
    } catch {
        # Do not emit the URL-bearing exception or silently retry an uncertain send.
        throw "Delivery $i failed or had an uncertain outcome. Check protected workflow logs. Episode: $episode"
    }
}
