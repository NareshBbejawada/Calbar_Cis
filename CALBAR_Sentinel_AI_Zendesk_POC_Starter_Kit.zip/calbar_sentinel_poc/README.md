# CALBAR SolarWinds -> Sentinel -> AI -> Zendesk POC starter kit
Prepared 2026-10-31. Proposed design; no resources have been deployed.

## Scope and safety
Use 3 nonproduction hosts and two selected conditions. Preserve existing SolarWinds
notifications. Start with synthetic data and shadow mode. Do not ingest the full 30,000
notifications/day into this POC. AI is advisory; policy decides ticket creation and owner.
A 25-create-attempt guard is included in SQL. Approved government hosting and approved
Zendesk data transfer are prerequisites; hosting in Azure Government does not place
Zendesk within Microsoft's government service boundary.

## Files and order
1. Provision an isolated approved resource group, Sentinel-enabled Log Analytics
   workspace, Logic Apps Standard with runtime storage, Service Bus queue, SQL database,
   Key Vault and approved Azure Government model deployment.
2. Install `11-poc-state.sql` in a fresh POC database. Replace Zendesk IDs only after
   admin approval. Keep TicketWritesEnabled=0. Configure managed identity access.
3. Use `02-table-sample.json` to create `CALBARMonitoringEvents_CL` on Analytics plan
   and its DCR/DCE. The example timestamp is for schema only; do not ingest stale samples.
4. Build the workflows using `14-workflow-build-notes.md`. This is manual assembly,
   not an ARM/Bicep or full workflow deployment package.
5. Validate ingestion with `07-Send-PocEvent.ps1` and `04-validation-queries.kql`.
6. Build the candidate rule using `03-analytics-rule.kql` and scoped automation rules.
7. Deploy a government-available chat model such as approved gpt-4.1-mini. Copy its
   own Chat Completions endpoint from View Code. `10-ai-request-example.json` assumes
   v1 Chat Completions with model=cbar-alert-triage-poc. Endpoint/auth must match your
   resource. For a different API shape use its generated sample; do not mix API routes.
8. Record shadow AI suggestions using files 05 and 06. API JSON mode isn't schema
   enforcement; validate the returned content in the workflow.
9. After review, enable SQL writes and PolicyWithAISummary mode. Send fresh episodes.
10. Add scoped real SolarWinds trigger/reset actions using file 09. Set reset EventType
    to reset. Verify installed product/version and occurrence IDs, especially resets.
11. Complete all acceptance tests in file 13 and review SQL queries in file 12.

## Synthetic tests
Set CBAR_POC_INGRESS_URL through an approved secure method; signed callback URLs are secrets.

```powershell
# New trigger, then duplicate deliveries for the exact same episode.
.\07-Send-PocEvent.ps1 -SourceOccurrenceId 10001
.\07-Send-PocEvent.ps1 -SourceOccurrenceId 10001 -Repeat 20
# Recovery for that episode; run after successful ticket creation in write mode.
.\07-Send-PocEvent.ps1 -SourceOccurrenceId 10001 -EventType reset
# Different condition on same synthetic host.
.\07-Send-PocEvent.ps1 -AlertRuleId 102 -AlertObjectId 1002 -SourceOccurrenceId 10002
# Approved informational policy.
.\07-Send-PocEvent.ps1 -AlertRuleId 103 -AlertObjectId 1003 -SourceOccurrenceId 10003
# Unknown route from authenticated allowed source -> review/triage.
.\07-Send-PocEvent.ps1 -AlertRuleId 999 -AlertObjectId 1001 -SourceOccurrenceId 10004
```

## Validation performed for this kit
JSON and JSON-schema files and sample consistency were checked locally. No Azure,
SolarWinds, Zendesk, PowerShell runtime or SQL Server deployment was available for
end-to-end execution. Review and test T-SQL, PowerShell, KQL and workflow bindings in
an isolated environment before use. This kit is not production-certified.

## Government-specific inputs to record
Tenant/subscription, region, workspace ID, Logic App identity/object ID, Service Bus
namespace, DCE ingestion endpoint, DCR immutable ID, exact input stream name, SQL server
and database, model inference endpoint/deployment/version, Zendesk subdomain and group
IDs, monitoring requester ID, pilot source/rule/object mappings, security-approved data.
Do not commit credentials or callback URLs to version control.

## Official references reviewed
- https://learn.microsoft.com/en-us/azure/sentinel/feature-availability
- https://learn.microsoft.com/en-us/azure/foundry/concepts/foundry-azure-government
- https://learn.microsoft.com/en-us/azure/ai-services/openai/azure-government/
- https://learn.microsoft.com/en-us/azure/azure-monitor/logs/tutorial-logs-ingestion-portal
- https://learn.microsoft.com/en-us/azure/azure-monitor/logs/logs-ingestion-api-overview
- https://learn.microsoft.com/en-us/azure/sentinel/create-analytics-rules
- https://learn.microsoft.com/en-us/azure/sentinel/scheduled-rules-overview
- https://learn.microsoft.com/en-us/azure/sentinel/automation/create-playbooks
- https://learn.microsoft.com/en-us/azure/sentinel/automation/run-playbooks
- https://learn.microsoft.com/en-us/connectors/azuresentinel/
- https://learn.microsoft.com/en-us/azure/logic-apps/connectors/built-in/reference/servicebus/
- https://documentation.solarwinds.com/en/success_center/orionplatform/content/core-using-get-or-post-url-functions-sw1058.htm
- https://documentation.solarwinds.com/en/success_center/incident-response/content/integrations/alert-source-integrations-native/solarwinds-observability-self-hosted.htm
- https://developer.zendesk.com/api-reference/ticketing/tickets/tickets/
- https://developer.zendesk.com/api-reference/ticketing/introduction/

## Private-network warning
Sentinel managed webhook callbacks and private-only inbound Logic Apps require
special treatment. See workflow notes before disabling public access. Separate
ingress and playbook resources when their network policies differ; assign each
identity only the permissions its workflows need.
