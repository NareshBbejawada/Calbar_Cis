-- Runtime state, including shadow/no-ticket decisions.
SELECT EpisodeKey,EventType,DecisionId,Status,FinalAction,TicketId,
       CreatedUtc,UpdatedUtc,FirstAttemptUtc,ReviewReason,AIResult,Evidence
FROM poc.Decision ORDER BY CreatedUtc DESC;

-- Review every uncertain or stalled action; do not delete its claim to force a retry.
SELECT * FROM poc.Decision
WHERE Status='NeedsReview'
   OR (Status IN ('Claimed','Ready','Attempting') AND UpdatedUtc<DATEADD(minute,-10,SYSUTCDATETIME()));

-- Budget and outbound switch.
SELECT * FROM poc.Config;

-- Check pilot mappings before live ticket writes.
SELECT * FROM poc.Route WHERE ZendeskGroupId IS NULL;
