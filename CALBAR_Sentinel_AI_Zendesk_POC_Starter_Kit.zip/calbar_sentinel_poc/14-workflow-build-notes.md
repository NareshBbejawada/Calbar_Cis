# Workflow assembly notes

These are build instructions, not deployable Logic App workflow JSON. Connector IDs,
resource IDs, networking and Sentinel trigger payloads must be bound to your tenant.
Use four stateful workflows: `SW-Ingest`, `SW-To-Sentinel`, `Sentinel-Triage`,
`POC-Health`. They may share one Logic Apps Standard resource only when its approved
inbound policy supports BOTH SolarWinds requests and Sentinel managed callbacks.
When private-only inbound access is required for SolarWinds, separate the ingress
and Sentinel playbook into two Logic App resources with their own identities and
approved policies. Do not disable public access on a Sentinel webhook playbook and
assume managed callbacks can reach a private endpoint. Apply Microsoft's documented
Sentinel access-restriction requirements and test invocation before building the rest.
Service Bus private endpoints require the Premium tier; get cost/security approval.

## 1. SW-Ingest
1. HTTP request trigger, POST, schema from `01-ingress-schema.json`.
2. Restrict inbound access to approved sources. SourceInstance allowlist initially
   CALBAR-SW-POC; add CALBAR-SW-PILOT only for the real pilot. Body validation is NOT
   sender authentication. Protect the callback signature and use network restrictions.
3. Compose an object (not string concatenation of JSON) containing the fields plus
   ReceivedUtc=utcNow(), EpisodeKey=concat(SourceInstance,'|',AlertRuleId,'|',
   AlertObjectId,'|',SourceOccurrenceId). Immutable episode IDs are mandatory.
4. Send object as JSON to `q-cbar-poc-events`. Assign a fresh receipt MessageId,
   separate from EpisodeKey. Do not use one queue MessageId for both trigger and reset.
5. HTTP 202 response only after durable queue acceptance. Failed validation/send must
   produce a non-success response and an observable failed run. Alert on failed runs.

## 2. SW-To-Sentinel
1. Service Bus built-in peek-lock queue trigger. Use explicit completion, not
   receive-and-delete or auto-complete. Keep work short; set/review lock renewal.
2. Parse the queued object. Call poc.GetRoute with parameterized source/rule/object.
3. Compose the table object shown in `02-table-sample.json`. TimeGenerated=utcNow()
   at forwarding time, ReceivedUtc stays the original receipt. They are NOT native
   source time. Set IsPoc=true from workflow configuration, never from caller input.
4. POST a JSON ARRAY containing this object to the DCR/DCE logs-ingestion URI.
   Managed-identity audience: https://monitor.azure.us (not commercial Azure).
   Stream name must exactly match the DCR streamDeclarations key.
5. Complete the Service Bus message only after HTTP 204. On errors preserve/retry
   message delivery and monitor dead-letter messages. A repeated ingestion can produce
   repeated table rows; downstream idempotency still matters.
6. SourceSummary is optional untrusted data. Never insert arbitrary source text into
   KQL, SQL or executable code. Use parameterized SQL and structured JSON values.

## 3. Sentinel candidate rule
Use `03-analytics-rule.kql`. Five-minute frequency, 30-minute lookback, result threshold
>0, alert for each returned row, rule-wide suppression OFF. Create incidents.
Surface EpisodeKey, EventType, SourceInstance, AlertRuleId, AlertObjectId, Asset,
Condition, SourceSummary and ReceivedUtc as custom details within platform limits.
Group matching EpisodeKey only (for a pilot grouping window such as 24 hours), not
all events from a host. SQL is the durable duplicate barrier; grouping is not.
Do not invent MITRE tactics for ordinary infrastructure conditions.
If Defender portal correlation changes incident grouping, process each constituent
alert independently using its custom details; never parse incident title for identity.

## 4. Sentinel-Triage
Use the Microsoft Sentinel incident trigger, not an HTTP trigger masquerading as one.
Do not rename the installed trigger. Trigger concurrency 1 for the POC; sequential loops.
Manually run against a test incident first and inspect the actual trigger JSON.
Alert custom details may be serialized JSON and their values may be arrays. Use Parse
JSON and the actual schema shown in your run; take a scalar from a single-element array.
Reject/route ambiguous or multiple episode identities to review. Do not assume a generic
path taken from another tenant. Iterate distinct EpisodeKey/EventType pairs.

For each pair:
1. Call poc.ClaimDecision. Continue ONLY if IsNewClaim=1. Existing completed, blocked
   or uncertain claims must not create another send automatically.
2. Read poc.GetRoute. Configuration, not AI, selects Zendesk IDs and mandatory policy.
3. For a triggered event, call the model once with the evidence and policy. Validate
   JSON with `06-ai-response-schema.json`, evidence IDs against supplied keys, output
   size and allowlisted owner. The JSON-mode API does NOT validate this schema for you.
   Reject missing content, refusal, truncation, invalid JSON or unsupported evidence.
   Model/parse failure -> explicit unavailable result and policy fallback.
4. `Shadow` mode: save final action `record`, AIResult, Evidence. No Zendesk body/send.
   Informational policy: also `record`; AI-only digest never suppresses mandatory ticket.
5. `PolicyWithAISummary` mode: known Ticket policy -> create; unknown Review -> triage
   test ticket; known Digest -> record. Route and priority come from policy only.
6. Compose the final Zendesk body as an OBJECT. Replace placeholder IDs. Subject and
   comment must say POC, and comments are internal. Log final routing/policy separately
   from AI advice. Include AI-unavailable when applicable; never fabricate a summary.
7. Call poc.SaveDecision with FinalAction=create, FrozenRequest=string(body), Evidence,
   and AIResult. This freezes the request before the external operation.
8. Call poc.BeginSend. Continue ONLY if SendAllowed=1. Use returned FrozenRequest;
   Idempotency-Key=DecisionId. Send POST to the fixed approved Zendesk host and path.
   Disable the HTTP action's automatic retries for this POC. A failure or timeout must
   become NeedsReview via poc.MarkReview, with a sanitized error and observed status.
9. On success, persist returned ticket.id using poc.CompleteSend immediately.
10. Add an optional Sentinel comment containing the resulting ticket reference after
    SQL success. A comment failure must not roll back or recreate the Zendesk ticket.

Reset handling: skip AI, use poc.GetEpisodeTicket for the exact EpisodeKey. No ticket ->
poc.MarkReview (no invented correlation). Otherwise SaveDecision(update, TicketId,
FrozenRequest with internal comment only), BeginSend, PUT the known ticket, CompleteSend.
Never include status=solved or change assignment. Uncertain PUTs need review too; an
idempotency key for creates does not guarantee comment updates are idempotent.

Automation: one rule for incident created, scoped to the POC analytics rule; another
for incident updated with alerts ADDED, scoped to that rule. Both call this playbook.
Do not trigger on every comment/tag update; that can cause a loop. Grant Sentinel's
service identity permission to execute playbooks on the containing resource group.
Run manually from a Sentinel incident, not the generic Logic Apps Run Trigger button.

## 5. POC-Health and operating discipline
Check failed workflows, Service Bus active/dead-letter counts, age of queued messages,
SQL NeedsReview/stalled claims and ticket cap. Use an existing approved independent
operations notification route. The POC does not provide a production P1 paging SLA.
Review `12-sql-review-queries.sql` and compare every controlled test event with the
source log and its downstream disposition. Run source replay manually while piloting.

## Deliberate POC limits
- No autonomous AI suppression, closure, priority downgrade or remediation.
- One ticket per source episode, not cross-source root-cause correlation.
- Repeat notifications do not add repetitive Zendesk comments in this first slice.
- No auto-retry/reclaim after an uncertain Zendesk send. Reconcile manually using the
  persisted exact payload and decision ID. Idempotency protection expires after two
  hours; do not delete claims or blindly retry after that window.
- Shadow decisions stay recorded. After enabling writes, send a NEW synthetic episode;
  old shadow records must not suddenly become live tickets.
- Out-of-order/reset-only events remain visible for manual review; not auto-close.
- Before production: durable outbox retry/reconciliation, SWIS history backfill,
  explicit acknowledgment/escalation, retention, recovery, throughput and security tests.

## Government endpoint and secrets checks
The DCE/DCR logs ingestion endpoint must be copied from the deployed resource. Use
`{logsIngestion.endpoint}/dataCollectionRules/{immutableId}/streams/{input-stream}?api-version=2023-01-01`
with a JSON-array body and a managed identity granted Monitoring Metrics Publisher
on that DCR. Do not confuse the stream name with a display name or table name.

For the model, copy the inference URL from the deployed government model's View Code.
File 10 assumes v1 Chat Completions. Obtain any approved model API key and Zendesk
OAuth token from Key Vault and enable secure inputs/outputs on secret-bearing and
sensitive HTTP/Compose/Parse actions. Do not enable local keys against organizational
policy; use the resource's approved Entra authentication route instead. An access
restriction alone is not authorization, and an input SourceInstance is not identity.
