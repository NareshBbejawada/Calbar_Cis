using Microsoft.Data.SqlClient;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddRazorPages();
builder.Services.AddSingleton<GovernanceRepository>();
var app = builder.Build();
app.UseExceptionHandler("/Error");
app.UseHsts();
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.MapRazorPages();
app.MapGet("/health", () => Results.Ok(new { status = "healthy", utc = DateTime.UtcNow }));
app.Run();

public sealed class GovernanceRepository(IConfiguration configuration)
{
    private string ConnectionString
    {
        get
        {
            var cs = configuration.GetConnectionString("GovernanceDb")
                     ?? throw new InvalidOperationException("ConnectionStrings:GovernanceDb is missing.");
            return cs;
        }
    }

    public async Task<DashboardSummary> GetSummaryAsync(CancellationToken ct)
    {
        await using var cn = new SqlConnection(ConnectionString);
        await cn.OpenAsync(ct);
        await using var cmd = new SqlCommand("SELECT InstanceCount,Passed,Failed,Errors,Exempt,LastEvaluatedUtc FROM rpt.vw_DashboardSummary", cn);
        await using var r = await cmd.ExecuteReaderAsync(ct);
        if (!await r.ReadAsync(ct)) return new();
        return new DashboardSummary(r.GetInt32(0), ValueOrZero(r,1), ValueOrZero(r,2), ValueOrZero(r,3), ValueOrZero(r,4), r.IsDBNull(5)?null:r.GetDateTime(5));
    }

    public async Task<List<InstanceSummary>> GetInstancesAsync(CancellationToken ct)
    {
        var list = new List<InstanceSummary>();
        await using var cn = new SqlConnection(ConnectionString); await cn.OpenAsync(ct);
        await using var cmd = new SqlCommand("SELECT InstanceId,SqlConnectionName,ComputerName,EnvironmentName,Passed,Failed,Errors,Exempt,LastEvaluatedUtc FROM rpt.vw_InstanceSummary ORDER BY Failed DESC,Errors DESC,SqlConnectionName",cn);
        await using var r=await cmd.ExecuteReaderAsync(ct);
        while(await r.ReadAsync(ct)) list.Add(new(r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetString(3),ValueOrZero(r,4),ValueOrZero(r,5),ValueOrZero(r,6),ValueOrZero(r,7),r.IsDBNull(8)?null:r.GetDateTime(8)));
        return list;
    }

    public async Task<List<ComplianceItem>> GetFailuresAsync(int? instanceId,CancellationToken ct)
    {
        var list=new List<ComplianceItem>();
        await using var cn=new SqlConnection(ConnectionString);await cn.OpenAsync(ct);
        var sql="SELECT TOP(500) SqlConnectionName,ControlCode,Title,Severity,DatabaseName,Status,ActualValue,ExpectedValue,EvaluatedUtc FROM rpt.vw_LatestComplianceResult WHERE Status IN ('FAIL','ERROR') AND (@InstanceId IS NULL OR InstanceId=@InstanceId) ORDER BY CASE Severity WHEN 'CRITICAL' THEN 1 WHEN 'HIGH' THEN 2 WHEN 'MEDIUM' THEN 3 ELSE 4 END,SqlConnectionName,ControlCode";
        await using var cmd=new SqlCommand(sql,cn);cmd.Parameters.AddWithValue("@InstanceId",(object?)instanceId??DBNull.Value);
        await using var r=await cmd.ExecuteReaderAsync(ct);
        while(await r.ReadAsync(ct)) list.Add(new(r.GetString(0),r.GetString(1),r.GetString(2),r.GetString(3),r.IsDBNull(4)?null:r.GetString(4),r.GetString(5),r.IsDBNull(6)?null:r.GetString(6),r.IsDBNull(7)?null:r.GetString(7),r.GetDateTime(8)));
        return list;
    }
    private static int ValueOrZero(SqlDataReader r,int i)=>r.IsDBNull(i)?0:Convert.ToInt32(r.GetValue(i));
}
public record DashboardSummary(int InstanceCount=0,int Passed=0,int Failed=0,int Errors=0,int Exempt=0,DateTime? LastEvaluatedUtc=null);
public record InstanceSummary(int InstanceId,string SqlConnectionName,string ComputerName,string EnvironmentName,int Passed,int Failed,int Errors,int Exempt,DateTime? LastEvaluatedUtc);
public record ComplianceItem(string SqlConnectionName,string ControlCode,string Title,string Severity,string? DatabaseName,string Status,string? ActualValue,string? ExpectedValue,DateTime EvaluatedUtc);
