using Microsoft.AspNetCore.Mvc.RazorPages;
namespace Calsb.SqlCis.Web.Pages;
public class IndexModel(GovernanceRepository repo):PageModel
{
 public DashboardSummary Summary {get;private set;}=new();
 public List<InstanceSummary> Instances {get;private set;}=[];
 public async Task OnGet(CancellationToken ct){Summary=await repo.GetSummaryAsync(ct);Instances=await repo.GetInstancesAsync(ct);}
}
