using Microsoft.AspNetCore.Mvc.RazorPages;
namespace Calsb.SqlCis.Web.Pages;
public class FailuresModel(GovernanceRepository repo):PageModel
{
 public List<ComplianceItem> Items {get;private set;}=[];
 public async Task OnGet(int? instanceId,CancellationToken ct)=>Items=await repo.GetFailuresAsync(instanceId,ct);
}
