#!/usr/bin/env bash
set -euo pipefail
: "${RESOURCE_GROUP:?Set RESOURCE_GROUP}"
: "${APP_NAME:?Set APP_NAME}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/web/Calsb.SqlCis.Web"
dotnet restore
dotnet publish -c Release -o publish
cd publish
zip -r ../app.zip . >/dev/null
az webapp deploy --resource-group "$RESOURCE_GROUP" --name "$APP_NAME" --src-path ../app.zip --type zip
