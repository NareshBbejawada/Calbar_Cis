targetScope = 'resourceGroup'
param location string = resourceGroup().location
param appName string
param appServicePlanName string = '${appName}-plan'
param vnetResourceId string
param integrationSubnetName string
param miFqdn string
param databaseName string = 'CALSB_SQL_CIS'
param skuName string = 'P1v3'

resource plan 'Microsoft.Web/serverfarms@2024-04-01' = {
  name: appServicePlanName
  location: location
  sku: { name: skuName tier: 'PremiumV3' }
  kind: 'linux'
  properties: { reserved: true }
}

resource app 'Microsoft.Web/sites@2024-04-01' = {
  name: appName
  location: location
  identity: { type: 'SystemAssigned' }
  properties: {
    serverFarmId: plan.id
    httpsOnly: true
    virtualNetworkSubnetId: '${vnetResourceId}/subnets/${integrationSubnetName}'
    siteConfig: {
      linuxFxVersion: 'DOTNETCORE|8.0'
      minTlsVersion: '1.2'
      ftpsState: 'Disabled'
      alwaysOn: true
      http20Enabled: true
      healthCheckPath: '/health'
      appSettings: [
        { name: 'ASPNETCORE_ENVIRONMENT'; value: 'Production' }
        { name: 'WEBSITE_RUN_FROM_PACKAGE'; value: '1' }
        { name: 'ConnectionStrings__GovernanceDb'; value: 'Server=tcp:${miFqdn},1433;Database=${databaseName};Authentication=Active Directory Managed Identity;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;' }
      ]
    }
  }
}

output appServiceName string = app.name
output appPrincipalId string = app.identity.principalId
output defaultHostName string = app.properties.defaultHostName
