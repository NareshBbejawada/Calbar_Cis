#!/usr/bin/env bash
set -euo pipefail
: "${RESOURCE_GROUP:?Set RESOURCE_GROUP}"
: "${LOCATION:?Set LOCATION}"
: "${APP_NAME:?Set APP_NAME}"
: "${VNET_RESOURCE_ID:?Set VNET_RESOURCE_ID}"
: "${INTEGRATION_SUBNET:?Set INTEGRATION_SUBNET}"
: "${MI_FQDN:?Set MI_FQDN}"

az group create -n "$RESOURCE_GROUP" -l "$LOCATION" >/dev/null
az deployment group create -g "$RESOURCE_GROUP" -f main.bicep \
  -p appName="$APP_NAME" vnetResourceId="$VNET_RESOURCE_ID" integrationSubnetName="$INTEGRATION_SUBNET" miFqdn="$MI_FQDN"

echo "Azure infrastructure created. Next: grant the App Service managed identity database access, publish the web app, and enable Entra authentication."
