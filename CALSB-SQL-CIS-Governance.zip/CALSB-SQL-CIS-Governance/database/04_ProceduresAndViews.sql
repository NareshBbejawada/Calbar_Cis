USE [CALSB_SQL_CIS];
GO
CREATE OR ALTER PROCEDURE inv.usp_UpsertDiscoveredInstance
 @ComputerName nvarchar(128), @Fqdn nvarchar(256)=NULL, @DomainName nvarchar(128)=NULL,
 @IPv4Address varchar(45)=NULL, @OperatingSystem nvarchar(256)=NULL,
 @InstanceName nvarchar(128), @SqlConnectionName nvarchar(256), @ListenerPort int=NULL,
 @DiscoverySource varchar(40)=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 BEGIN TRAN;
 DECLARE @ServerId int;
 SELECT @ServerId=ServerId FROM inv.Server WITH(UPDLOCK,HOLDLOCK) WHERE ComputerName=@ComputerName;
 IF @ServerId IS NULL
 BEGIN
   INSERT inv.Server(ComputerName,Fqdn,DomainName,IPv4Address,OperatingSystem,DiscoverySource,LastDiscoveredUtc)
   VALUES(@ComputerName,@Fqdn,@DomainName,@IPv4Address,@OperatingSystem,@DiscoverySource,SYSUTCDATETIME());
   SET @ServerId=SCOPE_IDENTITY();
 END
 ELSE UPDATE inv.Server SET Fqdn=COALESCE(@Fqdn,Fqdn),DomainName=COALESCE(@DomainName,DomainName),IPv4Address=COALESCE(@IPv4Address,IPv4Address),OperatingSystem=COALESCE(@OperatingSystem,OperatingSystem),DiscoverySource=@DiscoverySource,LastDiscoveredUtc=SYSUTCDATETIME(),ModifiedUtc=SYSUTCDATETIME(),IsActive=1 WHERE ServerId=@ServerId;
 MERGE inv.SqlInstance AS T USING(SELECT @ServerId ServerId,@InstanceName InstanceName) S
 ON T.ServerId=S.ServerId AND T.InstanceName=S.InstanceName
 WHEN MATCHED THEN UPDATE SET SqlConnectionName=@SqlConnectionName,ListenerPort=COALESCE(@ListenerPort,T.ListenerPort),IsActive=1,ModifiedUtc=SYSUTCDATETIME()
 WHEN NOT MATCHED THEN INSERT(ServerId,InstanceName,SqlConnectionName,ListenerPort) VALUES(@ServerId,@InstanceName,@SqlConnectionName,@ListenerPort);
 COMMIT;
END;
GO

CREATE OR ALTER VIEW rpt.vw_LatestComplianceResult AS
WITH x AS (
 SELECT r.*,ROW_NUMBER() OVER(PARTITION BY r.InstanceId,r.ControlId,ISNULL(r.DatabaseName,N'') ORDER BY r.EvaluatedUtc DESC,r.ResultId DESC) rn
 FROM audit.ComplianceResult r
)
SELECT x.ResultId,x.ScanRunId,x.InstanceId,i.SqlConnectionName,s.ComputerName,s.EnvironmentName,
       x.ControlId,c.ControlCode,c.Title,c.Severity,c.ScopeType,x.DatabaseName,x.EvaluatedUtc,x.Status,
       x.ActualValue,x.ExpectedValue,x.Details,x.RemediationAttempted,x.RemediationSucceeded
FROM x JOIN inv.SqlInstance i ON i.InstanceId=x.InstanceId
JOIN inv.Server s ON s.ServerId=i.ServerId
JOIN cfg.ControlDefinition c ON c.ControlId=x.ControlId
WHERE x.rn=1;
GO

CREATE OR ALTER VIEW rpt.vw_DashboardSummary AS
SELECT COUNT(DISTINCT InstanceId) InstanceCount,
 SUM(CASE WHEN Status='PASS' THEN 1 ELSE 0 END) Passed,
 SUM(CASE WHEN Status='FAIL' THEN 1 ELSE 0 END) Failed,
 SUM(CASE WHEN Status='ERROR' THEN 1 ELSE 0 END) Errors,
 SUM(CASE WHEN Status='EXEMPT' THEN 1 ELSE 0 END) Exempt,
 MAX(EvaluatedUtc) LastEvaluatedUtc
FROM rpt.vw_LatestComplianceResult;
GO

CREATE OR ALTER VIEW rpt.vw_InstanceSummary AS
SELECT InstanceId,SqlConnectionName,ComputerName,EnvironmentName,
 SUM(CASE WHEN Status='PASS' THEN 1 ELSE 0 END) Passed,
 SUM(CASE WHEN Status='FAIL' THEN 1 ELSE 0 END) Failed,
 SUM(CASE WHEN Status='ERROR' THEN 1 ELSE 0 END) Errors,
 SUM(CASE WHEN Status='EXEMPT' THEN 1 ELSE 0 END) Exempt,
 MAX(EvaluatedUtc) LastEvaluatedUtc
FROM rpt.vw_LatestComplianceResult
GROUP BY InstanceId,SqlConnectionName,ComputerName,EnvironmentName;
GO
