USE [CALSB_SQL_CIS];
GO

MERGE cfg.ControlDefinition AS T
USING (VALUES
('CIS-2.1','Ad Hoc Distributed Queries must be disabled','HIGH','INSTANCE',9,
 N'SELECT CAST(value_in_use AS int) ActualValue, CASE WHEN value_in_use=0 THEN 1 ELSE 0 END IsCompliant FROM sys.configurations WHERE name=''Ad Hoc Distributed Queries''',N'0',
 N'EXEC sp_configure ''show advanced options'',1; RECONFIGURE; EXEC sp_configure ''Ad Hoc Distributed Queries'',0; RECONFIGURE;',0,1,10),
('CIS-2.2','CLR Enabled must be disabled unless approved','HIGH','INSTANCE',9,
 N'SELECT CAST(value_in_use AS int) ActualValue, CASE WHEN value_in_use=0 THEN 1 ELSE 0 END IsCompliant FROM sys.configurations WHERE name=''clr enabled''',N'0',
 N'EXEC sp_configure ''show advanced options'',1; RECONFIGURE; EXEC sp_configure ''clr enabled'',0; RECONFIGURE;',0,0,20),
('CIS-2.3','Cross DB Ownership Chaining must be disabled','HIGH','INSTANCE',9,
 N'SELECT CAST(value_in_use AS int) ActualValue, CASE WHEN value_in_use=0 THEN 1 ELSE 0 END IsCompliant FROM sys.configurations WHERE name=''cross db ownership chaining''',N'0',
 N'EXEC sp_configure ''show advanced options'',1; RECONFIGURE; EXEC sp_configure ''cross db ownership chaining'',0; RECONFIGURE;',0,1,30),
('CIS-2.4','Database Mail XPs must be disabled unless approved','MEDIUM','INSTANCE',9,
 N'SELECT CAST(value_in_use AS int) ActualValue, CASE WHEN value_in_use=0 THEN 1 ELSE 0 END IsCompliant FROM sys.configurations WHERE name=''Database Mail XPs''',N'0',NULL,0,0,40),
('CIS-2.5','Ole Automation Procedures must be disabled','HIGH','INSTANCE',9,
 N'SELECT CAST(value_in_use AS int) ActualValue, CASE WHEN value_in_use=0 THEN 1 ELSE 0 END IsCompliant FROM sys.configurations WHERE name=''Ole Automation Procedures''',N'0',
 N'EXEC sp_configure ''show advanced options'',1; RECONFIGURE; EXEC sp_configure ''Ole Automation Procedures'',0; RECONFIGURE;',0,1,50),
('CIS-2.6','Remote Access must be disabled','MEDIUM','INSTANCE',9,
 N'SELECT CAST(value_in_use AS int) ActualValue, CASE WHEN value_in_use=0 THEN 1 ELSE 0 END IsCompliant FROM sys.configurations WHERE name=''remote access''',N'0',NULL,1,0,60),
('CIS-2.7','Remote Admin Connections must be disabled','MEDIUM','INSTANCE',9,
 N'SELECT CAST(value_in_use AS int) ActualValue, CASE WHEN value_in_use=0 THEN 1 ELSE 0 END IsCompliant FROM sys.configurations WHERE name=''remote admin connections''',N'0',NULL,0,0,70),
('CIS-2.8','Scan for Startup Procs must be disabled','HIGH','INSTANCE',9,
 N'SELECT CAST(value_in_use AS int) ActualValue, CASE WHEN value_in_use=0 THEN 1 ELSE 0 END IsCompliant FROM sys.configurations WHERE name=''scan for startup procs''',N'0',NULL,1,0,80),
('CIS-2.9','Trustworthy databases must be OFF','HIGH','DATABASE',9,
 N'SELECT name DatabaseName, CAST(is_trustworthy_on AS int) ActualValue, CASE WHEN is_trustworthy_on=0 THEN 1 ELSE 0 END IsCompliant FROM sys.databases WHERE database_id>4 AND state=0',N'0',NULL,0,0,90),
('CIS-2.10','Default Trace must be enabled','MEDIUM','INSTANCE',9,
 N'SELECT CAST(value_in_use AS int) ActualValue, CASE WHEN value_in_use=1 THEN 1 ELSE 0 END IsCompliant FROM sys.configurations WHERE name=''default trace enabled''',N'1',NULL,0,0,100),
('CIS-2.11','Login auditing must include failed logins','HIGH','INSTANCE',9,
 N'DECLARE @v int=(SELECT CONVERT(int,value_data) FROM sys.dm_server_registry WHERE registry_key LIKE ''%MSSQLServer'' AND value_name=''AuditLevel''); SELECT @v ActualValue, CASE WHEN @v IN (2,3) THEN 1 ELSE 0 END IsCompliant',N'2 or 3',NULL,1,0,110),
('CIS-2.12','SQL error log count must be at least 12','MEDIUM','INSTANCE',9,
 N'DECLARE @v int=(SELECT CONVERT(int,value_data) FROM sys.dm_server_registry WHERE value_name=''NumErrorLogs''); SELECT ISNULL(@v,6) ActualValue, CASE WHEN ISNULL(@v,6)>=12 THEN 1 ELSE 0 END IsCompliant',N'>=12',NULL,1,0,120),
('CIS-2.13','xp_cmdshell must be disabled','CRITICAL','INSTANCE',9,
 N'SELECT CAST(value_in_use AS int) ActualValue, CASE WHEN value_in_use=0 THEN 1 ELSE 0 END IsCompliant FROM sys.configurations WHERE name=''xp_cmdshell''',N'0',
 N'EXEC sp_configure ''show advanced options'',1; RECONFIGURE; EXEC sp_configure ''xp_cmdshell'',0; RECONFIGURE;',0,1,130),
('CIS-3.1','sa login must be disabled','CRITICAL','INSTANCE',9,
 N'SELECT CAST(is_disabled AS int) ActualValue, CASE WHEN is_disabled=1 THEN 1 ELSE 0 END IsCompliant FROM sys.sql_logins WHERE sid=0x01',N'1',N'ALTER LOGIN [sa] DISABLE;',0,0,140),
('CIS-3.2','No SQL login may have a blank password','CRITICAL','INSTANCE',9,
 N'SELECT COUNT(*) ActualValue, CASE WHEN COUNT(*)=0 THEN 1 ELSE 0 END IsCompliant FROM sys.sql_logins WHERE PWDCOMPARE('''',password_hash)=1',N'0',NULL,0,0,150),
('CIS-3.3','Contained database authentication must be disabled','HIGH','INSTANCE',11,
 N'SELECT CAST(value_in_use AS int) ActualValue, CASE WHEN value_in_use=0 THEN 1 ELSE 0 END IsCompliant FROM sys.configurations WHERE name=''contained database authentication''',N'0',NULL,0,0,160),
('CIS-4.1','Public server role must not have direct permissions','HIGH','INSTANCE',9,
 N'SELECT COUNT(*) ActualValue, CASE WHEN COUNT(*)=0 THEN 1 ELSE 0 END IsCompliant FROM sys.server_permissions WHERE grantee_principal_id=SUSER_ID(''public'') AND permission_name<>''CONNECT SQL''',N'0',NULL,0,0,170),
('CIS-5.1','CLR strict security must be enabled on SQL 2017+','HIGH','INSTANCE',14,
 N'SELECT CAST(value_in_use AS int) ActualValue, CASE WHEN value_in_use=1 THEN 1 ELSE 0 END IsCompliant FROM sys.configurations WHERE name=''clr strict security''',N'1',NULL,0,0,180),
('CIS-5.2','SQL Server version must be supported','CRITICAL','INSTANCE',9,
 N'DECLARE @major int=CONVERT(int,SERVERPROPERTY(''ProductMajorVersion'')); SELECT @major ActualValue, CASE WHEN @major>=15 THEN 1 ELSE 0 END IsCompliant',N'SQL Server 2019 or newer',NULL,0,0,190),
('CIS-6.1','User databases should use CHECKSUM page verification','HIGH','DATABASE',9,
 N'SELECT name DatabaseName, page_verify_option_desc ActualValue, CASE WHEN page_verify_option=2 THEN 1 ELSE 0 END IsCompliant FROM sys.databases WHERE database_id>4 AND state=0',N'CHECKSUM',NULL,0,0,200)
) AS S(ControlCode,Title,Severity,ScopeType,MinimumMajorVersion,CheckSql,ExpectedValue,RemediationSql,RequiresRestart,IsAutoRemediationAllowed,SortOrder)
ON T.ControlCode=S.ControlCode
WHEN MATCHED THEN UPDATE SET Title=S.Title,Severity=S.Severity,ScopeType=S.ScopeType,MinimumMajorVersion=S.MinimumMajorVersion,CheckSql=S.CheckSql,ExpectedValue=S.ExpectedValue,RemediationSql=S.RemediationSql,RequiresRestart=S.RequiresRestart,IsAutoRemediationAllowed=S.IsAutoRemediationAllowed,SortOrder=S.SortOrder,ModifiedUtc=SYSUTCDATETIME()
WHEN NOT MATCHED THEN INSERT(ControlCode,Title,Severity,ScopeType,MinimumMajorVersion,CheckSql,ExpectedValue,RemediationSql,RequiresRestart,IsAutoRemediationAllowed,SortOrder)
VALUES(S.ControlCode,S.Title,S.Severity,S.ScopeType,S.MinimumMajorVersion,S.CheckSql,S.ExpectedValue,S.RemediationSql,S.RequiresRestart,S.IsAutoRemediationAllowed,S.SortOrder);
GO
