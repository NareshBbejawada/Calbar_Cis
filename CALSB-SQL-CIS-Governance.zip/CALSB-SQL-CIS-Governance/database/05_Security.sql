USE [CALSB_SQL_CIS];
GO
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name=N'cis_runner') CREATE ROLE cis_runner;
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name=N'cis_web_reader') CREATE ROLE cis_web_reader;
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name=N'cis_web_admin') CREATE ROLE cis_web_admin;
GRANT SELECT,INSERT,UPDATE,EXECUTE ON SCHEMA::inv TO cis_runner;
GRANT SELECT ON SCHEMA::cfg TO cis_runner;
GRANT SELECT,INSERT,UPDATE ON SCHEMA::audit TO cis_runner;
GRANT SELECT ON SCHEMA::rpt TO cis_runner;
GRANT SELECT ON SCHEMA::inv TO cis_web_reader;
GRANT SELECT ON SCHEMA::cfg TO cis_web_reader;
GRANT SELECT ON SCHEMA::rpt TO cis_web_reader;
GRANT SELECT,INSERT,UPDATE,DELETE ON SCHEMA::cfg TO cis_web_admin;
GRANT SELECT,INSERT,UPDATE ON SCHEMA::inv TO cis_web_admin;
GRANT SELECT ON SCHEMA::rpt TO cis_web_admin;
GO
/* After App Service managed identity is enabled, run while signed in as Entra admin:
CREATE USER [<app-service-name>] FROM EXTERNAL PROVIDER;
ALTER ROLE cis_web_reader ADD MEMBER [<app-service-name>];
ALTER ROLE cis_web_admin ADD MEMBER [<app-service-name>]; -- only if portal edits are enabled
*/
