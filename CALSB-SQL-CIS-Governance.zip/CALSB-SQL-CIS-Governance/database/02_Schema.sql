USE [CALSB_SQL_CIS];
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name=N'inv') EXEC('CREATE SCHEMA inv AUTHORIZATION dbo');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name=N'cfg') EXEC('CREATE SCHEMA cfg AUTHORIZATION dbo');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name=N'audit') EXEC('CREATE SCHEMA audit AUTHORIZATION dbo');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name=N'rpt') EXEC('CREATE SCHEMA rpt AUTHORIZATION dbo');
GO

CREATE TABLE inv.Server (
    ServerId             int IDENTITY(1,1) NOT NULL CONSTRAINT PK_inv_Server PRIMARY KEY,
    ComputerName         nvarchar(128) NOT NULL,
    Fqdn                 nvarchar(256) NULL,
    DomainName           nvarchar(128) NULL,
    IPv4Address          varchar(45) NULL,
    OperatingSystem      nvarchar(256) NULL,
    EnvironmentName      varchar(20) NOT NULL CONSTRAINT DF_Server_Environment DEFAULT ('Unknown'),
    IsActive             bit NOT NULL CONSTRAINT DF_Server_IsActive DEFAULT (1),
    DiscoverySource      varchar(40) NULL,
    LastDiscoveredUtc    datetime2(0) NULL,
    LastSuccessfulScanUtc datetime2(0) NULL,
    Notes                nvarchar(1000) NULL,
    CreatedUtc           datetime2(0) NOT NULL CONSTRAINT DF_Server_Created DEFAULT SYSUTCDATETIME(),
    ModifiedUtc          datetime2(0) NOT NULL CONSTRAINT DF_Server_Modified DEFAULT SYSUTCDATETIME(),
    RowVersion           rowversion NOT NULL,
    CONSTRAINT UQ_inv_Server_ComputerName UNIQUE (ComputerName)
);
GO

CREATE TABLE inv.SqlInstance (
    InstanceId            int IDENTITY(1,1) NOT NULL CONSTRAINT PK_inv_SqlInstance PRIMARY KEY,
    ServerId              int NOT NULL,
    InstanceName          nvarchar(128) NOT NULL,
    SqlConnectionName     nvarchar(256) NOT NULL,
    ListenerPort          int NULL,
    IsClustered           bit NULL,
    ClusterName           nvarchar(128) NULL,
    IsHadrEnabled         bit NULL,
    ProductVersion        nvarchar(64) NULL,
    ProductLevel          nvarchar(64) NULL,
    Edition               nvarchar(128) NULL,
    EngineEdition         int NULL,
    ServiceAccount        nvarchar(256) NULL,
    AuthenticationMode    varchar(20) NULL,
    IsActive              bit NOT NULL CONSTRAINT DF_Instance_IsActive DEFAULT (1),
    LastConnectedUtc      datetime2(0) NULL,
    LastConnectionError   nvarchar(2000) NULL,
    CreatedUtc            datetime2(0) NOT NULL CONSTRAINT DF_Instance_Created DEFAULT SYSUTCDATETIME(),
    ModifiedUtc           datetime2(0) NOT NULL CONSTRAINT DF_Instance_Modified DEFAULT SYSUTCDATETIME(),
    RowVersion            rowversion NOT NULL,
    CONSTRAINT FK_Instance_Server FOREIGN KEY(ServerId) REFERENCES inv.Server(ServerId),
    CONSTRAINT UQ_inv_Instance UNIQUE(ServerId, InstanceName)
);
GO

CREATE TABLE cfg.ControlDefinition (
    ControlId              int IDENTITY(1,1) NOT NULL CONSTRAINT PK_cfg_Control PRIMARY KEY,
    ControlCode            varchar(30) NOT NULL,
    Title                  nvarchar(300) NOT NULL,
    Description            nvarchar(2000) NULL,
    Severity               varchar(10) NOT NULL,
    ScopeType              varchar(20) NOT NULL CONSTRAINT CK_Control_Scope CHECK (ScopeType IN ('INSTANCE','DATABASE')),
    MinimumMajorVersion    int NULL,
    CheckSql               nvarchar(max) NOT NULL,
    ExpectedValue          nvarchar(300) NULL,
    RemediationSql         nvarchar(max) NULL,
    RequiresRestart        bit NOT NULL CONSTRAINT DF_Control_Restart DEFAULT(0),
    IsEnabled              bit NOT NULL CONSTRAINT DF_Control_Enabled DEFAULT(1),
    IsAutoRemediationAllowed bit NOT NULL CONSTRAINT DF_Control_Auto DEFAULT(0),
    SortOrder              int NOT NULL CONSTRAINT DF_Control_Sort DEFAULT(100),
    CreatedUtc             datetime2(0) NOT NULL CONSTRAINT DF_Control_Created DEFAULT SYSUTCDATETIME(),
    ModifiedUtc            datetime2(0) NOT NULL CONSTRAINT DF_Control_Modified DEFAULT SYSUTCDATETIME(),
    CONSTRAINT UQ_cfg_ControlCode UNIQUE(ControlCode),
    CONSTRAINT CK_Control_Severity CHECK(Severity IN ('LOW','MEDIUM','HIGH','CRITICAL'))
);
GO

CREATE TABLE cfg.InstanceControlOverride (
    InstanceId            int NOT NULL,
    ControlId             int NOT NULL,
    IsEnabled             bit NOT NULL,
    Reason                nvarchar(1000) NULL,
    ExpiresUtc            datetime2(0) NULL,
    ModifiedBy            nvarchar(256) NULL,
    ModifiedUtc           datetime2(0) NOT NULL CONSTRAINT DF_Override_Modified DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_cfg_InstanceControlOverride PRIMARY KEY(InstanceId, ControlId),
    CONSTRAINT FK_Override_Instance FOREIGN KEY(InstanceId) REFERENCES inv.SqlInstance(InstanceId),
    CONSTRAINT FK_Override_Control FOREIGN KEY(ControlId) REFERENCES cfg.ControlDefinition(ControlId)
);
GO

CREATE TABLE cfg.Exception (
    ExceptionId           bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_cfg_Exception PRIMARY KEY,
    InstanceId            int NOT NULL,
    ControlId             int NOT NULL,
    DatabaseName          sysname NULL,
    BusinessReason        nvarchar(2000) NOT NULL,
    ApprovedBy            nvarchar(256) NOT NULL,
    ApprovedUtc           datetime2(0) NOT NULL,
    ExpiresUtc            datetime2(0) NOT NULL,
    IsActive              bit NOT NULL CONSTRAINT DF_Exception_Active DEFAULT(1),
    TicketNumber          nvarchar(100) NULL,
    CreatedBy             nvarchar(256) NULL,
    CreatedUtc            datetime2(0) NOT NULL CONSTRAINT DF_Exception_Created DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Exception_Instance FOREIGN KEY(InstanceId) REFERENCES inv.SqlInstance(InstanceId),
    CONSTRAINT FK_Exception_Control FOREIGN KEY(ControlId) REFERENCES cfg.ControlDefinition(ControlId)
);
GO

CREATE TABLE audit.ScanRun (
    ScanRunId             bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_audit_ScanRun PRIMARY KEY,
    StartedUtc            datetime2(0) NOT NULL,
    CompletedUtc          datetime2(0) NULL,
    RunnerName            nvarchar(128) NOT NULL,
    Mode                  varchar(20) NOT NULL,
    RequestedBy           nvarchar(256) NULL,
    InstanceCount         int NOT NULL CONSTRAINT DF_ScanRun_InstanceCount DEFAULT(0),
    PassedCount           int NOT NULL CONSTRAINT DF_ScanRun_Passed DEFAULT(0),
    FailedCount           int NOT NULL CONSTRAINT DF_ScanRun_Failed DEFAULT(0),
    ErrorCount            int NOT NULL CONSTRAINT DF_ScanRun_Error DEFAULT(0),
    Status                varchar(20) NOT NULL CONSTRAINT DF_ScanRun_Status DEFAULT('Running'),
    ErrorMessage          nvarchar(max) NULL
);
GO

CREATE TABLE audit.ComplianceResult (
    ResultId              bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_audit_Result PRIMARY KEY,
    ScanRunId             bigint NOT NULL,
    InstanceId            int NOT NULL,
    ControlId             int NOT NULL,
    DatabaseName          sysname NULL,
    EvaluatedUtc          datetime2(0) NOT NULL,
    Status                varchar(20) NOT NULL,
    ActualValue           nvarchar(2000) NULL,
    ExpectedValue         nvarchar(300) NULL,
    Details               nvarchar(max) NULL,
    RemediationAttempted  bit NOT NULL CONSTRAINT DF_Result_Remediation DEFAULT(0),
    RemediationSucceeded  bit NULL,
    DurationMs            int NULL,
    CONSTRAINT FK_Result_ScanRun FOREIGN KEY(ScanRunId) REFERENCES audit.ScanRun(ScanRunId),
    CONSTRAINT FK_Result_Instance FOREIGN KEY(InstanceId) REFERENCES inv.SqlInstance(InstanceId),
    CONSTRAINT FK_Result_Control FOREIGN KEY(ControlId) REFERENCES cfg.ControlDefinition(ControlId),
    CONSTRAINT CK_Result_Status CHECK(Status IN ('PASS','FAIL','ERROR','EXEMPT','NOT_APPLICABLE'))
);
GO

CREATE INDEX IX_Instance_Active ON inv.SqlInstance(IsActive) INCLUDE(SqlConnectionName, ProductVersion);
CREATE INDEX IX_Result_InstanceControlDate ON audit.ComplianceResult(InstanceId,ControlId,EvaluatedUtc DESC) INCLUDE(Status,ActualValue,ScanRunId);
CREATE INDEX IX_Result_ScanRun ON audit.ComplianceResult(ScanRunId) INCLUDE(Status);
CREATE INDEX IX_Exception_Active ON cfg.Exception(InstanceId,ControlId,IsActive,ExpiresUtc);
GO
