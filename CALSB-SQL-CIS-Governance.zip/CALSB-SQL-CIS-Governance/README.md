# CALSB SQL CIS Governance starter package

A small-client implementation for `calsb.org` using Azure App Service, an existing Azure SQL Managed Instance, and an internal Windows discovery/compliance runner.

## Package contents

- `database/`: inventory, controls, exceptions, audit schema, reports, and security roles.
- `powershell/`: AD/CIDR SQL discovery, CIS runner, credential setup, and scheduled-task installer.
- `web/`: .NET 8 Razor Pages dashboard using App Service managed identity.
- `azure/`: Bicep infrastructure and deployment scripts.
- `config/`: example configuration.
- `docs/DEPLOYMENT-GUIDE.md`: complete implementation steps.

## First commands

1. Install the database scripts on the existing MI.
2. Configure and run internal discovery with `-WhatIfOnly`.
3. Load inventory and perform the first audit-only scan.
4. Deploy the Azure App Service and grant its managed identity `cis_web_reader`.
5. Publish the dashboard and enable Entra authentication.

See `docs/DEPLOYMENT-GUIDE.md` for all steps and security notes.
