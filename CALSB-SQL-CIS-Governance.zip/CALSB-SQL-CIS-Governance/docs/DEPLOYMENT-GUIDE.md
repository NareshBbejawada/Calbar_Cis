# CALSB SQL CIS Governance deployment guide

## 1. Recommended small-client architecture

- **Azure App Service**: read-only dashboard and failure reporting, protected by Microsoft Entra authentication.
- **Existing Azure SQL Managed Instance**: `CALSB_SQL_CIS` inventory, configuration, exceptions, scan history, and reporting database.
- **Internal Windows runner**: domain-joined Windows Server inside `calsb.org`; runs discovery and CIS checks using Task Scheduler. It needs outbound connectivity to the Managed Instance and management connectivity to SQL Servers.
- **Private networking**: App Service uses regional VNet integration to reach the Managed Instance. The on-premises runner reaches the MI through existing VPN/ExpressRoute/private routing, or through the MI public endpoint only when CALSB security explicitly approves it.

Do not run network discovery from App Service. App Service is the portal; the internal runner is the scanner.

## 2. Prerequisites

1. Existing Azure SQL Managed Instance with an Entra administrator configured.
2. Azure VNet/subnet that can resolve and reach the MI FQDN. Create a dedicated empty subnet for App Service VNet integration; delegate it to `Microsoft.Web/serverFarms` if required by the portal.
3. Domain-joined Windows Server 2019/2022 for the runner, PowerShell 7 recommended, .NET 8 runtime, and network access to CALSB SQL hosts.
4. Runner service account, for example `CALSB\svc_sqlcis`, with:
   - Log on as a batch job on the runner.
   - SQL `VIEW SERVER STATE`, `VIEW ANY DEFINITION`, and read access needed by checks on target instances. Use a controlled server role rather than sysadmin for audit-only operation.
   - Permission to query AD computers if AD discovery is enabled.
5. `Microsoft.Data.SqlClient.dll` available to PowerShell. Simplest method: install the `SqlServer` PowerShell module and ensure its dependencies are available, or copy the NuGet assembly into the runner's PowerShell module path.
6. Azure CLI, Bicep, .NET 8 SDK, and zip on the deployment workstation.

## 3. Create the governance database

From SSMS/Azure Data Studio connected to the MI, execute in order:

1. `database/01_CreateDatabase.sql`
2. `database/02_Schema.sql`
3. `database/03_SeedControls.sql`
4. `database/04_ProceduresAndViews.sql`
5. `database/05_Security.sql`

`Install-All.sql` can be run in SQLCMD mode from its own folder.

Create a least-privileged SQL login for the on-premises runner if Entra service-principal authentication is not yet available:

```sql
USE master;
CREATE LOGIN cis_runner_login WITH PASSWORD = '<strong password stored in the vault>', CHECK_POLICY = ON;
USE CALSB_SQL_CIS;
CREATE USER cis_runner_login FOR LOGIN cis_runner_login;
ALTER ROLE cis_runner ADD MEMBER cis_runner_login;
```

For production, store the password in an enterprise vault. The included DPAPI credential file is acceptable for a small initial deployment only when the scheduled task always runs under the same service account.

## 4. Configure the internal runner

1. Copy `powershell`, `config`, and `logs` to `C:\ProgramData\CALSB-SQL-CIS`:

```powershell
New-Item C:\ProgramData\CALSB-SQL-CIS -ItemType Directory -Force
Copy-Item .\powershell\* C:\ProgramData\CALSB-SQL-CIS\scripts -Recurse -Force
Copy-Item .\config\CisGovernance.config.example.json C:\ProgramData\CALSB-SQL-CIS\config\CisGovernance.config.json
```

2. Sign in as the final task service account and create encrypted credentials:

```powershell
C:\ProgramData\CALSB-SQL-CIS\scripts\Initialize-Runner.ps1
```

3. Edit `CisGovernance.config.json`:
   - MI FQDN and database name.
   - `DomainDnsName`: `calsb.org`.
   - Approved CALSB CIDR ranges only. Do not enter the whole Internet or networks not owned by CALSB.
   - Common SQL ports. Include known custom ports.
   - Start with `AuditOnly=true` and `AllowAutoRemediation=false`.

4. Test MI access:

```powershell
Test-NetConnection <mi-fqdn> -Port 1433
```

5. Run discovery without database writes first:

```powershell
.\Discover-SqlInstances.ps1 -ConfigPath C:\ProgramData\CALSB-SQL-CIS\config\CisGovernance.config.json -WhatIfOnly
```

Review the CSV and logs. Then run without `-WhatIfOnly` to load inventory.

6. Validate inventory:

```sql
SELECT s.ComputerName,s.Fqdn,s.IPv4Address,i.InstanceName,i.SqlConnectionName,i.ListenerPort,i.LastConnectedUtc,i.LastConnectionError
FROM inv.Server s JOIN inv.SqlInstance i ON i.ServerId=s.ServerId
ORDER BY s.ComputerName,i.InstanceName;
```

7. Run the first audit:

```powershell
.\Invoke-CisGovernance.ps1 -ConfigPath C:\ProgramData\CALSB-SQL-CIS\config\CisGovernance.config.json
```

8. Install schedules:

```powershell
$cred=Get-Credential 'CALSB\svc_sqlcis'
.\Install-ScheduledTasks.ps1 -RunAsCredential $cred
```

The default schedules are weekly discovery Sunday 1:00 AM and daily CIS scan 2:00 AM.

## 5. Discovery behavior and limitations

The discovery script combines:

- Enabled AD computer enumeration.
- TCP checks against approved CIDR ranges and configured SQL ports.
- SQL Browser UDP/1434 responses for named instances.
- DNS enrichment and inventory upsert.

A network scan cannot guarantee discovery of every SQL instance. Firewalls, disabled SQL Browser, dynamic ports, aliases, clustered listeners, local-only instances, and cloud SQL services can hide endpoints. After the scan, reconcile the results with CMDB, DNS, monitoring, backup, vulnerability-scanner, and application-owner records.

## 6. Deploy Azure App Service

Set values and run the Bicep deployment:

```bash
cd azure
export RESOURCE_GROUP='rg-calsb-sqlcis-prod'
export LOCATION='westus2'
export APP_NAME='calsb-sqlcis-prod'
export VNET_RESOURCE_ID='/subscriptions/<sub>/resourceGroups/<network-rg>/providers/Microsoft.Network/virtualNetworks/<vnet>'
export INTEGRATION_SUBNET='snet-appservice-integration'
export MI_FQDN='<managed-instance-fqdn>'
./deploy-azure.sh
```

The template creates a Linux Premium v3 App Service plan because VNet integration and stable internal access are required. Adjust SKU after testing, but verify VNet integration support before downsizing.

## 7. Grant App Service managed identity access to MI

After the App Service is created, connect to the MI as its Microsoft Entra administrator:

```sql
USE CALSB_SQL_CIS;
CREATE USER [calsb-sqlcis-prod] FROM EXTERNAL PROVIDER;
ALTER ROLE cis_web_reader ADD MEMBER [calsb-sqlcis-prod];
```

The name must exactly match the App Service managed identity display name. Grant `cis_web_admin` only after change-control features are intentionally enabled.

## 8. Publish the web app

```bash
export RESOURCE_GROUP='rg-calsb-sqlcis-prod'
export APP_NAME='calsb-sqlcis-prod'
./publish-web.sh
```

Test:

```text
https://calsb-sqlcis-prod.azurewebsites.net/health
```

Then open the root dashboard. If database connectivity fails, check App Service VNet integration, NSG/UDR/DNS, MI private endpoint or VNet-local endpoint resolution, and the managed identity database user.

## 9. Enable Microsoft Entra authentication

In Azure portal:

1. App Service → **Authentication** → **Add identity provider**.
2. Select Microsoft Entra ID.
3. Choose a workforce/tenant application restricted to the CALSB tenant.
4. Require authentication for all requests.
5. Set unauthenticated requests to HTTP 302 redirect or HTTP 401 according to CALSB policy.
6. Restrict access using an Entra group such as `CALSB-SQL-CIS-Readers`; use a separate admins group when write features are added.

A `calsb.org` AD domain does not automatically equal the Entra tenant domain. Use the actual CALSB Entra tenant and synchronized identities/groups.

## 10. Initial rollout sequence

1. Week 1: discovery only; reconcile inventory.
2. Week 2: daily audit-only scans; tune controls and document accepted exceptions.
3. Week 3: publish dashboard to DBAs/security; validate false positives.
4. Week 4: enable only explicitly approved auto-remediation controls, one control at a time, in non-production first.
5. Keep restart-required controls audit-only until a maintenance-window workflow exists.

## 11. Target SQL permissions for audit-only runner

Start with a custom server role on each SQL Server and test every control:

```sql
USE master;
CREATE SERVER ROLE [CALSB_CIS_AUDITOR];
GRANT VIEW SERVER STATE TO [CALSB_CIS_AUDITOR];
GRANT VIEW ANY DEFINITION TO [CALSB_CIS_AUDITOR];
GRANT VIEW ANY DATABASE TO [CALSB_CIS_AUDITOR];
ALTER SERVER ROLE [CALSB_CIS_AUDITOR] ADD MEMBER [CALSB\svc_sqlcis];
```

Some registry-backed checks may need additional rights or may return errors on older versions. Treat those as `ERROR`, not automatically as noncompliant, until permissions are confirmed.

## 12. Production safeguards

- Audit-only is the default.
- No automatic restart is included.
- Remediation requires both `AllowAutoRemediation=true` and the `-Remediate` switch, and only controls marked auto-remediable execute.
- Use approved subnet lists and firewall rules.
- Keep App Service inbound access behind Entra; optionally use Private Endpoint plus internal DNS if CALSB requires no public web endpoint.
- Back up `CALSB_SQL_CIS`, retain scan history according to policy, and monitor failed scheduled tasks.
- Review the seeded controls against the exact CIS SQL Server benchmark version licensed/approved by CALSB. This starter package does not reproduce the complete copyrighted CIS Benchmark text.
