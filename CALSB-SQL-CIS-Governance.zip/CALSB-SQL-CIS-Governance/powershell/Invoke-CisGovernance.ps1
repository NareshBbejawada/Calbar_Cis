[CmdletBinding()]
param([Parameter(Mandatory)][string]$ConfigPath,[int[]]$InstanceId,[switch]$Remediate)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module "$PSScriptRoot\Common.psm1" -Force
$config=Import-CisConfig $ConfigPath;$dbcs=New-CisSqlConnectionString $config.GovernanceDatabase
$log=Join-Path $config.Runner.LogFolder ("CIS-{0:yyyyMMdd-HHmmss}.log" -f (Get-Date));$runner=$env:COMPUTERNAME
if($Remediate-and(-not$config.Runner.AllowAutoRemediation)){throw 'Remediation requested but AllowAutoRemediation is false.'}
$mode=if($Remediate){'Remediate'}else{'AuditOnly'}
$dt=Invoke-CisSqlDataTable $dbcs "INSERT audit.ScanRun(StartedUtc,RunnerName,Mode,RequestedBy) OUTPUT inserted.ScanRunId VALUES(SYSUTCDATETIME(),@Runner,@Mode,@Who)" @{Runner=$runner;Mode=$mode;Who="$env:USERDOMAIN\$env:USERNAME"}
$runId=[long]$dt.Rows[0].ScanRunId
try{
 $filter=if($InstanceId){' AND i.InstanceId IN ('+($InstanceId-join',')+')'}else{''}
 $instances=Invoke-CisSqlDataTable $dbcs ("SELECT i.InstanceId,i.SqlConnectionName,i.ProductVersion FROM inv.SqlInstance i WHERE i.IsActive=1"+$filter)
 $controls=Invoke-CisSqlDataTable $dbcs @'
SELECT c.* FROM cfg.ControlDefinition c WHERE c.IsEnabled=1 ORDER BY c.SortOrder
'@
 $targetCred=if($config.Runner.UseWindowsAuthenticationForTargets){$null}else{Import-CisCredential $config.Runner.TargetSqlCredentialFile}
 foreach($inst in $instances.Rows){
  Write-CisLog "Scanning $($inst.SqlConnectionName)" INFO $log
  try{
   $tb=[Microsoft.Data.SqlClient.SqlConnectionStringBuilder]::new();$tb.DataSource=$inst.SqlConnectionName;$tb.InitialCatalog='master';$tb.Encrypt=$true;$tb.TrustServerCertificate=$true;$tb.ConnectTimeout=15
   if($targetCred){$tb.UserID=$targetCred.UserName;$tb.Password=$targetCred.GetNetworkCredential().Password}else{$tb.IntegratedSecurity=$true}
   $ver=Invoke-CisSqlDataTable $tb.ConnectionString "SELECT CONVERT(int,SERVERPROPERTY('ProductMajorVersion')) MajorVersion,CONVERT(nvarchar(64),SERVERPROPERTY('ProductVersion')) ProductVersion,CONVERT(nvarchar(128),SERVERPROPERTY('Edition')) Edition,CONVERT(bit,SERVERPROPERTY('IsClustered')) IsClustered,CONVERT(bit,SERVERPROPERTY('IsHadrEnabled')) IsHadrEnabled" $null 30
   $major=[int]$ver.Rows[0].MajorVersion
   Invoke-CisSqlNonQuery $dbcs 'UPDATE inv.SqlInstance SET ProductVersion=@Version,Edition=@Edition,IsClustered=@Clustered,IsHadrEnabled=@Hadr,LastConnectedUtc=SYSUTCDATETIME(),LastConnectionError=NULL,ModifiedUtc=SYSUTCDATETIME() WHERE InstanceId=@Id' @{Version=$ver.Rows[0].ProductVersion;Edition=$ver.Rows[0].Edition;Clustered=$ver.Rows[0].IsClustered;Hadr=$ver.Rows[0].IsHadrEnabled;Id=$inst.InstanceId}|Out-Null
   foreach($ctl in $controls.Rows){
    if($ctl.MinimumMajorVersion-and$major-lt[int]$ctl.MinimumMajorVersion){continue}
    $start=Get-Date
    try{
      $rows=Invoke-CisSqlDataTable $tb.ConnectionString ([string]$ctl.CheckSql) $null ([int]$config.Runner.CommandTimeoutSeconds)
      if($rows.Rows.Count-eq0){throw 'Control query returned no rows.'}
      foreach($row in $rows.Rows){
       $dbName=if($rows.Columns.Contains('DatabaseName')){[string]$row.DatabaseName}else{$null};$actual=if($rows.Columns.Contains('ActualValue')){[string]$row.ActualValue}else{$null};$ok=[bool]$row.IsCompliant
       $ex=Invoke-CisSqlDataTable $dbcs 'SELECT TOP(1) ExceptionId FROM cfg.Exception WHERE InstanceId=@I AND ControlId=@C AND IsActive=1 AND ExpiresUtc>SYSUTCDATETIME() AND (DatabaseName IS NULL OR DatabaseName=@D)' @{I=$inst.InstanceId;C=$ctl.ControlId;D=$dbName}
       $status=if($ex.Rows.Count-gt0){'EXEMPT'}elseif($ok){'PASS'}else{'FAIL'};$attempt=$false;$success=$null;$details=$null
       if($status-eq'FAIL'-and$Remediate-and[bool]$ctl.IsAutoRemediationAllowed-and-not[string]::IsNullOrWhiteSpace([string]$ctl.RemediationSql)){$attempt=$true;try{Invoke-CisSqlNonQuery $tb.ConnectionString ([string]$ctl.RemediationSql) $null 120|Out-Null;$success=$true;$details='Remediation executed; next scan will verify.'}catch{$success=$false;$details=$_.Exception.Message}}
       $ms=[int]((Get-Date)-$start).TotalMilliseconds
       Invoke-CisSqlNonQuery $dbcs 'INSERT audit.ComplianceResult(ScanRunId,InstanceId,ControlId,DatabaseName,EvaluatedUtc,Status,ActualValue,ExpectedValue,Details,RemediationAttempted,RemediationSucceeded,DurationMs) VALUES(@R,@I,@C,@D,SYSUTCDATETIME(),@S,@A,@E,@X,@RA,@RS,@MS)' @{R=$runId;I=$inst.InstanceId;C=$ctl.ControlId;D=$dbName;S=$status;A=$actual;E=$ctl.ExpectedValue;X=$details;RA=$attempt;RS=$success;MS=$ms}|Out-Null
      }
    }catch{Invoke-CisSqlNonQuery $dbcs 'INSERT audit.ComplianceResult(ScanRunId,InstanceId,ControlId,EvaluatedUtc,Status,ExpectedValue,Details) VALUES(@R,@I,@C,SYSUTCDATETIME(),''ERROR'',@E,@X)' @{R=$runId;I=$inst.InstanceId;C=$ctl.ControlId;E=$ctl.ExpectedValue;X=$_.Exception.Message}|Out-Null;Write-CisLog "$($inst.SqlConnectionName) / $($ctl.ControlCode): $($_.Exception.Message)" WARN $log}
   }
  }catch{Invoke-CisSqlNonQuery $dbcs 'UPDATE inv.SqlInstance SET LastConnectionError=@E,ModifiedUtc=SYSUTCDATETIME() WHERE InstanceId=@I' @{E=$_.Exception.Message;I=$inst.InstanceId}|Out-Null;Write-CisLog "Instance failure $($inst.SqlConnectionName): $($_.Exception.Message)" ERROR $log;continue}
 }
 $sum=Invoke-CisSqlDataTable $dbcs 'SELECT SUM(CASE WHEN Status=''PASS'' THEN 1 ELSE 0 END) P,SUM(CASE WHEN Status=''FAIL'' THEN 1 ELSE 0 END) F,SUM(CASE WHEN Status=''ERROR'' THEN 1 ELSE 0 END) E FROM audit.ComplianceResult WHERE ScanRunId=@R' @{R=$runId}
 $passed = if($sum.Rows[0].P -eq [DBNull]::Value){0}else{[int]$sum.Rows[0].P}
 $failed = if($sum.Rows[0].F -eq [DBNull]::Value){0}else{[int]$sum.Rows[0].F}
 $errors = if($sum.Rows[0].E -eq [DBNull]::Value){0}else{[int]$sum.Rows[0].E}
 Invoke-CisSqlNonQuery $dbcs 'UPDATE audit.ScanRun SET CompletedUtc=SYSUTCDATETIME(),Status=''Completed'',InstanceCount=@IC,PassedCount=@P,FailedCount=@F,ErrorCount=@E WHERE ScanRunId=@R' @{IC=$instances.Rows.Count;P=$passed;F=$failed;E=$errors;R=$runId}|Out-Null
}catch{Invoke-CisSqlNonQuery $dbcs 'UPDATE audit.ScanRun SET CompletedUtc=SYSUTCDATETIME(),Status=''Failed'',ErrorMessage=@E WHERE ScanRunId=@R' @{E=$_.Exception.ToString();R=$runId}|Out-Null;throw}
Write-CisLog "CIS run $runId completed." INFO $log
