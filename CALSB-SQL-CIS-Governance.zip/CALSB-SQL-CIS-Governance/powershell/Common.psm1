Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Load Microsoft.Data.SqlClient. The SqlServer PowerShell module normally supplies it.
try { Add-Type -AssemblyName 'Microsoft.Data.SqlClient' -ErrorAction Stop } catch {
    $candidate = Get-ChildItem -Path "$env:ProgramFiles\WindowsPowerShell\Modules","$env:ProgramFiles\PowerShell\Modules" -Filter Microsoft.Data.SqlClient.dll -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $candidate) { throw "Microsoft.Data.SqlClient.dll was not found. Install-Module SqlServer -Scope AllUsers, then retry." }
    Add-Type -Path $candidate.FullName
}

function Import-CisConfig {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { throw "Configuration file not found: $Path" }
    Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json
}

function Import-CisCredential {
    [CmdletBinding()]
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return $null }
    if (-not (Test-Path -LiteralPath $Path)) { throw "Credential file not found: $Path" }
    Import-Clixml -LiteralPath $Path
}

function New-CisSqlConnectionString {
    [CmdletBinding()]
    param([Parameter(Mandatory)]$DatabaseConfig)
    $b = [Microsoft.Data.SqlClient.SqlConnectionStringBuilder]::new()
    $b.DataSource = [string]$DatabaseConfig.Server
    $b.InitialCatalog = [string]$DatabaseConfig.Database
    $b.Encrypt = [bool]$DatabaseConfig.Encrypt
    $b.TrustServerCertificate = [bool]$DatabaseConfig.TrustServerCertificate
    $b.ConnectTimeout = 30
    if ($DatabaseConfig.Authentication -eq 'Integrated') {
        $b.IntegratedSecurity = $true
    } else {
        $cred = Import-CisCredential -Path $DatabaseConfig.CredentialFile
        $b.UserID = $cred.UserName
        $b.Password = $cred.GetNetworkCredential().Password
    }
    $b.ConnectionString
}

function Invoke-CisSqlDataTable {
    [CmdletBinding()]
    param(
      [Parameter(Mandatory)][string]$ConnectionString,
      [Parameter(Mandatory)][string]$Query,
      [hashtable]$Parameters,
      [int]$CommandTimeout=60
    )
    $cn = [Microsoft.Data.SqlClient.SqlConnection]::new($ConnectionString)
    try {
      $cn.Open()
      $cmd = $cn.CreateCommand(); $cmd.CommandText=$Query; $cmd.CommandTimeout=$CommandTimeout
      if ($Parameters) {
        foreach ($key in $Parameters.Keys) {
          $v=$Parameters[$key]
          $p=$cmd.Parameters.AddWithValue("@$key", $(if($null -eq $v){[DBNull]::Value}else{$v}))
          $null=$p
        }
      }
      $dt=[System.Data.DataTable]::new(); $r=$cmd.ExecuteReader(); $dt.Load($r); $dt
    } finally { if($cn.State -ne 'Closed'){$cn.Close()}; $cn.Dispose() }
}

function Invoke-CisSqlNonQuery {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$ConnectionString,[Parameter(Mandatory)][string]$Query,[hashtable]$Parameters,[int]$CommandTimeout=60)
    $cn=[Microsoft.Data.SqlClient.SqlConnection]::new($ConnectionString)
    try {$cn.Open();$cmd=$cn.CreateCommand();$cmd.CommandText=$Query;$cmd.CommandTimeout=$CommandTimeout
      if($Parameters){foreach($key in $Parameters.Keys){$v=$Parameters[$key];$null=$cmd.Parameters.AddWithValue("@$key",$(if($null-eq$v){[DBNull]::Value}else{$v}))}}
      $cmd.ExecuteNonQuery()
    } finally {if($cn.State-ne'Closed'){$cn.Close()};$cn.Dispose()}
}

function Write-CisLog {
 param([string]$Message,[ValidateSet('INFO','WARN','ERROR')][string]$Level='INFO',[string]$LogPath)
 $line="{0:u} [{1}] {2}" -f (Get-Date),$Level,$Message
 Write-Host $line
 if($LogPath){$dir=Split-Path $LogPath -Parent;if(-not(Test-Path $dir)){New-Item -ItemType Directory -Path $dir -Force|Out-Null};Add-Content -Path $LogPath -Value $line}
}

Export-ModuleMember -Function *
