[CmdletBinding()]
param([Parameter(Mandatory)][string]$ConfigPath,[switch]$WhatIfOnly)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module "$PSScriptRoot\Common.psm1" -Force
$config=Import-CisConfig $ConfigPath
$dbcs=New-CisSqlConnectionString $config.GovernanceDatabase
$log=Join-Path $config.Runner.LogFolder ("Discovery-{0:yyyyMMdd-HHmmss}.log" -f (Get-Date))

function Convert-CidrToIpList([string]$Cidr){
  $parts=$Cidr.Split('/');$ip=[System.Net.IPAddress]::Parse($parts[0]);$prefix=[int]$parts[1]
  if($ip.AddressFamily-ne[System.Net.Sockets.AddressFamily]::InterNetwork){throw 'Only IPv4 CIDR is supported.'}
  $bytes=$ip.GetAddressBytes();[array]::Reverse($bytes);$base=[BitConverter]::ToUInt32($bytes,0)
  $mask=[uint32]::MaxValue -shl (32-$prefix);$network=$base-band$mask;$broadcast=$network-bor(-bnot$mask)
  for($n=$network+1;$n-lt$broadcast;$n++){ $b=[BitConverter]::GetBytes([uint32]$n);[array]::Reverse($b);([System.Net.IPAddress]::new($b)).ToString() }
}
function Test-Tcp([string]$HostName,[int]$Port,[int]$TimeoutMs){
  $c=[System.Net.Sockets.TcpClient]::new();try{$a=$c.BeginConnect($HostName,$Port,$null,$null);if(-not$a.AsyncWaitHandle.WaitOne($TimeoutMs,$false)){return $false};$c.EndConnect($a);$true}catch{$false}finally{$c.Dispose()}
}
function Get-BrowserInstances([string]$HostName){
  $u=[System.Net.Sockets.UdpClient]::new();try{$u.Client.ReceiveTimeout=1000;$u.Connect($HostName,1434);$req=[byte[]](2);$null=$u.Send($req,$req.Length);$ep=[System.Net.IPEndPoint]::new([System.Net.IPAddress]::Any,0);$resp=$u.Receive([ref]$ep);$text=[Text.Encoding]::ASCII.GetString($resp,3,$resp.Length-3);$tokens=$text.Split(';');$out=@();for($i=0;$i-lt$tokens.Count;$i++){if($tokens[$i]-eq'ServerName'){$obj=@{};while (($i -lt ($tokens.Count - 1)) -and -not [string]::IsNullOrWhiteSpace($tokens[$i])){$obj[$tokens[$i]]=$tokens[$i+1];$i+=2};$out+=[pscustomobject]@{ServerName=$obj.ServerName;InstanceName=$obj.InstanceName;Tcp=$obj.tcp}}};$out}catch{@()}finally{$u.Dispose()}
}

$candidates=[System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
if($config.Discovery.UseActiveDirectory){
 try{Import-Module ActiveDirectory -ErrorAction Stop;Get-ADComputer -Filter 'Enabled -eq $true' -Properties DNSHostName|ForEach-Object{if($_.DNSHostName){$null=$candidates.Add($_.DNSHostName)}};Write-CisLog "Loaded $($candidates.Count) enabled AD computers." INFO $log}catch{Write-CisLog "AD enumeration skipped: $($_.Exception.Message)" WARN $log}
}
foreach($subnet in $config.Discovery.Subnets){foreach($ip in Convert-CidrToIpList $subnet){$null=$candidates.Add($ip)}}
Write-CisLog "Testing $($candidates.Count) candidate hosts." INFO $log
$found=New-Object System.Collections.Generic.List[object]
foreach($hostName in $candidates){
  $open=@();foreach($p in $config.Discovery.TcpPorts){if(Test-Tcp $hostName ([int]$p) ([int]$config.Discovery.ConnectTimeoutMs)){$open+=[int]$p}}
  $browser=@();if($config.Discovery.TrySqlBrowserUdp){$browser=Get-BrowserInstances $hostName}
  foreach($b in $browser){$instance=if($b.InstanceName-eq'MSSQLSERVER'){'MSSQLSERVER'}else{$b.InstanceName};$conn=if($instance-eq'MSSQLSERVER'){$hostName}else{"$hostName\$instance"};$found.Add([pscustomobject]@{Host=$hostName;Instance=$instance;Connection=$conn;Port=if($b.Tcp){[int]$b.Tcp}else{$null};Source='SQLBrowser'})}
  foreach($p in $open){if(-not($found|Where-Object{$_.Host-eq$hostName-and$_.Port-eq$p})){$found.Add([pscustomobject]@{Host=$hostName;Instance=if($p-eq1433){'MSSQLSERVER'}else{"PORT_$p"};Connection="$hostName,$p";Port=$p;Source='TCPScan'})}}
}
$found=$found|Sort-Object Host,Instance -Unique
foreach($x in $found){
 try{$addr=([System.Net.Dns]::GetHostAddresses($x.Host)|Where-Object AddressFamily -eq InterNetwork|Select-Object -First 1).IPAddressToString}catch{$addr=$x.Host}
 try{$fqdn=[System.Net.Dns]::GetHostEntry($x.Host).HostName}catch{$fqdn=$x.Host}
 $computer=$fqdn.Split('.')[0]
 Write-CisLog "Discovered $($x.Connection)" INFO $log
 if(-not$WhatIfOnly){Invoke-CisSqlNonQuery $dbcs 'EXEC inv.usp_UpsertDiscoveredInstance @ComputerName,@Fqdn,@DomainName,@IPv4Address,NULL,@InstanceName,@SqlConnectionName,@ListenerPort,@DiscoverySource' @{ComputerName=$computer;Fqdn=$fqdn;DomainName=$config.Discovery.DomainDnsName;IPv4Address=$addr;InstanceName=$x.Instance;SqlConnectionName=$x.Connection;ListenerPort=$x.Port;DiscoverySource=$x.Source}|Out-Null}
}
$csv=Join-Path $config.Runner.LogFolder ("Discovery-{0:yyyyMMdd-HHmmss}.csv" -f (Get-Date));$found|Export-Csv $csv -NoTypeInformation
Write-CisLog "Discovery complete. Found $($found.Count) endpoints. CSV: $csv" INFO $log
