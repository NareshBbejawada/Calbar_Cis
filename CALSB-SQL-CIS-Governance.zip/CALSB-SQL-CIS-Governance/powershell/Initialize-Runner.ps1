[CmdletBinding()]
param(
 [string]$InstallRoot='C:\ProgramData\CALSB-SQL-CIS',
 [string]$GovernanceSqlUser='cis_runner_login'
)
$ErrorActionPreference='Stop'
$folders=@($InstallRoot,"$InstallRoot\config","$InstallRoot\logs","$InstallRoot\secrets","$InstallRoot\scripts")
$folders|ForEach-Object{New-Item -ItemType Directory -Path $_ -Force|Out-Null}
Write-Host 'Enter the Azure SQL Managed Instance SQL credential used by the runner.'
$mi=Get-Credential -UserName $GovernanceSqlUser -Message 'Governance database credential'
$mi|Export-Clixml -Path "$InstallRoot\secrets\mi-credential.xml"
Write-Host 'Optional target SQL credential. Cancel and use Windows authentication when the runner service account already has SQL rights.'
try {$target=Get-Credential -Message 'Target SQL credential (optional)'; if($target){$target|Export-Clixml -Path "$InstallRoot\secrets\target-sql-credential.xml"}} catch {}
Write-Host "Folders and DPAPI-protected credentials created under $InstallRoot. Run scheduled tasks under this same Windows account."
