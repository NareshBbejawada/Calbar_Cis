[CmdletBinding()]
param([string]$InstallRoot='C:\ProgramData\CALSB-SQL-CIS',[string]$ConfigPath='C:\ProgramData\CALSB-SQL-CIS\config\CisGovernance.config.json',[Parameter(Mandatory)][pscredential]$RunAsCredential)
$ErrorActionPreference='Stop'
$pwsh=(Get-Command pwsh.exe -ErrorAction SilentlyContinue).Source;if(-not$pwsh){$pwsh=(Get-Command powershell.exe).Source}
$scanAction=New-ScheduledTaskAction -Execute $pwsh -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$InstallRoot\scripts\Invoke-CisGovernance.ps1`" -ConfigPath `"$ConfigPath`""
$scanTrigger=New-ScheduledTaskTrigger -Daily -At 2:00AM
Register-ScheduledTask -TaskName 'CALSB SQL CIS Governance Scan' -Action $scanAction -Trigger $scanTrigger -User $RunAsCredential.UserName -Password $RunAsCredential.GetNetworkCredential().Password -RunLevel Highest -Force|Out-Null
$discAction=New-ScheduledTaskAction -Execute $pwsh -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$InstallRoot\scripts\Discover-SqlInstances.ps1`" -ConfigPath `"$ConfigPath`""
$discTrigger=New-ScheduledTaskTrigger -Weekly -DaysOfWeek Sunday -At 1:00AM
Register-ScheduledTask -TaskName 'CALSB SQL Discovery' -Action $discAction -Trigger $discTrigger -User $RunAsCredential.UserName -Password $RunAsCredential.GetNetworkCredential().Password -RunLevel Highest -Force|Out-Null
Write-Host 'Scheduled daily CIS scan at 2:00 AM and weekly discovery Sunday at 1:00 AM.'
