# SQL Server Drive Capacity Report

Read-only Windows volume inventory with a professional HTML email and complete CSV attachments.

## Included files

- `Send-SQLDriveCapacityReport.ps1`: self-contained collection and email script.
- `servers.txt`: sample inventory; replace with your real Windows host names.
- `Sample-Email-Preview.html`: illustrative layout only; contains invented data, not a scan of your environment.

## 1. Place the files on the management server

Example folder: `D:\DBA\DriveSpaceReport`

The script targets Windows PowerShell 5.1 / PowerShell 7 on Windows. No SQL Server module, Excel installation, or third-party PowerShell module is required. It queries the operating system, not the SQL engine; SQL does not need to be running for a reachable host to be scanned.

Use a dedicated account with approved remote CIM/WMI read access to each host and write access to the report folder. Local elevation alone does not grant remote access. Configure the permitted WinRM or WMI/DCOM paths with your Windows/security team; the script does not enable remote management, change firewall settings, bypass certificates, or change authentication policy.

Windows CIM cmdlets and their supported transports are documented here:
https://learn.microsoft.com/en-us/powershell/module/cimcmdlets/get-ciminstance
https://learn.microsoft.com/en-us/powershell/module/cimcmdlets/new-cimsessionoption
https://learn.microsoft.com/en-us/windows/win32/wmisdk/securing-a-remote-wmi-connection

## 2. Edit servers.txt

Use actual Windows computer names or FQDNs, one per line. Blank lines and # comments are ignored. Duplicate normalized names are removed case-insensitively. `HOST\INSTANCE` and `HOST,PORT` are normalized to `HOST`. Short names and FQDNs for the same host are not resolved/deduplicated against each other; use one consistent format.

Include each SQL node separately, including passive and DR nodes. An AG listener or SQL alias is not expanded into its backing hosts. This script is for Windows SQL hosts; it is not for Linux SQL hosts, Azure SQL Database, or Azure SQL Managed Instance.

## 3. Edit the configuration block

At the top of the script, under `EDIT THESE SETTINGS`, replace:

```powershell
SmtpServer = 'smtp.yourcompany.com'
SmtpPort   = 25
MailFrom   = 'dba-monitor@yourcompany.com'
MailTo     = @('DBA-Team@yourcompany.com')
MailCc     = @()
EnableSsl  = $true
```

For multiple recipients, use an array such as `@('DBA-Team@company.com','Operations@company.com')`.

Use your organization's approved SMTP relay and sender address. The relay may need to allow the collector's IP address and selected sender/recipients. STARTTLS is enabled by default. Set the port to whatever your relay administrators specify.

IMPORTANT MAIL LIMITATION: To stay self-contained on Windows PowerShell 5.1, this script uses .NET `SmtpClient` for an existing enterprise SMTP relay. Microsoft does not recommend `SmtpClient` for new mail integrations, and this implementation does not support OAuth. Do not point it at an OAuth-only Microsoft 365 mailbox endpoint and expect username/password sign-in to work. For an OAuth-only environment, the email function must be replaced with your approved Microsoft Graph or MailKit/OAuth integration. Do not disable your organization's authentication protections to accommodate this script.

`EnableSsl = $true` requests STARTTLS, not implicit TLS on port 465. A relay that does not advertise STARTTLS will reject the attempt. Do not bypass TLS certificate validation. Only set `EnableSsl = $false` for an explicitly approved, restricted internal non-TLS relay; the script prevents credential-based SMTP when TLS is disabled. It never silently falls back to unencrypted SMTP.

References:
https://learn.microsoft.com/en-us/dotnet/api/system.net.mail.smtpclient
https://learn.microsoft.com/en-us/dotnet/api/system.net.mail.smtpclient.enablessl

## 4. Test without email

Start with two or three hosts. In PowerShell:

```powershell
Set-Location 'D:\DBA\DriveSpaceReport'
.\Send-SQLDriveCapacityReport.ps1 -NoEmail -OpenReport
```

Review the HTML, CSVs, and collection errors. This still queries the real hosts, but sends no email and makes no server changes. `-OpenReport` is for an interactive session, not a scheduled task.

The first SMTP test should go to your own address before changing `MailTo` to the DBA distribution list.

A syntax-only check on the Windows runner (does not execute the script):

```powershell
$tokens = $null
$parseErrors = $null
$path = 'D:\DBA\DriveSpaceReport\Send-SQLDriveCapacityReport.ps1'
$null = [System.Management.Automation.Language.Parser]::ParseFile(
    $path, [ref]$tokens, [ref]$parseErrors
)
$parseErrors | Format-List
```

No output from `$parseErrors` means no parser errors were detected. Parsing does not validate remote connectivity, permissions, runtime behavior, or SMTP delivery. Use your organization's normal script signing/execution policy. Do not bypass policy or unblock a downloaded script without reviewing it.

## 5. Run and send the report

```powershell
.\Send-SQLDriveCapacityReport.ps1
```

By default, a report email is sent each run, including healthy runs. For alert-only delivery:

```powershell
.\Send-SQLDriveCapacityReport.ps1 -OnlySendOnAlert
```

Collection failures and unknown measurements also trigger alert-only delivery; failed hosts never suppress the email by being treated as healthy. Repeated unresolved alerts will send on every run. There is no alert suppression, acknowledgment tracking, or historical trend comparison.

For a WMI/DCOM-only environment:

```powershell
.\Send-SQLDriveCapacityReport.ps1 -ConnectionProtocol DCOM
```

For WSMan-only collection, use `-ConnectionProtocol WSMan`. The default `Auto` tries WSMan first and then DCOM if the volume query fails. It does not use ping as a prerequisite. `OperationTimeoutSec` is per CIM operation, not a strict wall-clock limit for the whole host or scan. Hosts are scanned sequentially; assess actual runtime before choosing the scheduled interval.

Optional interactive alternate credentials:

```powershell
$cimCred = Get-Credential
.\Send-SQLDriveCapacityReport.ps1 -CimCredential $cimCred -NoEmail
```

For an approved authenticated SMTP relay that supports this method:

```powershell
$smtpCred = Get-Credential
.\Send-SQLDriveCapacityReport.ps1 -SmtpCredential $smtpCred
```

Do not use interactive credential prompts for scheduled execution. Use the scheduled service identity for CIM and your approved relay authentication/credential-storage design. Do not put plaintext passwords in the script or task arguments.

## Thresholds and report contents

| Status | Default rule |
|---|---|
| CRITICAL / red | Free space below 10% |
| WARNING / amber | Free space at least 10% but below 20% |
| HEALTHY / green | Free space at least 20% |
| UNKNOWN / gray | Capacity/free space unavailable, invalid, or volume reported offline |

Exactly 20% free does not alert. Comparisons use full-precision percentages before rounding. The HTML displays two decimal places; a value just below a boundary can round to that boundary while correctly remaining in the lower status category.

Use parameters to change thresholds, for example:

```powershell
.\Send-SQLDriveCapacityReport.ps1 -WarningThreshold 25 -CriticalThreshold 10
```

`ReclaimToThresholdGB` is the space that must be freed to reach the warning threshold at the current volume size. It is rounded upward to 0.01 GB. It is NOT the disk expansion amount; expanding a volume changes the denominator. A volume at 1,000 GB with 60 GB free needs 140 GB reclaimed to reach 20% at the current size. If expanding without reclaiming data, it would need 175 GB additional capacity to reach 20%, before allowing for future growth.

Capacity columns labeled GB use 1,073,741,824 bytes (GiB), consistent with the PowerShell `1GB` constant. CSV includes raw byte values and full-precision numeric measurements for calculations.

Every run creates a unique timestamp/PID subfolder under `Reports` containing:

- `DriveCapacityReport.html`: full, color-formatted report.
- `AllDrives.csv`: complete volume inventory, including unknown results.
- `ActionRequired.csv`: only volumes below the warning threshold, lowest free percentage first.
- `CollectionIssues.csv`: connection/query/measurement problems; headers only when there are none.
- `ServerCoverage.csv`: COMPLETE, PARTIAL, or FAILED collection status for every listed host.
- `Run.log`: collection and SMTP submission outcome.

All four CSV files are attached. Local HTML includes all rows. Email sections display up to 150 rows each by default to avoid enormous messages; any truncation is labeled. Set `MaxInlineRowsPerSection = 0` for unlimited inline rows, subject to your mail system's message-size limits. Avoid very large inline reports; the CSV attachments are the complete source.

Report files contain internal infrastructure information. Restrict access to the output folder and recipients. The script does not delete old reports; apply your approved report-retention policy separately. Provider-supplied strings are HTML-encoded, and formula-like CSV text is prefixed with an apostrophe for safer spreadsheet viewing.

## Scope and operational limits

The inventory uses `Win32_Volume` with `DriveType = 3` and resolves directory mount points with `Win32_MountPoint`. It includes fixed local/SAN-presented volumes visible through the provider, even without drive letters. Unmounted/system/recovery volumes may appear as GUID paths. Removable media, optical drives, and mapped network drives are not included. File shares used for SQL storage require separate monitoring.

This is not a physical SAN capacity report. Each volume is deduplicated by volume ID within a host only; shared/CSV storage may appear on several hosts. An offline cluster disk not exposed by a passive node's WMI provider cannot be inferred. Collection completeness is relative to the listed hosts and volumes actually returned, not a proof that every expected storage device exists. Cross-check cluster-owned storage against your expected inventory and owning nodes.

If mount-point lookup fails, valid capacity results are retained with the best available drive/path/GUID, and the server is marked PARTIAL. Failed hosts do not receive zero-capacity/healthy rows. Null free space is not converted to zero.

Schema references:
https://learn.microsoft.com/en-us/previous-versions/windows/desktop/vdswmi/win32-volume
https://learn.microsoft.com/en-us/previous-versions/windows/desktop/vdswmi/win32-mountpoint

## Scheduling

After a successful pilot and mail test, create a task in Windows Task Scheduler:

- Run under the approved monitoring/service account with remote read access.
- Choose "Run whether user is logged on or not" using your approved service-account method.
- If using a regular domain account, the "Do not store password" option restricts network resource access; do not select it when this task needs that account's network credentials.
- Trigger: daily, repeating every 30 minutes indefinitely, or your approved interval. Measure actual scan time first.
- Program: `C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe`
- Arguments: `-NoProfile -NonInteractive -File "D:\DBA\DriveSpaceReport\Send-SQLDriveCapacityReport.ps1" -OnlySendOnAlert`
- Start in: `D:\DBA\DriveSpaceReport`
- When a task is already running: do not start a new instance.
- Do not enable `-OpenReport` for scheduled execution.

Absolute paths and a non-overlapping schedule prevent common unattended-run problems. Do not configure indiscriminate restart-on-failure if exit code 2 would cause unwanted duplicate alert emails.

Exit codes: `0` = completed (may include low-space alerts); `1` = configuration, report, or SMTP failure; `2` = report completed with partial/failed collection. An SMTP failure takes precedence over collection exit code 2. "Email accepted by SMTP relay" indicates successful submission, not guaranteed final mailbox delivery.

## Validation status

The script was authored and statically reviewed, but it has not been executed on a Windows PowerShell host or against your actual servers/SMTP relay here. The preview uses invented sample data. Validate syntax on your Windows runner, perform a small `-NoEmail` pilot, verify a test email, and then schedule.
