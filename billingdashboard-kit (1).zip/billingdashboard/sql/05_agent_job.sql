/* =====================================================================
   05_agent_job.sql  -  SQL Agent job "billingdashboard - Collect"
   >>> Run in SQLCMD MODE (SSMS: Query > SQLCMD Mode) <<<
   >>> Run on EACH of the 4 AG nodes, connected to the node directly
       (NOT the listener). The job only does work on the primary.   <<<

   Creates on this node:
     credential  billingdashboard_cred   (CALSB\svc_billingdashboard)
     proxy       billingdashboard_proxy  (CmdExec)
     job         billingdashboard - Collect
     schedule    billingdashboard - every 2 min
   ===================================================================== */
:setvar SvcAccount   "CALSB\svc_billingdashboard"
:setvar SvcPassword  "<type the password here, run, then delete it - do not save>"
:setvar ScriptPath   "D:\DBA\billingdashboard\Export-dbo.ps1"
:setvar OutFile      "\\AZDBAPRD01\billingdashboard$\data.json"
:setvar JobOwner     "sa"

USE master;
GO
/* ---- credential + proxy for the export step ---------------------- */
IF EXISTS (SELECT 1 FROM sys.credentials WHERE name = N'billingdashboard_cred')
    ALTER CREDENTIAL billingdashboard_cred WITH IDENTITY = N'$(SvcAccount)', SECRET = N'$(SvcPassword)';
ELSE
    CREATE CREDENTIAL billingdashboard_cred WITH IDENTITY = N'$(SvcAccount)', SECRET = N'$(SvcPassword)';
GO
USE msdb;
GO
IF NOT EXISTS (SELECT 1 FROM msdb.dbo.sysproxies WHERE name = N'billingdashboard_proxy')
BEGIN
    EXEC msdb.dbo.sp_add_proxy @proxy_name = N'billingdashboard_proxy',
         @credential_name = N'billingdashboard_cred', @enabled = 1,
         @description = N'Runs Export-dbo.ps1 as CALSB\svc_billingdashboard';
    EXEC msdb.dbo.sp_grant_proxy_to_subsystem @proxy_name = N'billingdashboard_proxy',
         @subsystem_name = N'CmdExec';
END;
GO

/* ---- job ----------------------------------------------------------- */
DECLARE @jobId uniqueidentifier, @cmd nvarchar(2000);

IF EXISTS (SELECT 1 FROM msdb.dbo.sysjobs WHERE name = N'billingdashboard - Collect')
    EXEC msdb.dbo.sp_delete_job @job_name = N'billingdashboard - Collect', @delete_unused_schedule = 1;

EXEC msdb.dbo.sp_add_job
     @job_name = N'billingdashboard - Collect', @enabled = 1,
     @description = N'Collects online payment activity + SQL health into the billingdashboard database and writes data.json for the billing dashboard.',
     @owner_login_name = N'$(JobOwner)', @job_id = @jobId OUTPUT;

/* Step 1: only the AG primary for billingdashboard continues */
EXEC msdb.dbo.sp_add_jobstep
     @job_id = @jobId, @step_name = N'1 - Primary check', @subsystem = N'TSQL',
     @database_name = N'master',
     @command = N'IF ISNULL(sys.fn_hadr_is_primary_replica(N''billingdashboard''), 1) = 0
    THROW 50001, N''Not the primary replica for billingdashboard - skipping.'', 1;',
     @on_success_action = 3,   -- next step
     @on_fail_action    = 1;   -- quit reporting success (secondary = normal)

/* Step 2: collect */
EXEC msdb.dbo.sp_add_jobstep
     @job_id = @jobId, @step_name = N'2 - Collect', @subsystem = N'TSQL',
     @database_name = N'billingdashboard',
     @command = N'EXEC dbo.usp_Collect;',
     @on_success_action = 3, @on_fail_action = 3;

/* Step 3: write data.json (runs as CALSB\svc_billingdashboard) */
SET @cmd = N'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$(ScriptPath)" -SqlInstance "SFDBSLISTN01" -Database "billingdashboard" -OutFile "$(OutFile)"';
EXEC msdb.dbo.sp_add_jobstep
     @job_id = @jobId, @step_name = N'3 - Export data.json', @subsystem = N'CmdExec',
     @command = @cmd, @proxy_name = N'billingdashboard_proxy',
     @on_success_action = 1, @on_fail_action = 2;

EXEC msdb.dbo.sp_add_jobschedule
     @job_id = @jobId, @name = N'billingdashboard - every 2 min',
     @freq_type = 4, @freq_interval = 1,
     @freq_subday_type = 4, @freq_subday_interval = 2,
     @active_start_time = 0;

EXEC msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)';
GO

SELECT j.name, j.enabled, s.name AS schedule_name
FROM msdb.dbo.sysjobs j
JOIN msdb.dbo.sysjobschedules js ON js.job_id = j.job_id
JOIN msdb.dbo.sysschedules s ON s.schedule_id = js.schedule_id
WHERE j.name = N'billingdashboard - Collect';
