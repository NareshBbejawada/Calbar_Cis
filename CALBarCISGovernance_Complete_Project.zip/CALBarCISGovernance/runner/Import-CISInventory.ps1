[CmdletBinding()]param([string]$InventoryFile='E:\CALBarCISGovernance\Inventory\SQLServers.txt',[string]$RepositoryServer='LASQLCL3\ODYDEV',[string]$RepositoryDatabase='CALBAR_SQL_CIS')
$ErrorActionPreference='Stop'; Import-Module SqlServer
$items=Get-Content $InventoryFile|%{$_.Trim()}|?{$_ -and -not $_.StartsWith('#')}|Sort-Object -Unique
foreach($instance in $items){$v=$instance.Replace("'","''");$q="IF EXISTS(SELECT 1 FROM inv.SQL_Server_Inventory WHERE ServerInstance=N'$v') UPDATE inv.SQL_Server_Inventory SET IsEnabled=1,ModifiedAtUtc=SYSUTCDATETIME() WHERE ServerInstance=N'$v'; ELSE INSERT inv.SQL_Server_Inventory(ServerInstance) VALUES(N'$v');";Invoke-Sqlcmd -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $q -TrustServerCertificate -AbortOnError}
Write-Host "Imported $($items.Count) SQL instances."
