[CmdletBinding()]param([string]$RepositoryServer='LASQLCL3\ODYDEV',[string]$RepositoryDatabase='CALBAR_SQL_CIS',[string]$LogFolder='E:\CALBarCISGovernance\Runner\Logs')
$ErrorActionPreference='Stop'; Import-Module SqlServer; New-Item $LogFolder -ItemType Directory -Force|Out-Null; $log=Join-Path $LogFolder ("CISRunner_{0:yyyyMMdd_HHmmss}.log"-f(Get-Date)); Start-Transcript $log
try{
 $run=(Invoke-Sqlcmd -ServerInstance $RepositoryServer -Database $RepositoryDatabase -TrustServerCertificate -Query "INSERT audit.CIS_Run(StartedBy) OUTPUT inserted.RunId VALUES(SUSER_SNAME())").RunId
 $servers=Invoke-Sqlcmd -ServerInstance $RepositoryServer -Database $RepositoryDatabase -TrustServerCertificate -Query "SELECT ServerId,ServerInstance FROM inv.SQL_Server_Inventory WHERE IsEnabled=1 ORDER BY ServerInstance"
 $controls=Invoke-Sqlcmd -ServerInstance $RepositoryServer -Database $RepositoryDatabase -TrustServerCertificate -Query "SELECT ControlId,ControlCode,ExpectedValue,CheckType,CheckQuery,MinimumMajorVersion FROM cfg.CIS_Control_Definition WHERE IsEnabled=1 ORDER BY SortOrder"
 $count=0
 foreach($s in $servers){
  Write-Host "Scanning $($s.ServerInstance)"
  $major=$null; try{$major=[int](Invoke-Sqlcmd -ServerInstance $s.ServerInstance -Database master -TrustServerCertificate -Query "SELECT CAST(SERVERPROPERTY('ProductMajorVersion') AS int) Major" -QueryTimeout 20).Major}catch{}
  foreach($c in $controls){$status='ERROR';$actual=$null;$err=$null
   try{if($c.MinimumMajorVersion -and $major -lt [int]$c.MinimumMajorVersion){$status='PASS';$actual='Not applicable'}else{$row=Invoke-Sqlcmd -ServerInstance $s.ServerInstance -Database master -TrustServerCertificate -Query $c.CheckQuery -QueryTimeout 30 -ErrorAction Stop;$actual=[string]$row.ActualValue; switch($c.CheckType){'MINIMUM'{$status=if([decimal]$actual -ge [decimal]$c.ExpectedValue){'PASS'}else{'FAIL'}}'SET'{$status=if(($c.ExpectedValue-split ',') -contains $actual){'PASS'}else{'FAIL'}}default{$status=if($actual -eq [string]$c.ExpectedValue){'PASS'}else{'FAIL'}}}}}catch{$err=$_.Exception.Message}
   $a=if($null-eq$actual){'NULL'}else{"N'"+$actual.Replace("'","''")+"'"};$e=if($null-eq$err){'NULL'}else{"N'"+$err.Replace("'","''").Substring(0,[Math]::Min(3900,$err.Length))+"'"};$expected=[string]$c.ExpectedValue;$expected=$expected.Replace("'","''")
   $q="INSERT audit.CIS_Compliance_Result(RunId,ServerId,ControlId,Status,ActualValue,ExpectedValue,ErrorMessage) VALUES($run,$($s.ServerId),$($c.ControlId),'$status',$a,N'$expected',$e);";Invoke-Sqlcmd -ServerInstance $RepositoryServer -Database $RepositoryDatabase -TrustServerCertificate -Query $q; $count++
  }
 }
 Invoke-Sqlcmd -ServerInstance $RepositoryServer -Database $RepositoryDatabase -TrustServerCertificate -Query "UPDATE audit.CIS_Run SET CompletedAtUtc=SYSUTCDATETIME(),ServerCount=$($servers.Count),ResultCount=$count,RunStatus='COMPLETED' WHERE RunId=$run"
 Write-Host "Completed run $run with $count results."
}catch{if($run){Invoke-Sqlcmd -ServerInstance $RepositoryServer -Database $RepositoryDatabase -TrustServerCertificate -Query "UPDATE audit.CIS_Run SET CompletedAtUtc=SYSUTCDATETIME(),RunStatus='FAILED' WHERE RunId=$run" -ErrorAction SilentlyContinue};throw}finally{Stop-Transcript}
