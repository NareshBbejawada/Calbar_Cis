USE CALBAR_SQL_CIS;
GO
MERGE cfg.CIS_Control_Definition AS t USING (VALUES
('CIS-2.6','Remote Access disabled','0','CONFIG',N'SELECT CAST(value_in_use AS nvarchar(100)) ActualValue FROM sys.configurations WHERE name=''remote access''',NULL,10),
('CIS-2.7','Remote Admin Connections disabled','0','CONFIG',N'SELECT CAST(value_in_use AS nvarchar(100)) ActualValue FROM sys.configurations WHERE name=''remote admin connections''',NULL,20),
('CIS-2.8','Scan for startup procs disabled','0','CONFIG',N'SELECT CAST(value_in_use AS nvarchar(100)) ActualValue FROM sys.configurations WHERE name=''scan for startup procs''',NULL,30),
('CIS-2.9','Cross DB ownership chaining disabled','0','CONFIG',N'SELECT CAST(value_in_use AS nvarchar(100)) ActualValue FROM sys.configurations WHERE name=''cross db ownership chaining''',NULL,40),
('CIS-3.2','Trustworthy databases absent','0','SCALAR',N'SELECT CAST(COUNT(*) AS nvarchar(100)) ActualValue FROM sys.databases WHERE is_trustworthy_on=1 AND name<>''msdb''',NULL,50),
('CIS-3.4','SA login disabled','0','SCALAR',N'SELECT CAST(COUNT(*) AS nvarchar(100)) ActualValue FROM sys.server_principals WHERE sid=0x01 AND is_disabled=0',NULL,60),
('CIS-3.5','Public server permissions restricted','0','SCALAR',N'SELECT CAST(COUNT(*) AS nvarchar(100)) ActualValue FROM sys.server_permissions p JOIN sys.server_principals sp ON p.grantee_principal_id=sp.principal_id WHERE sp.name=''public'' AND p.permission_name NOT IN(''VIEW ANY DATABASE'',''CONNECT'',''CONNECT SQL'')',NULL,70),
('CIS-5.1','Maximum error log files at least 12','12','MINIMUM',N'DECLARE @n int; EXEC master.sys.xp_instance_regread N''HKEY_LOCAL_MACHINE'',N''Software\Microsoft\MSSQLServer\MSSQLServer'',N''NumErrorLogs'',@n OUTPUT; SELECT CAST(COALESCE(@n,6) AS nvarchar(100)) ActualValue',NULL,80),
('CIS-5.2','Default trace enabled','1','CONFIG',N'SELECT CAST(value_in_use AS nvarchar(100)) ActualValue FROM sys.configurations WHERE name=''default trace enabled''',NULL,90),
('CIS-5.3','Login auditing includes failed logins','2,3','SET',N'DECLARE @v int; EXEC master.sys.xp_instance_regread N''HKEY_LOCAL_MACHINE'',N''Software\Microsoft\MSSQLServer\MSSQLServer'',N''AuditLevel'',@v OUTPUT; SELECT CAST(@v AS nvarchar(100)) ActualValue',NULL,100),
('CIS-2.2','Ad Hoc Distributed Queries disabled','0','CONFIG',N'SELECT CAST(value_in_use AS nvarchar(100)) ActualValue FROM sys.configurations WHERE name=''Ad Hoc Distributed Queries''',NULL,110),
('CIS-2.3','CLR disabled','0','CONFIG',N'SELECT CAST(value_in_use AS nvarchar(100)) ActualValue FROM sys.configurations WHERE name=''clr enabled''',NULL,120),
('CIS-2.4','OLE Automation disabled','0','CONFIG',N'SELECT CAST(value_in_use AS nvarchar(100)) ActualValue FROM sys.configurations WHERE name=''Ole Automation Procedures''',NULL,130),
('CIS-2.5','xp_cmdshell disabled','0','CONFIG',N'SELECT CAST(value_in_use AS nvarchar(100)) ActualValue FROM sys.configurations WHERE name=''xp_cmdshell''',NULL,140),
('CIS-2.10','CLR strict security enabled','1','CONFIG',N'SELECT CAST(value_in_use AS nvarchar(100)) ActualValue FROM sys.configurations WHERE name=''clr strict security''',14,150)
) s(ControlCode,ControlName,ExpectedValue,CheckType,CheckQuery,MinimumMajorVersion,SortOrder)
ON t.ControlCode=s.ControlCode WHEN MATCHED THEN UPDATE SET ControlName=s.ControlName,ExpectedValue=s.ExpectedValue,CheckType=s.CheckType,CheckQuery=s.CheckQuery,MinimumMajorVersion=s.MinimumMajorVersion,SortOrder=s.SortOrder,IsEnabled=1
WHEN NOT MATCHED THEN INSERT(ControlCode,ControlName,ExpectedValue,CheckType,CheckQuery,MinimumMajorVersion,SortOrder) VALUES(s.ControlCode,s.ControlName,s.ExpectedValue,s.CheckType,s.CheckQuery,s.MinimumMajorVersion,s.SortOrder);
GO
