USE master;
-- Replace domain identities before execution.
-- CREATE LOGIN [CALSB\gmsa-cisweb$] FROM WINDOWS;
-- CREATE LOGIN [CALSB\gmsa-cisrunner$] FROM WINDOWS;
GO
USE CALBAR_SQL_CIS;
-- CREATE USER [CALSB\gmsa-cisweb$] FOR LOGIN [CALSB\gmsa-cisweb$];
-- ALTER ROLE db_datareader ADD MEMBER [CALSB\gmsa-cisweb$];
-- CREATE USER [CALSB\gmsa-cisrunner$] FOR LOGIN [CALSB\gmsa-cisrunner$];
-- ALTER ROLE db_datareader ADD MEMBER [CALSB\gmsa-cisrunner$];
-- ALTER ROLE db_datawriter ADD MEMBER [CALSB\gmsa-cisrunner$];
GO
