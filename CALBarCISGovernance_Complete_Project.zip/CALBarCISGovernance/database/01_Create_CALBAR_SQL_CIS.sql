USE master;
IF DB_ID(N'CALBAR_SQL_CIS') IS NULL CREATE DATABASE CALBAR_SQL_CIS;
GO
ALTER DATABASE CALBAR_SQL_CIS SET RECOVERY SIMPLE, AUTO_CLOSE OFF, AUTO_SHRINK OFF, PAGE_VERIFY CHECKSUM;
GO
USE CALBAR_SQL_CIS;
GO
IF NOT EXISTS(SELECT 1 FROM sys.schemas WHERE name='inv') EXEC('CREATE SCHEMA inv');
IF NOT EXISTS(SELECT 1 FROM sys.schemas WHERE name='cfg') EXEC('CREATE SCHEMA cfg');
IF NOT EXISTS(SELECT 1 FROM sys.schemas WHERE name='audit') EXEC('CREATE SCHEMA audit');
IF NOT EXISTS(SELECT 1 FROM sys.schemas WHERE name='rpt') EXEC('CREATE SCHEMA rpt');
GO
CREATE TABLE inv.SQL_Server_Inventory(ServerId int IDENTITY PRIMARY KEY,ServerInstance nvarchar(256) NOT NULL UNIQUE,Environment nvarchar(30) NOT NULL CONSTRAINT DF_Inv_Env DEFAULT('Unknown'),IsEnabled bit NOT NULL CONSTRAINT DF_Inv_Enabled DEFAULT(1),Notes nvarchar(1000) NULL,CreatedAtUtc datetime2(0) NOT NULL CONSTRAINT DF_Inv_Created DEFAULT SYSUTCDATETIME(),ModifiedAtUtc datetime2(0) NOT NULL CONSTRAINT DF_Inv_Modified DEFAULT SYSUTCDATETIME());
CREATE TABLE cfg.CIS_Control_Definition(ControlId int IDENTITY PRIMARY KEY,ControlCode varchar(30) NOT NULL UNIQUE,ControlName nvarchar(250) NOT NULL,Description nvarchar(1000) NULL,ExpectedValue nvarchar(100) NOT NULL,CheckType varchar(30) NOT NULL,CheckQuery nvarchar(max) NOT NULL,MinimumMajorVersion int NULL,IsEnabled bit NOT NULL CONSTRAINT DF_Control_Enabled DEFAULT(1),SortOrder int NOT NULL);
CREATE TABLE audit.CIS_Run(RunId bigint IDENTITY PRIMARY KEY,StartedAtUtc datetime2(0) NOT NULL DEFAULT SYSUTCDATETIME(),CompletedAtUtc datetime2(0) NULL,StartedBy nvarchar(256) NULL,ServerCount int NULL,ResultCount int NULL,RunStatus varchar(20) NOT NULL DEFAULT('RUNNING'));
CREATE TABLE audit.CIS_Compliance_Result(ResultId bigint IDENTITY PRIMARY KEY,RunId bigint NOT NULL,ServerId int NOT NULL,ControlId int NOT NULL,Status varchar(10) NOT NULL,ActualValue nvarchar(4000) NULL,ExpectedValue nvarchar(100) NULL,ErrorMessage nvarchar(4000) NULL,CheckedAtUtc datetime2(0) NOT NULL DEFAULT SYSUTCDATETIME(),CONSTRAINT FK_Result_Run FOREIGN KEY(RunId) REFERENCES audit.CIS_Run(RunId),CONSTRAINT FK_Result_Server FOREIGN KEY(ServerId) REFERENCES inv.SQL_Server_Inventory(ServerId),CONSTRAINT FK_Result_Control FOREIGN KEY(ControlId) REFERENCES cfg.CIS_Control_Definition(ControlId));
CREATE INDEX IX_Result_Latest ON audit.CIS_Compliance_Result(ServerId,ControlId,CheckedAtUtc DESC) INCLUDE(Status,ActualValue,ExpectedValue,ErrorMessage);
GO
CREATE OR ALTER VIEW rpt.vw_CIS_Latest_Compliance_Result AS
WITH x AS(SELECT r.*,ROW_NUMBER() OVER(PARTITION BY r.ServerId,r.ControlId ORDER BY r.CheckedAtUtc DESC,r.ResultId DESC) rn FROM audit.CIS_Compliance_Result r)
SELECT x.ResultId,x.RunId,i.ServerInstance,c.ControlCode,c.ControlName,x.Status,x.ActualValue,x.ExpectedValue,x.ErrorMessage,x.CheckedAtUtc
FROM x JOIN inv.SQL_Server_Inventory i ON x.ServerId=i.ServerId JOIN cfg.CIS_Control_Definition c ON x.ControlId=c.ControlId WHERE x.rn=1;
GO
