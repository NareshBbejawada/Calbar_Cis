# Run as Administrator
$features='Web-Server','Web-Windows-Auth','Web-Mgmt-Console','Web-Default-Doc','Web-Static-Content','Web-Http-Logging','Web-Filtering','Web-Stat-Compression','Web-Dyn-Compression','Web-ISAPI-Ext','Web-ISAPI-Filter'
Install-WindowsFeature $features -IncludeManagementTools
Write-Host 'Install the x64 .NET 10 Hosting Bundle, then reboot if requested.'
if(-not(Get-Module SqlServer -ListAvailable)){Install-PackageProvider NuGet -Force;Set-PSRepository PSGallery -InstallationPolicy Trusted;Install-Module SqlServer -Scope AllUsers -Force}
