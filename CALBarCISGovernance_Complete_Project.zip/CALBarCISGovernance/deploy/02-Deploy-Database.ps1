param([string]$RepositoryServer='LASQLCL3\ODYDEV',[string]$ProjectRoot='E:\CALBarCISGovernance')
Import-Module SqlServer
Invoke-Sqlcmd -ServerInstance $RepositoryServer -Database master -InputFile "$ProjectRoot\Database\01_Create_CALBAR_SQL_CIS.sql" -TrustServerCertificate -AbortOnError
Invoke-Sqlcmd -ServerInstance $RepositoryServer -Database CALBAR_SQL_CIS -InputFile "$ProjectRoot\Database\02_Seed_CIS_Controls.sql" -TrustServerCertificate -AbortOnError
Write-Host 'Database and controls deployed.'
