param([string]$RepositoryServer='LASQLCL3\ODYDEV',[string]$Url='http://azdbaprd01.calsb.org')
Import-Module SqlServer
Invoke-Sqlcmd -ServerInstance $RepositoryServer -Database CALBAR_SQL_CIS -TrustServerCertificate -Query "SELECT (SELECT COUNT(*) FROM inv.SQL_Server_Inventory) Inventory,(SELECT COUNT(*) FROM cfg.CIS_Control_Definition) Controls,(SELECT COUNT(*) FROM audit.CIS_Compliance_Result) Results,(SELECT COUNT(*) FROM rpt.vw_CIS_Latest_Compliance_Result) Latest"
Invoke-WebRequest $Url -UseDefaultCredentials | Select StatusCode,StatusDescription
