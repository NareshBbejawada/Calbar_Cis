param([string]$ProjectRoot='E:\CALBarCISGovernance',[string]$SiteName='CALBarCISGovernance',[string]$HostName='azdbaprd01.calsb.org')
$ErrorActionPreference='Stop';$src="$ProjectRoot\Source\CALBar.CIS.Web";$publish="$ProjectRoot\UI"
& 'C:\Program Files\dotnet\dotnet.exe' publish $src -c Release -o $publish --self-contained false
Import-Module WebAdministration
if(-not(Test-Path "IIS:\AppPools\$SiteName")){New-WebAppPool $SiteName}
Set-ItemProperty "IIS:\AppPools\$SiteName" managedRuntimeVersion ''
Set-ItemProperty "IIS:\AppPools\$SiteName" processModel.identityType ApplicationPoolIdentity
icacls $publish /grant "IIS AppPool\${SiteName}:(OI)(CI)(RX)" /T
if(Get-Website $SiteName -ErrorAction SilentlyContinue){Remove-Website $SiteName}
New-Website -Name $SiteName -PhysicalPath $publish -ApplicationPool $SiteName -Port 80 -HostHeader $HostName
Set-WebConfigurationProperty -Filter /system.webServer/security/authentication/anonymousAuthentication -PSPath IIS:\ -Location $SiteName -Name enabled -Value false
Set-WebConfigurationProperty -Filter /system.webServer/security/authentication/windowsAuthentication -PSPath IIS:\ -Location $SiteName -Name enabled -Value true
Start-WebAppPool $SiteName;Start-Website $SiteName
Write-Host "Website deployed: http://$HostName"
