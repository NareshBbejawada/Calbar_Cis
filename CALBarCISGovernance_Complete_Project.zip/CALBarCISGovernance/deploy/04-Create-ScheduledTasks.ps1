param([string]$ProjectRoot='E:\CALBarCISGovernance',[string]$RunAsAccount='SYSTEM')
$a1=New-ScheduledTaskAction -Execute powershell.exe -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$ProjectRoot\Runner\Import-CISInventory.ps1`""
$t1=New-ScheduledTaskTrigger -Daily -At 1am
Register-ScheduledTask -TaskName 'CALBar CIS Inventory Import' -Action $a1 -Trigger $t1 -User $RunAsAccount -RunLevel Highest -Force
$a2=New-ScheduledTaskAction -Execute powershell.exe -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$ProjectRoot\Runner\Invoke-CISRunner.ps1`""
$t2=New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(2) -RepetitionInterval (New-TimeSpan -Minutes 30)
Register-ScheduledTask -TaskName 'CALBar CIS Governance Runner' -Action $a2 -Trigger $t2 -User $RunAsAccount -RunLevel Highest -Force
