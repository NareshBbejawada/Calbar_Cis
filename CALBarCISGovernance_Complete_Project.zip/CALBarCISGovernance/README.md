# CAL Bar SQL CIS Governance
Standalone .NET 10/IIS project for `azdbaprd01.calsb.org`, repository `LASQLCL3\ODYDEV`, database `CALBAR_SQL_CIS`, and text-file inventory.

## Server deployment layout
Copy the package contents to `E:\CALBarCISGovernance` using these target names:
- `src` -> `E:\CALBarCISGovernance\Source`
- `database` -> `E:\CALBarCISGovernance\Database`
- `runner` -> `E:\CALBarCISGovernance\Runner`
- `inventory` -> `E:\CALBarCISGovernance\Inventory`
- `deploy` -> `E:\CALBarCISGovernance\Deploy`

## Execute in order
1. `Deploy\01-Install-Prerequisites.ps1`
2. Confirm `C:\Program Files\dotnet\dotnet.exe --info` and .NET 10 SDK are installed. The SDK is needed to publish on the server.
3. `Deploy\02-Deploy-Database.ps1`
4. Edit `Inventory\SQLServers.txt`, then run `Runner\Import-CISInventory.ps1`.
5. Grant the runner identity read access on each target SQL instance and write access to `CALBAR_SQL_CIS`.
6. Run `Runner\Invoke-CISRunner.ps1` manually and confirm results.
7. `Deploy\03-Publish-Web.ps1`
8. Grant `CALSB\AZDBAPRD01$` or the selected app-pool gMSA `db_datareader` in `CALBAR_SQL_CIS`.
9. `Deploy\04-Create-ScheduledTasks.ps1` using an approved domain/gMSA account rather than SYSTEM for production.
10. `Deploy\05-Validate.ps1`.

The runner is audit-only and never changes SQL Server configuration.
