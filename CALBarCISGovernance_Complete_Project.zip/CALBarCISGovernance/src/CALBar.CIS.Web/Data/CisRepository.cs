using Microsoft.Data.SqlClient;
using CALBar.CIS.Web.Models;
namespace CALBar.CIS.Web.Data;
public sealed class CisRepository(IConfiguration config)
{
 private readonly string _cs=config.GetConnectionString("CISGovernance") ?? throw new InvalidOperationException("Missing CISGovernance connection string");
 public async Task<DashboardVm> GetDashboardAsync(){ await using var c=new SqlConnection(_cs); await c.OpenAsync();
  const string q="SELECT (SELECT COUNT(*) FROM inv.SQL_Server_Inventory WHERE IsEnabled=1),(SELECT COUNT(*) FROM cfg.CIS_Control_Definition WHERE IsEnabled=1),(SELECT COUNT(*) FROM rpt.vw_CIS_Latest_Compliance_Result WHERE Status='PASS'),(SELECT COUNT(*) FROM rpt.vw_CIS_Latest_Compliance_Result WHERE Status='FAIL'),(SELECT COUNT(*) FROM rpt.vw_CIS_Latest_Compliance_Result WHERE Status='ERROR'),(SELECT MAX(CheckedAtUtc) FROM audit.CIS_Compliance_Result);";
  await using var cmd=new SqlCommand(q,c); await using var r=await cmd.ExecuteReaderAsync(); await r.ReadAsync();
  return new(r.GetInt32(0),r.GetInt32(1),r.GetInt32(2),r.GetInt32(3),r.GetInt32(4),r.IsDBNull(5)?null:r.GetDateTime(5)); }
 public async Task<List<ComplianceRow>> GetLatestAsync(string? status=null){var list=new List<ComplianceRow>(); await using var c=new SqlConnection(_cs); await c.OpenAsync();
  var q="SELECT ServerInstance,ControlCode,ControlName,Status,ActualValue,ExpectedValue,ErrorMessage,CheckedAtUtc FROM rpt.vw_CIS_Latest_Compliance_Result"+(string.IsNullOrWhiteSpace(status)?"":" WHERE Status=@s")+" ORDER BY ServerInstance,ControlCode";
  await using var cmd=new SqlCommand(q,c); if(!string.IsNullOrWhiteSpace(status))cmd.Parameters.AddWithValue("@s",status); await using var r=await cmd.ExecuteReaderAsync(); while(await r.ReadAsync())list.Add(new(r.GetString(0),r.GetString(1),r.GetString(2),r.GetString(3),r.IsDBNull(4)?null:r.GetString(4),r.IsDBNull(5)?null:r.GetString(5),r.IsDBNull(6)?null:r.GetString(6),r.GetDateTime(7))); return list;}
 public async Task<List<InventoryRow>> GetInventoryAsync(){var list=new List<InventoryRow>(); await using var c=new SqlConnection(_cs); await c.OpenAsync(); await using var cmd=new SqlCommand("SELECT ServerId,ServerInstance,Environment,IsEnabled,CreatedAtUtc FROM inv.SQL_Server_Inventory ORDER BY ServerInstance",c); await using var r=await cmd.ExecuteReaderAsync(); while(await r.ReadAsync())list.Add(new(r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetBoolean(3),r.GetDateTime(4))); return list;}
}
