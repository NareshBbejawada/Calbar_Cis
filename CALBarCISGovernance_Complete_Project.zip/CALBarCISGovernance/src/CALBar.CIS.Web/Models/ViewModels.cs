namespace CALBar.CIS.Web.Models;
public record DashboardVm(int Servers,int Controls,int Passed,int Failed,int Errors,DateTime? LastRun);
public record ComplianceRow(string ServerInstance,string ControlCode,string ControlName,string Status,string? ActualValue,string? ExpectedValue,string? ErrorMessage,DateTime CheckedAtUtc);
public record InventoryRow(int ServerId,string ServerInstance,string Environment,bool IsEnabled,DateTime CreatedAtUtc);
