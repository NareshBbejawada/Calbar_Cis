using Microsoft.AspNetCore.Mvc; using CALBar.CIS.Web.Data;
namespace CALBar.CIS.Web.Controllers;
public class ReportsController(CisRepository repo):Controller { public async Task<IActionResult> Index(string? status=null){ViewBag.Status=status; return View(await repo.GetLatestAsync(status));} }
