using Microsoft.AspNetCore.Mvc; using CALBar.CIS.Web.Data;
namespace CALBar.CIS.Web.Controllers;
public class InventoryController(CisRepository repo):Controller { public async Task<IActionResult> Index()=>View(await repo.GetInventoryAsync()); }
