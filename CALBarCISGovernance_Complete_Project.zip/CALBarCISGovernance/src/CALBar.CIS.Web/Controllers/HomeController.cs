using Microsoft.AspNetCore.Mvc; using CALBar.CIS.Web.Data;
namespace CALBar.CIS.Web.Controllers;
public class HomeController(CisRepository repo):Controller { public async Task<IActionResult> Index()=>View(await repo.GetDashboardAsync()); public IActionResult Error()=>View(); }
