/* =====================================================================
   09_proactive.sql  -  more proactive checks (kit v5, 2026-11-19)
   Run on the LISTENER SFDBSLISTN01 (normal mode), after 01, 02, 03, 07
   of this kit (or simply run upgrade_v5.sql). Changes ONLY the
   billingdashboard database; reads DMVs, msdb is not touched. Re-runnable.

   Adds
     dbo.usp_CollectCapacity    CPU, log space, disk free (every 2 min)
     dbo.usp_EvaluateProactive  6 more rules, called by usp_EvaluateAlerts:
        APP_QUIET        one application stopped taking payments
        WEB_NODE_SILENT  a DMZ web server stopped talking to SQL
        LOG_SPACE        transaction log filling (shows log_reuse_wait)
        DISK_SPACE       volume holding a watched database running low
        CPU_HIGH         10-minute average CPU high
        JOB_LATE         card / ACH report not processed, GEORGE posting late
   ===================================================================== */
USE billingdashboard;
GO

/* =====================================================================
   1. Capacity collection
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.usp_CollectCapacity
    @now datetime2(0) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET @now = ISNULL(@now, SYSDATETIME());

    DECLARE @every int = ISNULL(TRY_CAST(dbo.fn_Cfg(N'CapacityEveryMinutes') AS int), 2);
    IF EXISTS (SELECT 1 FROM dbo.CpuSnapshot WHERE SnapTs > DATEADD(SECOND, 30 - @every * 60, @now))
        RETURN -1;

    DECLARE @dbs nvarchar(500) = N',' + REPLACE(ISNULL(dbo.fn_Cfg(N'CapacityDatabases'), N'Billing_V2'), N' ', N'') + N',';
    DECLARE @rows int = 0;

    /* CPU: newest scheduler-monitor sample (SQL Server writes one per minute) */
    INSERT dbo.CpuSnapshot (SnapTs, SqlPct, OtherPct)
    SELECT TOP (1) @now, x.sqlp,
           CASE WHEN 100 - x.idle - x.sqlp < 0 THEN 0 ELSE 100 - x.idle - x.sqlp END
    FROM (SELECT r.[timestamp],
                 sqlp = y.rec.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int'),
                 idle = y.rec.value('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]', 'int')
          FROM sys.dm_os_ring_buffers r
          CROSS APPLY (SELECT CONVERT(xml, r.record) AS rec) y
          WHERE r.ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR'
            AND r.record LIKE N'%<SystemHealth>%') x
    WHERE x.sqlp IS NOT NULL AND x.idle IS NOT NULL
    ORDER BY x.[timestamp] DESC;
    SET @rows += @@ROWCOUNT;

    /* Log space for the watched databases */
    CREATE TABLE #l (DbName sysname, LogSizeMb float, UsedPct float, Status int);
    INSERT #l EXEC (N'DBCC SQLPERF(LOGSPACE) WITH NO_INFOMSGS');
    INSERT dbo.LogSpaceSnapshot (SnapTs, DbName, LogSizeMb, UsedPct, ReuseWait)
    SELECT @now, l.DbName, CAST(l.LogSizeMb AS decimal(12,1)), CAST(l.UsedPct AS decimal(5,1)), d.log_reuse_wait_desc
    FROM #l l
    LEFT JOIN sys.databases d ON d.name = l.DbName
    WHERE @dbs LIKE N'%,' + l.DbName + N',%';
    SET @rows += @@ROWCOUNT;

    /* Disk volumes holding files of the watched (online) databases */
    SELECT mf.database_id, mf.file_id, db = d.name
    INTO   #f
    FROM   sys.master_files mf
    JOIN   sys.databases d ON d.database_id = mf.database_id
    WHERE  d.state = 0 AND @dbs LIKE N'%,' + d.name + N',%';

    SELECT f.db, vol = LEFT(vs.volume_mount_point, 260), vs.total_bytes, vs.available_bytes
    INTO   #v
    FROM   #f f
    CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) vs;

    INSERT dbo.VolumeSnapshot (SnapTs, Volume, TotalGb, FreeGb, Dbs)
    SELECT @now, v.vol,
           CAST(MAX(v.total_bytes) / 1073741824.0 AS decimal(12,1)),
           CAST(MAX(v.available_bytes) / 1073741824.0 AS decimal(12,1)),
           LEFT(STUFF((SELECT DISTINCT N', ' + v2.db FROM #v v2 WHERE v2.vol = v.vol
                       FOR XML PATH(''), TYPE).value('.', 'nvarchar(400)'), 1, 2, N''), 400)
    FROM #v v
    GROUP BY v.vol;
    SET @rows += @@ROWCOUNT;

    RETURN @rows;
END;
GO

/* =====================================================================
   2. More rules. Called by usp_EvaluateAlerts, which owns #ev and the
      email/state machine. @allQuiet = NO_PAYMENTS is already firing.
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.usp_EvaluateProactive
    @now      datetime2(0),
    @allQuiet bit = 0
AS
BEGIN
    SET NOCOUNT ON;
    IF OBJECT_ID(N'tempdb..#ev') IS NULL RETURN;   -- only meaningful inside usp_EvaluateAlerts

    DECLARE @aqMin   int          = ISNULL(TRY_CAST(dbo.fn_Cfg(N'AppQuietMinutes')      AS int), 30),
            @aqPer   decimal(9,2) = ISNULL(TRY_CAST(dbo.fn_Cfg(N'AppQuietMinPerHour')   AS decimal(9,2)), 12),
            @bWeeks  int          = ISNULL(TRY_CAST(dbo.fn_Cfg(N'QuietBaselineWeeks')   AS int), 4),
            @wsMin   int          = ISNULL(TRY_CAST(dbo.fn_Cfg(N'WebSilentMinOthers')   AS int), 20),
            @ignore  nvarchar(500)= N',' + REPLACE(ISNULL(dbo.fn_Cfg(N'WebSilentIgnoreHosts'), N''), N' ', N'') + N',',
            @logWarn decimal(5,1) = ISNULL(TRY_CAST(dbo.fn_Cfg(N'LogUsedWarnPct')       AS decimal(5,1)), 70),
            @dskWarn decimal(5,1) = ISNULL(TRY_CAST(dbo.fn_Cfg(N'DiskFreeWarnPct')      AS decimal(5,1)), 15),
            @cpuWarn int          = ISNULL(TRY_CAST(dbo.fn_Cfg(N'CpuWarnPct')           AS int), 85),
            @postDl  time(0)      = ISNULL(TRY_CAST(dbo.fn_Cfg(N'PostingDeadline')      AS time(0)), '09:30'),
            @postWe  bit          = ISNULL(TRY_CAST(dbo.fn_Cfg(N'PostingCheckWeekends') AS bit), 0);
    IF @bWeeks NOT BETWEEN 1 AND 8 SET @bWeeks = 4;

    /* ---------- APP_QUIET: one application stopped, others still fine --- */
    DECLARE @first datetime2(0) = (SELECT MIN(TranTs) FROM dbo.PaymentTxn);
    DECLARE @txnOk bit = CASE WHEN EXISTS (SELECT 1 FROM dbo.CollectLog
                                           WHERE Step = 'Txn' AND Status = 'OK' AND RunTs >= DATEADD(MINUTE, -10, @now))
                              THEN 1 ELSE 0 END;

    SELECT k INTO #wk FROM (VALUES (1),(2),(3),(4),(5),(6),(7),(8)) v (k)
    WHERE k <= @bWeeks AND DATEADD(MINUTE, -60, DATEADD(DAY, -7 * k, @now)) >= @first;
    DECLARE @nw int = (SELECT COUNT(*) FROM #wk);

    SELECT AppCode = ISNULL(p.AppCode, N'OTHER'), c = COUNT(*)
    INTO   #awc
    FROM   #wk w
    JOIN   dbo.PaymentTxn p ON p.TranTs >= DATEADD(MINUTE, -60, DATEADD(DAY, -7 * w.k, @now))
                           AND p.TranTs <  DATEADD(DAY, -7 * w.k, @now)
    JOIN   dbo.StatusMap sm ON sm.StatusCode = p.StatusCode AND sm.Category = 'Completed'
    GROUP BY ISNULL(p.AppCode, N'OTHER');

    SELECT a.AppCode, base = a.c * 1.0 / NULLIF(@nw, 0),
           lastC = (SELECT MAX(p.TranTs) FROM dbo.PaymentTxn p
                    JOIN dbo.StatusMap sm ON sm.StatusCode = p.StatusCode AND sm.Category = 'Completed'
                    WHERE ISNULL(p.AppCode, N'OTHER') = a.AppCode AND p.TranTs >= DATEADD(DAY, -3, @now))
    INTO   #aq
    FROM   #awc a;

    DECLARE @aqList nvarchar(1500) = STUFF((
        SELECT N'; ' + ISNULL(m.AppName, q.AppCode) + N': last payment '
               + ISNULL(FORMAT(q.lastC, N'HH:mm') + N' (' + CAST(DATEDIFF(MINUTE, q.lastC, @now) AS nvarchar(10)) + N' min ago)', N'none in 3 days')
               + N', normally about ' + FORMAT(q.base, N'N0') + N' per hour'
        FROM #aq q LEFT JOIN dbo.AppMap m ON m.AppCode = q.AppCode
        WHERE q.base >= @aqPer AND (q.lastC IS NULL OR q.lastC < DATEADD(MINUTE, -@aqMin, @now))
        ORDER BY q.base DESC
        FOR XML PATH(''), TYPE).value('.', 'nvarchar(1500)'), 1, 2, N'');
    DECLARE @aqN int = (SELECT COUNT(*) FROM #aq
                        WHERE base >= @aqPer AND (lastC IS NULL OR lastC < DATEADD(MINUTE, -@aqMin, @now)));

    INSERT #ev (RuleKey, Firing, Value, Subject, Detail)
    SELECT 'APP_QUIET', CASE WHEN @aqN > 0 AND @txnOk = 1 AND ISNULL(@allQuiet, 0) = 0 THEN 1 ELSE 0 END, @aqN,
           CONCAT(@aqN, N' application(s) stopped taking payments'),
           CONCAT(ISNULL(@aqList, N'All applications normal'),
                  N'. Other applications are still completing payments, so look at this application''s pages and its hand-off to the payment gateway.');

    /* ---------- WEB_NODE_SILENT ---------------------------------------- */
    SELECT TOP (3) RunTs INTO #ws FROM dbo.CollectLog
    WHERE Step = 'SqlHealth' AND Status = 'OK' AND RunTs >= DATEADD(MINUTE, -15, @now)
    ORDER BY LogId DESC;

    SELECT z.HostName, z.Zone, t.RunTs,
           mine   = ISNULL((SELECT SUM(w.Sessions) FROM dbo.WebNodeSnapshot w WHERE w.SnapTs = t.RunTs AND w.HostName = z.HostName), 0),
           others = ISNULL((SELECT SUM(w.Sessions) FROM dbo.WebNodeSnapshot w WHERE w.SnapTs = t.RunTs AND w.HostName <> z.HostName), 0)
    INTO   #wn
    FROM   dbo.ZoneMap z CROSS JOIN #ws t
    WHERE  @ignore NOT LIKE N'%,' + z.HostName + N',%';

    DECLARE @wsN int, @wsList nvarchar(1000);
    SELECT HostName, Zone, others = MIN(others) INTO #wsil FROM #wn
    GROUP BY HostName, Zone
    HAVING COUNT(*) = 3 AND MAX(mine) = 0 AND MIN(others) >= @wsMin;
    SET @wsN = (SELECT COUNT(*) FROM #wsil);
    SET @wsList = STUFF((SELECT N', ' + HostName + N' (' + Zone + N')' FROM #wsil ORDER BY HostName
                         FOR XML PATH(''), TYPE).value('.', 'nvarchar(1000)'), 1, 2, N'');

    INSERT #ev (RuleKey, Firing, Value, Subject, Detail)
    SELECT 'WEB_NODE_SILENT', CASE WHEN @wsN > 0 THEN 1 ELSE 0 END, @wsN,
           CONCAT(N'Web server not connecting to SQL: ', ISNULL(@wsList, N'none')),
           CONCAT(ISNULL(@wsList, N'none'), N' had no sessions to the Billing_V2 SQL instance in the last 3 samples while the other web servers had ',
                  ISNULL((SELECT MIN(others) FROM #wsil), 0), N'+. Check the IIS app pool, the load balancer pool and the network path. ',
                  N'If a server is meant to be idle, add it to Config WebSilentIgnoreHosts.');

    /* ---------- LOG_SPACE ---------------------------------------------- */
    DECLARE @lTs datetime2(0) = (SELECT MAX(SnapTs) FROM dbo.LogSpaceSnapshot);
    DECLARE @lN int, @lMax decimal(5,1), @lList nvarchar(1000);
    SELECT @lN = COUNT(*), @lMax = MAX(UsedPct) FROM dbo.LogSpaceSnapshot
    WHERE SnapTs = @lTs AND SnapTs >= DATEADD(MINUTE, -10, @now) AND UsedPct >= @logWarn AND LogSizeMb >= 100;
    SET @lList = STUFF((SELECT N'; ' + DbName + N' ' + FORMAT(UsedPct, N'N0') + N'% of ' + FORMAT(LogSizeMb, N'N0')
                               + N' MB (waiting on ' + ISNULL(ReuseWait, N'?') + N')'
                        FROM dbo.LogSpaceSnapshot
                        WHERE SnapTs = @lTs AND UsedPct >= @logWarn AND LogSizeMb >= 100
                        ORDER BY UsedPct DESC
                        FOR XML PATH(''), TYPE).value('.', 'nvarchar(1000)'), 1, 2, N'');
    INSERT #ev (RuleKey, Firing, Value, Subject, Detail)
    SELECT 'LOG_SPACE', CASE WHEN @lN > 0 THEN 1 ELSE 0 END, @lMax,
           CONCAT(N'Transaction log ', FORMAT(ISNULL(@lMax, 0), N'N0'), N'% full'),
           CONCAT(ISNULL(@lList, N'none'), N'. LOG_BACKUP = log backups not keeping up; AVAILABILITY_REPLICA = a secondary is behind; ',
                  N'ACTIVE_TRANSACTION = a long open transaction. Threshold ', FORMAT(@logWarn, N'N0'), N'%.');

    /* ---------- DISK_SPACE --------------------------------------------- */
    DECLARE @vTs datetime2(0) = (SELECT MAX(SnapTs) FROM dbo.VolumeSnapshot);
    DECLARE @vN int, @vMin decimal(9,1), @vList nvarchar(1000);
    SELECT @vN = COUNT(*), @vMin = MIN(FreeGb * 100.0 / NULLIF(TotalGb, 0)) FROM dbo.VolumeSnapshot
    WHERE SnapTs = @vTs AND SnapTs >= DATEADD(MINUTE, -10, @now) AND FreeGb * 100.0 / NULLIF(TotalGb, 0) < @dskWarn;
    SET @vList = STUFF((SELECT N'; ' + Volume + N' ' + FORMAT(FreeGb, N'N1') + N' GB free of ' + FORMAT(TotalGb, N'N0')
                               + N' GB (' + FORMAT(FreeGb * 100.0 / NULLIF(TotalGb, 0), N'N0') + N'%), holds ' + ISNULL(Dbs, N'?')
                        FROM dbo.VolumeSnapshot
                        WHERE SnapTs = @vTs AND FreeGb * 100.0 / NULLIF(TotalGb, 0) < @dskWarn
                        FOR XML PATH(''), TYPE).value('.', 'nvarchar(1000)'), 1, 2, N'');
    INSERT #ev (RuleKey, Firing, Value, Subject, Detail)
    SELECT 'DISK_SPACE', CASE WHEN @vN > 0 THEN 1 ELSE 0 END, @vMin,
           CONCAT(N'Low disk space on ', @@SERVERNAME, N': ', FORMAT(ISNULL(@vMin, 0), N'N0'), N'% free'),
           CONCAT(ISNULL(@vList, N'none'), N'. Threshold ', FORMAT(@dskWarn, N'N0'), N'% free.');

    /* ---------- CPU_HIGH ----------------------------------------------- */
    DECLARE @cN int, @cAvg decimal(9,1), @cSql decimal(9,1);
    SELECT @cN = COUNT(*), @cAvg = AVG(CAST(SqlPct + OtherPct AS decimal(9,1))), @cSql = AVG(CAST(SqlPct AS decimal(9,1)))
    FROM dbo.CpuSnapshot WHERE SnapTs >= DATEADD(MINUTE, -10, @now);
    INSERT #ev (RuleKey, Firing, Value, Subject, Detail)
    SELECT 'CPU_HIGH', CASE WHEN @cN >= 3 AND @cAvg >= @cpuWarn THEN 1 ELSE 0 END, @cAvg,
           CONCAT(N'SQL server CPU ', FORMAT(ISNULL(@cAvg, 0), N'N0'), N'% (10-minute average)'),
           CONCAT(N'On ', @@SERVERNAME, N': SQL Server ', FORMAT(ISNULL(@cSql, 0), N'N0'), N'%, other processes ',
                  FORMAT(ISNULL(@cAvg - @cSql, 0), N'N0'), N'%. See Top SQL waits and blocking on the dashboard. Threshold ', @cpuWarn, N'%.');

    /* ---------- JOB_LATE ----------------------------------------------- */
    DECLARE @today date = CAST(@now AS date);
    DECLARE @dow int = DATEDIFF(DAY, '19000101', @today) % 7;          -- 0 = Monday ... 6 = Sunday
    DECLARE @jobs nvarchar(1500) = STUFF((
        SELECT N'; ' + j.JobName + N': ' + ISNULL(j.Message, N'failed') + N' (' + FORMAT(j.RunStart, N'ddd HH:mm') + N')'
        FROM (SELECT JobName, RunStart, Status, Message,
                     rn = ROW_NUMBER() OVER (PARTITION BY JobName ORDER BY RunStart DESC)
              FROM dbo.JobRun WHERE Source = 'AppLog' AND RunStart >= DATEADD(HOUR, -26, @now)) j
        WHERE j.rn = 1 AND j.Status = 'Failed'
        FOR XML PATH(''), TYPE).value('.', 'nvarchar(1500)'), 1, 2, N'');
    DECLARE @postLate bit = 0;
    IF @now > DATEADD(SECOND, DATEDIFF(SECOND, CAST('00:00' AS time(0)), @postDl), CAST(@today AS datetime2(0)))
       AND (@dow < 5 OR @postWe = 1)
       AND NOT EXISTS (SELECT 1 FROM dbo.JobRun WHERE Source = 'AppLog' AND JobName LIKE N'Post payments to GEORGE%'
                       AND RunStart >= CAST(@today AS datetime2(0)))
       AND EXISTS (SELECT 1 FROM dbo.PaymentTxn p JOIN dbo.StatusMap sm ON sm.StatusCode = p.StatusCode AND sm.Category = 'Completed'
                   WHERE p.TranTs >= DATEADD(DAY, -1, CAST(@today AS datetime2(0))) AND p.TranTs < CAST(@today AS datetime2(0)))
        SET @postLate = 1;
    IF @postLate = 1
        SET @jobs = CONCAT(@jobs + N'; ', N'Post payments to GEORGE: no as400BMADPNDP rows written today by ',
                           CONVERT(nvarchar(5), @postDl, 108), N' although payments were completed yesterday');

    INSERT #ev (RuleKey, Firing, Value, Subject, Detail)
    SELECT 'JOB_LATE', CASE WHEN @jobs IS NOT NULL THEN 1 ELSE 0 END, NULL,
           CASE WHEN @postLate = 1 THEN N'GEORGE payment posting has not run today' ELSE N'Billing report run not processed' END,
           CONCAT(ISNULL(@jobs, N'All billing batches on time'),
                  N'. Members'' payments will not show as paid in GEORGE until the batch runs.');
END;
GO

/* =====================================================================
   3. CHECKS
   ===================================================================== */
DECLARE @r int;
EXEC @r = dbo.usp_CollectCapacity;
SELECT CONCAT(N'usp_CollectCapacity returned ', @r, N' (-1 = sampled too recently, try again in 2 minutes)') AS capacity_collect;
SELECT TOP (1) SnapTs, SqlPct, OtherPct FROM dbo.CpuSnapshot ORDER BY SnapTs DESC;
SELECT DbName, LogSizeMb, UsedPct, ReuseWait FROM dbo.LogSpaceSnapshot WHERE SnapTs = (SELECT MAX(SnapTs) FROM dbo.LogSpaceSnapshot);
SELECT Volume, TotalGb, FreeGb, CAST(FreeGb * 100.0 / NULLIF(TotalGb, 0) AS decimal(5,1)) AS free_pct, Dbs
FROM dbo.VolumeSnapshot WHERE SnapTs = (SELECT MAX(SnapTs) FROM dbo.VolumeSnapshot);

-- Per-application baseline for this hour (APP_QUIET only watches apps at or above AppQuietMinPerHour)
SELECT ISNULL(p.AppCode, N'OTHER') AS app, COUNT(*) / 4.0 AS avg_completed_this_hour_last_4_weeks
FROM (VALUES (1),(2),(3),(4)) w (k)
JOIN dbo.PaymentTxn p ON p.TranTs >= DATEADD(MINUTE, -60, DATEADD(DAY, -7 * w.k, SYSDATETIME()))
                     AND p.TranTs <  DATEADD(DAY, -7 * w.k, SYSDATETIME())
JOIN dbo.StatusMap sm ON sm.StatusCode = p.StatusCode AND sm.Category = 'Completed'
GROUP BY ISNULL(p.AppCode, N'OTHER') ORDER BY 2 DESC;

-- Evaluate everything once (AlertMode decides whether anything is emailed)
EXEC @r = dbo.usp_EvaluateAlerts;
SELECT s.RuleKey, s.IsActive, s.LastValue, s.Subject
FROM dbo.AlertState s
WHERE s.RuleKey IN ('APP_QUIET','WEB_NODE_SILENT','LOG_SPACE','DISK_SPACE','CPU_HIGH','JOB_LATE')
ORDER BY s.RuleKey;
