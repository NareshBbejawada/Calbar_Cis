/* =====================================================================
   03_dashboard_json_proc.sql  -  dbo.usp_GetDashboardJson
   Returns ONE JSON document consumed by index.html.
   Reads only the billingdashboard database - never touches the linked server, so
   the dashboard puts no load on GEORGE no matter how many people open it.
   ===================================================================== */
USE billingdashboard;
GO
CREATE OR ALTER FUNCTION dbo.fn_Cfg (@key sysname)
RETURNS nvarchar(max)
AS
BEGIN
    RETURN (SELECT ConfigValue FROM dbo.Config WHERE ConfigKey = @key);
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_GetDashboardJson
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @now      datetime2(0) = SYSDATETIME();
    DECLARE @today    date         = CAST(@now AS date);
    DECLARE @base     datetime2(0) = '2000-01-01';
    DECLARE @cs       date = TRY_CAST(dbo.fn_Cfg(N'CycleStart') AS date);
    DECLARE @ce       date = TRY_CAST(dbo.fn_Cfg(N'CycleEnd')   AS date);
    DECLARE @inCycle  bit  = CASE WHEN @today BETWEEN @cs AND @ce THEN 1 ELSE 0 END;
    /* Outside the cycle (e.g. while testing in November) show the last 60 days */
    DECLARE @dStart   date = CASE WHEN @inCycle = 1 THEN @cs ELSE DATEADD(DAY, -59, @today) END;
    DECLARE @h48      datetime2(0) = DATEADD(HOUR, DATEDIFF(HOUR, @base, @now) - 47, @base);
    DECLARE @stuckMin int = ISNULL(TRY_CAST(dbo.fn_Cfg(N'StuckPendingMinutes') AS int), 30);

    /* Categorised transactions for the windows we need */
    SELECT p.TranTs, p.AppCode, p.Amount, p.ErrorCode, p.ErrorText,
           Cat   = ISNULL(sm.Category, 'Pending'),    -- unmapped codes count as pending
           Class = CASE WHEN sm.Category = 'Failed'   -- System = gateway/processor, Customer = decline
                        THEN ISNULL(rc.Class, 'Customer') END
    INTO   #tx
    FROM   dbo.PaymentTxn p
    LEFT JOIN dbo.StatusMap   sm ON sm.StatusCode = p.StatusCode
    LEFT JOIN dbo.ReasonClass rc ON rc.ReasonCode = ISNULL(p.ErrorCode, N'(no code)')
    WHERE  p.TranTs >= CAST(@dStart AS datetime2(0));

    /* ---- v5: "normal" volume = same weekday and hour, previous N weeks ---- */
    DECLARE @bW int = ISNULL(TRY_CAST(dbo.fn_Cfg(N'QuietBaselineWeeks') AS int), 4);
    IF @bW NOT BETWEEN 1 AND 8 SET @bW = 4;
    DECLARE @firstH datetime2(0) = (SELECT DATEADD(HOUR, DATEDIFF(HOUR, @base, MIN(TranTs)), @base) FROM dbo.PaymentTxn);
    SELECT k INTO #wk FROM (VALUES (1),(2),(3),(4),(5),(6),(7),(8)) v (k) WHERE k <= @bW;

    /* completed per hour per app, for the hours the 48 h baseline needs */
    SELECT h = DATEADD(HOUR, DATEDIFF(HOUR, @base, p.TranTs), @base), app = ISNULL(p.AppCode, N'?'), c = COUNT(*)
    INTO   #hc
    FROM   dbo.PaymentTxn p
    JOIN   dbo.StatusMap sm ON sm.StatusCode = p.StatusCode AND sm.Category = 'Completed'
    WHERE  p.TranTs >= DATEADD(DAY, -7 * @bW, @h48) AND p.TranTs < DATEADD(DAY, -6, @now)
    GROUP BY DATEADD(HOUR, DATEDIFF(HOUR, @base, p.TranTs), @base), ISNULL(p.AppCode, N'?');

    SELECT h = DATEADD(HOUR, n.n, @h48) INTO #sl
    FROM (SELECT TOP (48) n = ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 FROM sys.all_objects) n;

    SELECT s.h, nw = COUNT(*) INTO #slw
    FROM #sl s CROSS JOIN #wk w
    WHERE DATEADD(DAY, -7 * w.k, s.h) >= @firstH
    GROUP BY s.h;

    SELECT s.h, hc.app, e = SUM(hc.c) * 1.0 / MAX(sw.nw)
    INTO   #exp
    FROM   #slw sw
    JOIN   #sl s ON s.h = sw.h
    CROSS JOIN #wk w
    JOIN   #hc hc ON hc.h = DATEADD(DAY, -7 * w.k, s.h)
    WHERE  DATEADD(DAY, -7 * w.k, s.h) >= @firstH
    GROUP BY s.h, hc.app;

    /* rolling 60 minutes per app vs the same 60 minutes in previous weeks */
    DECLARE @nwNow int = (SELECT COUNT(*) FROM #wk
                          WHERE DATEADD(MINUTE, -60, DATEADD(DAY, -7 * k, @now)) >= (SELECT MIN(TranTs) FROM dbo.PaymentTxn));
    SELECT app = ISNULL(p.AppCode, N'?'), c = COUNT(*)
    INTO   #ab
    FROM   #wk w
    JOIN   dbo.PaymentTxn p ON p.TranTs >= DATEADD(MINUTE, -60, DATEADD(DAY, -7 * w.k, @now))
                           AND p.TranTs <  DATEADD(DAY, -7 * w.k, @now)
    JOIN   dbo.StatusMap sm ON sm.StatusCode = p.StatusCode AND sm.Category = 'Completed'
    WHERE  DATEADD(MINUTE, -60, DATEADD(DAY, -7 * w.k, @now)) >= (SELECT MIN(TranTs) FROM dbo.PaymentTxn)
    GROUP BY ISNULL(p.AppCode, N'?');

    DECLARE @h60 datetime2(0) = DATEADD(MINUTE, -60, @now);
    DECLARE @cpuTs datetime2(0) = DATEADD(HOUR, -6, @now);
    DECLARE @logTs datetime2(0) = (SELECT MAX(SnapTs) FROM dbo.LogSpaceSnapshot);
    DECLARE @volTs datetime2(0) = (SELECT MAX(SnapTs) FROM dbo.VolumeSnapshot);

    /* Wait-stat deltas: latest snapshot vs the one nearest 60 minutes earlier */
    DECLARE @wNow datetime2(0) = (SELECT MAX(SnapTs) FROM dbo.WaitSnapshot);
    DECLARE @wOld datetime2(0) = (SELECT MAX(SnapTs) FROM dbo.WaitSnapshot
                                  WHERE SnapTs <= DATEADD(MINUTE, -60, @wNow));
    IF @wOld IS NULL SET @wOld = (SELECT MIN(SnapTs) FROM dbo.WaitSnapshot);

    DECLARE @agTs   datetime2(0) = (SELECT MAX(SnapTs) FROM dbo.AgSnapshot);
    DECLARE @webTs  datetime2(0) = (SELECT MAX(SnapTs) FROM dbo.WebNodeSnapshot);
    DECLARE @lastRun datetime2(0) = (SELECT MAX(RunTs) FROM dbo.CollectLog);

    SELECT
      meta = JSON_QUERY((SELECT
                generatedAt  = @now,
                cycleStart   = @cs,
                cycleEnd     = @ce,
                inCycle      = @inCycle,
                windowStart  = @dStart,
                server       = @@SERVERNAME,
                lastCollect  = @lastRun,
                alertMode    = dbo.fn_Cfg(N'AlertMode'),
                lastCompleted = (SELECT MAX(TranTs) FROM #tx WHERE Cat = 'Completed'),
                collect      = JSON_QUERY((
                    SELECT step = l.Step, status = l.Status, ts = l.RunTs,
                           durationMs = l.DurationMs, message = l.Message
                    FROM dbo.CollectLog l
                    WHERE l.LogId IN (SELECT MAX(LogId) FROM dbo.CollectLog GROUP BY Step)
                    FOR JSON PATH))
             FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)),

      thresholds = JSON_QUERY((SELECT
                failRateWarnPct     = TRY_CAST(dbo.fn_Cfg(N'FailRateWarnPct')  AS decimal(9,2)),
                failRateCritPct     = TRY_CAST(dbo.fn_Cfg(N'FailRateCritPct')  AS decimal(9,2)),
                stuckPendingMinutes = @stuckMin,
                pingWarnMs          = TRY_CAST(dbo.fn_Cfg(N'PingWarnMs')       AS int),
                pingCritMs          = TRY_CAST(dbo.fn_Cfg(N'PingCritMs')       AS int),
                redoQueueWarnKb     = TRY_CAST(dbo.fn_Cfg(N'RedoQueueWarnKb')  AS bigint),
                blockWarnSec        = TRY_CAST(dbo.fn_Cfg(N'BlockWarnSec')     AS int),
                quietBaselinePct    = TRY_CAST(dbo.fn_Cfg(N'QuietBaselinePct')        AS decimal(9,2)),
                quietMinPerHour     = TRY_CAST(dbo.fn_Cfg(N'QuietMinBaselinePerHour') AS decimal(9,2)),
                appQuietMinutes     = TRY_CAST(dbo.fn_Cfg(N'AppQuietMinutes')         AS int),
                appQuietMinPerHour  = TRY_CAST(dbo.fn_Cfg(N'AppQuietMinPerHour')      AS decimal(9,2)),
                cpuWarnPct          = TRY_CAST(dbo.fn_Cfg(N'CpuWarnPct')              AS int),
                logUsedWarnPct      = TRY_CAST(dbo.fn_Cfg(N'LogUsedWarnPct')          AS decimal(9,2)),
                diskFreeWarnPct     = TRY_CAST(dbo.fn_Cfg(N'DiskFreeWarnPct')         AS decimal(9,2)),
                webSilentIgnore     = dbo.fn_Cfg(N'WebSilentIgnoreHosts')
             FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)),

      apps = JSON_QUERY((SELECT code = AppCode, name = AppName
                         FROM dbo.AppMap ORDER BY SortOrder FOR JSON PATH)),

      /* last 48 hours, hourly, per app */
      hourly = JSON_QUERY((
          SELECT h = DATEADD(HOUR, DATEDIFF(HOUR, @base, TranTs), @base),
                 app = ISNULL(AppCode, N'?'),
                 completed = SUM(CASE WHEN Cat = 'Completed' THEN 1 ELSE 0 END),
                 failed    = SUM(CASE WHEN Cat = 'Failed'    THEN 1 ELSE 0 END),
                 sysFailed = SUM(CASE WHEN Class = 'System'  THEN 1 ELSE 0 END),
                 pending   = SUM(CASE WHEN Cat = 'Pending'   THEN 1 ELSE 0 END),
                 cancelled = SUM(CASE WHEN Cat = 'Cancelled' THEN 1 ELSE 0 END),
                 amount    = SUM(CASE WHEN Cat = 'Completed' THEN Amount ELSE 0 END)
          FROM #tx WHERE TranTs >= @h48
          GROUP BY DATEADD(HOUR, DATEDIFF(HOUR, @base, TranTs), @base), ISNULL(AppCode, N'?')
          FOR JSON PATH)),

      /* cycle (or last 60 days), daily, per app */
      daily = JSON_QUERY((
          SELECT d = CAST(TranTs AS date),
                 app = ISNULL(AppCode, N'?'),
                 completed = SUM(CASE WHEN Cat = 'Completed' THEN 1 ELSE 0 END),
                 failed    = SUM(CASE WHEN Cat = 'Failed'    THEN 1 ELSE 0 END),
                 sysFailed = SUM(CASE WHEN Class = 'System'  THEN 1 ELSE 0 END),
                 amount    = SUM(CASE WHEN Cat = 'Completed' THEN Amount ELSE 0 END)
          FROM #tx
          GROUP BY CAST(TranTs AS date), ISNULL(AppCode, N'?')
          FOR JSON PATH)),

      stuck = JSON_QUERY((
          SELECT app = ISNULL(AppCode, N'?'), [count] = COUNT(*),
                 oldestMinutes = MAX(DATEDIFF(MINUTE, TranTs, @now))
          FROM #tx
          WHERE Cat = 'Pending' AND TranTs < DATEADD(MINUTE, -@stuckMin, @now)
            AND TranTs >= DATEADD(DAY, -3, @now)
          GROUP BY ISNULL(AppCode, N'?')
          FOR JSON PATH)),

      failures = JSON_QUERY((
          SELECT TOP (60) app = ISNULL(AppCode, N'?'),
                 code = ISNULL(ErrorCode, N'(no code)'),
                 class = MAX(Class),
                 [text] = MAX(ErrorText), [count] = COUNT(*),
                 lastSeen = MAX(TranTs)
          FROM #tx
          WHERE Cat = 'Failed' AND TranTs >= DATEADD(HOUR, -24, @now)
          GROUP BY ISNULL(AppCode, N'?'), ISNULL(ErrorCode, N'(no code)')
          ORDER BY COUNT(*) DESC
          FOR JSON PATH)),

      progress = JSON_QUERY((
          SELECT TOP (1) snapTs = SnapTs, membersBilled = MembersBilled, membersPaid = MembersPaid,
                 amountBilled = AmountBilled, amountPaid = AmountPaid
          FROM dbo.BillingProgress ORDER BY SnapTs DESC
          FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)),

      webNodes = JSON_QUERY((
          SELECT host = w.HostName, zone = z.Zone, program = w.ProgramName, db = w.DbName,
                 sessions = w.Sessions, active = w.ActiveRequests
          FROM dbo.WebNodeSnapshot w
          JOIN dbo.ZoneMap z ON z.HostName = w.HostName
          WHERE w.SnapTs = @webTs
          FOR JSON PATH)),

      nodeHourly = JSON_QUERY((
          SELECT h = DATEADD(HOUR, DATEDIFF(HOUR, @base, SnapTs), @base), host = HostName,
                 sessions = AVG(CAST(s AS int))
          FROM (SELECT SnapTs, HostName, s = SUM(Sessions)
                FROM dbo.WebNodeSnapshot
                WHERE SnapTs >= DATEADD(HOUR, -24, @now)
                GROUP BY SnapTs, HostName) x
          GROUP BY DATEADD(HOUR, DATEDIFF(HOUR, @base, SnapTs), @base), HostName
          FOR JSON PATH)),

      ping = JSON_QUERY((
          SELECT ts = PingTs, ms = DurationMs, ok = Success, err = ErrorText
          FROM dbo.LinkedServerPing
          WHERE PingTs >= DATEADD(HOUR, -6, @now)
          ORDER BY PingTs
          FOR JSON PATH)),

      ag = JSON_QUERY((
          SELECT ag = AgName, replica = ReplicaServer, db = DbName, role = RoleDesc,
                 mode = AvailMode, syncState = SyncState, health = SyncHealth,
                 logSendKb = LogSendQueueKb, redoKb = RedoQueueKb
          FROM dbo.AgSnapshot WHERE SnapTs = @agTs
          ORDER BY AgName, RoleDesc DESC, ReplicaServer
          FOR JSON PATH)),

      instance = JSON_QUERY((
          SELECT TOP (1) snapTs = SnapTs, activeRequests = ActiveRequests,
                 blocked = BlockedSessions, longestBlockSec = LongestBlockSec
          FROM dbo.InstanceSnapshot ORDER BY SnapTs DESC
          FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)),

      jobs = JSON_QUERY((
          SELECT TOP (1000) source = Source, name = JobName, start = RunStart, [end] = RunEnd,
                 status = Status, [rows] = RowsProcessed, message = Message
          FROM dbo.JobRun
          WHERE RunStart >= DATEADD(DAY, -2, @now)
          ORDER BY RunStart DESC
          FOR JSON PATH)),

      /* Phase 1: payment gateway errors per web server (counts only) */
      gateway = JSON_QUERY((
          SELECT h = DATEADD(HOUR, DATEDIFF(HOUR, @base, BucketTs), @base), host = HostName,
                 timeout    = SUM(CASE WHEN Kind = 'Timeout'    THEN ErrorCount ELSE 0 END),
                 connection = SUM(CASE WHEN Kind = 'Connection' THEN ErrorCount ELSE 0 END),
                 other      = SUM(CASE WHEN Kind NOT IN ('Timeout', 'Connection') THEN ErrorCount ELSE 0 END)
          FROM dbo.GatewayError
          WHERE BucketTs >= @h48
          GROUP BY DATEADD(HOUR, DATEDIFF(HOUR, @base, BucketTs), @base), HostName
          FOR JSON PATH)),
      gateway15 = JSON_QUERY((
          SELECT host = g.HostName, zone = z.Zone, errors = SUM(g.ErrorCount)
          FROM dbo.GatewayError g LEFT JOIN dbo.ZoneMap z ON z.HostName = g.HostName
          WHERE g.BucketTs >= DATEADD(MINUTE, -15, @now)
          GROUP BY g.HostName, z.Zone
          FOR JSON PATH)),

      /* Phase 1: server-side alert rules (same state that drives the emails) */
      serverAlerts = JSON_QUERY((
          SELECT [rule] = s.RuleKey, title = r.Title, severity = r.Severity, audience = r.Audience,
                 since = s.SinceTs, subject = s.Subject, detail = s.Detail
          FROM dbo.AlertState s JOIN dbo.AlertRule r ON r.RuleKey = s.RuleKey
          WHERE s.IsActive = 1 AND r.Enabled = 1
          FOR JSON PATH)),
      alertLog = JSON_QUERY((
          SELECT TOP (50) ts = LogTs, [rule] = RuleKey, kind = Kind, severity = Severity,
                 subject = Subject, sent = Sent, note = SendNote
          FROM dbo.AlertLog
          WHERE LogTs >= DATEADD(HOUR, -48, @now)
          ORDER BY AlertId DESC
          FOR JSON PATH)),

      /* v5: per-application health, last 60 minutes vs normal */
      appHealth = JSON_QUERY((
          SELECT app = m.AppCode,
                 lastCompleted = (SELECT MAX(TranTs) FROM #tx WHERE AppCode = m.AppCode AND Cat = 'Completed'),
                 completed60   = (SELECT COUNT(*) FROM #tx WHERE AppCode = m.AppCode AND Cat = 'Completed' AND TranTs >= @h60),
                 failed60      = (SELECT COUNT(*) FROM #tx WHERE AppCode = m.AppCode AND Cat = 'Failed'    AND TranTs >= @h60),
                 sysFailed60   = (SELECT COUNT(*) FROM #tx WHERE AppCode = m.AppCode AND Class = 'System'  AND TranTs >= @h60),
                 baseline60    = CAST((SELECT c FROM #ab WHERE app = m.AppCode) * 1.0 / NULLIF(@nwNow, 0) AS decimal(9,1))
          FROM dbo.AppMap m
          ORDER BY m.SortOrder
          FOR JSON PATH)),

      /* v5: expected completed payments per hour (for the 48 h chart) */
      expected = JSON_QUERY((
          SELECT h, app, e = CAST(e AS decimal(9,1)) FROM #exp WHERE e > 0 FOR JSON PATH)),

      /* v5: SQL capacity headroom */
      capacity = JSON_QUERY((SELECT
          cpu  = JSON_QUERY((SELECT ts = SnapTs, [sql] = SqlPct, other = OtherPct
                             FROM dbo.CpuSnapshot WHERE SnapTs >= @cpuTs ORDER BY SnapTs FOR JSON PATH)),
          logs = JSON_QUERY((SELECT db = DbName, sizeMb = LogSizeMb, usedPct = UsedPct, wait = ReuseWait
                             FROM dbo.LogSpaceSnapshot WHERE SnapTs = @logTs ORDER BY UsedPct DESC FOR JSON PATH)),
          volumes = JSON_QUERY((SELECT vol = Volume, totalGb = TotalGb, freeGb = FreeGb, dbs = Dbs
                             FROM dbo.VolumeSnapshot WHERE SnapTs = @volTs ORDER BY Volume FOR JSON PATH)),
          snapTs = @logTs
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)),

      /* v5: members paid, last snapshot of each day (pace and forecast) */
      progressDaily = JSON_QUERY((
          SELECT d = CAST(b.SnapTs AS date), billed = b.MembersBilled, paid = b.MembersPaid, amountPaid = b.AmountPaid
          FROM dbo.BillingProgress b
          WHERE b.SnapTs IN (SELECT MAX(SnapTs) FROM dbo.BillingProgress
                             WHERE SnapTs >= DATEADD(DAY, -70, @now) GROUP BY CAST(SnapTs AS date))
          ORDER BY b.SnapTs
          FOR JSON PATH)),

      waits = JSON_QUERY((
          SELECT TOP (8) wait = n.WaitType, ms = n.WaitMs - ISNULL(o.WaitMs, 0)
          FROM dbo.WaitSnapshot n
          LEFT JOIN dbo.WaitSnapshot o ON o.SnapTs = @wOld AND o.WaitType = n.WaitType
          WHERE n.SnapTs = @wNow AND @wOld < @wNow
            AND n.WaitMs - ISNULL(o.WaitMs, 0) > 0
          ORDER BY n.WaitMs - ISNULL(o.WaitMs, 0) DESC
          FOR JSON PATH))

    FOR JSON PATH, WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES;
END;
GO

/* Read-only role for the exporter account */
IF DATABASE_PRINCIPAL_ID(N'billingdashboard_reader') IS NULL
    CREATE ROLE billingdashboard_reader;
GRANT EXECUTE ON dbo.usp_GetDashboardJson TO billingdashboard_reader;
GO
