# billingdashboard

Live dashboard for the State Bar Jan–Feb online fee billing cycle.
Everything lives in the dedicated `billingdashboard` database; existing user databases are only read, never changed.
Full step-by-step instructions: the **billingdashboard: Deployment Runbook** document.

## Kit layout

| Path | What it is | Where it goes |
|---|---|---|
| `sql/00a_discover_george.sql` | Discovery: GEORGE table columns (done 2026-11-13) | Run once, any node |
| `sql/00b_discover_billing_v2.sql` | Discovery round 2: Billing_V2 payment tables | Run once, listener |
| `sql/install_billingdashboard.sql` | Creates the dedicated `billingdashboard` database, installs 01–04, service account access (SQLCMD mode) | Listener SFDBSLISTN01 |
| `sql/01_schema.sql` … `04_config_george.sql` | Called by the installer | (no need to run separately) |
| `sql/06_config_payments.sql` | Connects the payment charts to Billing_V2 (read only) + backfills 60 days | Listener SFDBSLISTN01 |
| `sql/05_agent_job.sql` | Credential, proxy, job, schedule (SQLCMD mode) | Each of the 4 AG nodes |
| `sql/07_alerts.sql` | **Phase 1** alert procedures + checks (needs 01–03 of this kit first) | Listener SFDBSLISTN01 |
| `sql/09_proactive.sql` | **v5** capacity collection (CPU, log, disk) + 6 more rules | Listener SFDBSLISTN01 |
| `sql/upgrade_v5.sql` | Upgrades v3 or v4 to v5: 01 → 02 → 03 → 07 → 09 (SQLCMD). Job unchanged | Listener SFDBSLISTN01 |
| `sql/upgrade_phase1.sql` | Upgrades a running install: 01 → 02 → 03 → 07 (SQLCMD mode). Job unchanged | Listener SFDBSLISTN01 |
| `sql/08_database_mail.sql` | Database Mail profile `billingdashboard` + test email (SQLCMD). Skip if a profile exists | Each of the 4 AG nodes |
| `scripts/Test-billingdashboardRollout.ps1` | Read-only check: AG membership, job/credential/proxy/mail on each node, backups, data.json age, collector | DBA workstation |
| `scripts/Export-billingdashboard.ps1` | Writes data.json | `D:\DBA\billingdashboard\` on each AG node |
| `web/index.html`, `web/web.config` | The dashboard page + IIS settings | `E:\inetpub\billingdashboard\` on AZDBAPRD01 |

## Names

| Item | Name |
|---|---|
| Service account | `CALSB\svc_billingdashboard` |
| Viewer groups | `CALSB\billingdashboard-IT`, `CALSB\billingdashboard-Management` |
| SQL database / role | `billingdashboard` (new, same AG as Billing_V2) / `billingdashboard_reader` |
| Agent credential / proxy | `billingdashboard_cred` / `billingdashboard_proxy` |
| Agent job / schedule | `billingdashboard - Collect` / `billingdashboard - every 2 min` |
| Web server / folder / share | `AZDBAPRD01` /  `E:\inetpub\billingdashboard` / `billingdashboard` |
| IIS app pool / application | `billingdashboard` / `/billingdashboard` |
| Dashboard URL | `http://azdbaprd01/billingdashboard/` |

## Phase 1: proactive alerts (kit v4, 2026-11-14)

**Upgrade a running install**
1. Copy the kit to `C:\billingdashboard\` and run `sql\upgrade_phase1.sql` on the listener in SQLCMD mode.
   Read the 07 check output: 6a (reason codes and their class), 6b (gateway errors per server, last 7 days), 6c (baseline), 6d (rules now).
2. Copy `web\index.html` to `\\AZDBAPRD01\billingdashboard\`.
3. Leave `AlertMode = LogOnly` for a few days and watch the *Alert history* panel (IT Operations view): it shows every email that *would* have gone out.
4. Database Mail on all 4 nodes (existing profile, or `sql\08_database_mail.sql`), then:
   ```sql
   UPDATE billingdashboard.dbo.Config SET ConfigValue = N'billingdashboard'          WHERE ConfigKey = N'MailProfile';
   UPDATE billingdashboard.dbo.Config SET ConfigValue = N'dba@...;oncall@...'        WHERE ConfigKey = N'AlertRecipientsIT';
   UPDATE billingdashboard.dbo.Config SET ConfigValue = N'manager@...'               WHERE ConfigKey = N'AlertRecipientsMgmt';
   UPDATE billingdashboard.dbo.Config SET ConfigValue = N'Send'                      WHERE ConfigKey = N'AlertMode';
   EXEC billingdashboard.dbo.usp_SendDailySummary @Force = 1;   -- one summary email now, as a test
   ```

**Rules** (`dbo.AlertRule`: Enabled, Severity, Audience IT or IT+MGMT, CooldownMinutes; thresholds in `dbo.Config`)

| Rule | Fires when | Default audience |
|---|---|---|
| NO_PAYMENTS | no completed payment for 20 min while the 4-week same-hour baseline expects ≥ 30/hour | IT+MGMT |
| LOW_VOLUME | completed in last 60 min < 40% of that baseline | IT |
| SYSTEM_FAILURES | ≥ 5 gateway/processor failures in 15 min (reason codes 150, 151, 152, 207, 236, 250, no code; see `dbo.ReasonClass`) | IT+MGMT |
| DECLINE_RATE | customer declines ≥ FailRateCritPct (15%) of ≥ 30 attempts in 60 min | IT |
| GATEWAY_ERRORS | ≥ 10 exceptionLog rows from one web server in 15 min | IT |
| STUCK_PENDING | ≥ 5 payments pending > 30 min | IT |
| GEORGE_DOWN | 3 consecutive failed linked-server pings | IT |
| AG_UNHEALTHY | a replica of Billing_V2 / billingdashboard not HEALTHY | IT |
| COLLECTOR_FAILING | last 3 reads of Billing_V2 transactions failed | IT |
| DAILY_SUMMARY | 08:30 daily: yesterday's totals, by app, billing progress, jobs, alerts | IT (set IT+MGMT for the cycle) |

Each rule emails when raised, reminds every CooldownMinutes while active, and sends RESOLVED when it clears.
`AlertMode`: `Off` (no evaluation), `LogOnly` (default: recorded in `dbo.AlertLog`, not emailed), `Send`.
exceptionLog is read as counts only: Message is scanned for "timeout"/"connect" and never stored.

## v5: more proactive monitoring (2026-11-19)

Upgrade: run `sql\upgrade_v5.sql` (SQLCMD, listener), copy `web\index.html`. Read the 09 check output (capacity sample, per-app baseline).

**On the page**
- *Executive:* **Members paid: pace and forecast** (projected % paid by cycle end at the last 7 days' pace, also in the Members paid tile) and **Applications right now** (one line per application in plain words).
- *IT Operations:* **Application health** matrix (last payment, last 60 min vs normal, success rate, system failures per application); a dashed **normal volume** line on the hourly chart; **SQL capacity headroom** (CPU 6 h, log used % with log_reuse_wait, disk free per volume).
- Browser tab title shows the alert count and the tab icon turns amber or red. **Sound** button beeps on a new critical alert. **Wallboard** button or `http://azdbaprd01/billingdashboard/?wall=1` gives a full-screen view that switches between Executive and IT Operations every 45 s (Esc to leave).

**New rules** (same `AlertMode`, cooldown and email handling as Phase 1)

| Rule | Fires when | Settings in dbo.Config |
|---|---|---|
| APP_QUIET | one application with ≥ 12/hour normally has no completed payment for 30 min while others still work | AppQuietMinutes, AppQuietMinPerHour |
| WEB_NODE_SILENT | a DMZ web server has 0 SQL sessions for 3 samples while the others have ≥ 20 | WebSilentMinOthers, WebSilentIgnoreHosts |
| LOG_SPACE | log ≥ 70% used (logs ≥ 100 MB) for Billing_V2, billingdashboard, tempdb | LogUsedWarnPct, CapacityDatabases |
| DISK_SPACE | volume holding those databases < 15% free | DiskFreeWarnPct |
| CPU_HIGH | 10-minute average CPU ≥ 85% | CpuWarnPct |
| JOB_LATE | card/ACH report run not processed, or no GEORGE posting rows (as400BMADPNDP) by 09:30 on weekdays after a day with payments | PostingDeadline, PostingCheckWeekends |

If SFWEBPRD14 (South Central) normally carries no traffic, set `WebSilentIgnoreHosts = 'SFWEBPRD14'`.
