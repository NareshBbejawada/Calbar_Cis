# billingdashboard: project context

Last updated: 2026-11-19. Owner: Naresh (DBA, State Bar of California).

## Goal
Proactive monitoring for the annual January–February online fee billing cycle:
payment volume, success and failure, timeouts, stuck payments, website health,
and SQL/GEORGE health, for IT and management. Refreshes every 60 seconds.

## Hard rules
- **No changes to existing user databases** (Billing_V2, CABAR) or to GEORGE. Read only.
- Everything lives in the dedicated database **billingdashboard**.
- Never copy cardholder names, addresses, card/bank numbers or tokens.
  (`Billing_V2.dbo.exceptionLog.Message` contains names and addresses, so store counts only.)

## Environment
| Item | Value |
|---|---|
| AD domain | CALSB |
| SQL listener (Billing_V2 + billingdashboard) | SFDBSLISTN01, 4-node AG (2 Prod in DC01, 2 DR in DC02) |
| GEORGE | DB2 for IBM i, linked server `George_PRDT`, schema PRDT |
| DMZ web servers | Western: SFWEBPRD11, 12, 13 · South Central: SFWEBPRD14 |
| Dashboard web server | AZDBAPRD01 (internal), folder `E:\inetpub\billingdashboard`, share `\\AZDBAPRD01\billingdashboard` |
| Dashboard URL | http://azdbaprd01/billingdashboard/ |
| Apps with online payments | My State Bar Profile, Agency Billing, Certificate of Standing, Course Registration, Online Payment Service (payment gateway) |

## Naming standard
| Item | Name |
|---|---|
| Service account | `CALSB\svc_billingdashboard` |
| Viewer groups | `CALSB\billingdashboard-IT`, `CALSB\billingdashboard-Management` |
| Database / role | `billingdashboard` (in the same AG as Billing_V2) / `billingdashboard_reader` |
| Agent job / schedule | `billingdashboard - Collect` / `billingdashboard - every 2 min` |
| Agent credential / proxy | `billingdashboard_cred` / `billingdashboard_proxy` (CmdExec) |
| Export script on each AG node | `D:\DBA\billingdashboard\Export-billingdashboard.ps1` |
| IIS app pool / application | `billingdashboard` / `/billingdashboard` |

## How it works
1. SQL Agent job (on all 4 nodes, works only on the AG primary of `billingdashboard`), every 2 min:
   - step 1 primary check · step 2 `EXEC billingdashboard.dbo.usp_Collect` · step 3 export `data.json` (runs as the proxy)
2. `usp_Collect` reads:
   - `Billing_V2.dbo.[transaction]` via `LocalTxnQuery` in `dbo.Config` (modifiedDate index, 6-hour window, NOLOCK)
   - `Billing_V2` ccReportProcess / achReportProcess / as400BMADPNDP for job runs (`AppJobLogQuery`)
   - GEORGE `PRDT.BMMASTP` every 30 min for billed vs paid (`GeorgeProgressQuery`, WITH UR, BMBLYR = BillingYear, BM$TBL > 0)
   - DMVs: sessions from SFWEBPRD11–14, AG health, blocking, waits; linked-server ping (`SYSIBM.SYSDUMMY1`)
3. `dbo.usp_GetDashboardJson` builds one JSON; the PowerShell exporter writes it to the web share.
4. `index.html` (self-contained, Executive + IT Operations views) reads `data.json`.

## Billing_V2 facts (from discovery, 2026-11-13)
- `transaction`: transactionTypeId 1 ACH / 2 CreditCard; transactionStatusId 1 Pending / 2 In Process / 3 Paid / 4 Rejected;
  `decision` (CyberSource ACCEPT/REJECT/ERROR/REVIEW); `reasonCode` (100 = success; text in `transactionReason`);
  `requestDateTime`; `amount` (float); indexed `modifiedDate`. Accepted card payments sit at status 2 until settled.
- `applicationTransactions.transactionId → applicationId`; `application` has 16 apps.
  Grouped in `billingdashboard.dbo.AppGroup`: MSBP (2,12,16), AB (1,9,11), COS (3), ENT LLP/LLC (8,10), OTHER.
- Dashboard outcome codes: ACCEPTED → Completed; DECLINED, RETURNED → Failed; REVIEW, PENDING → Pending.
- Daily 08:00 card and ACH report runs; ~08:15 batch writes `as400BMADPNDP` (posting to GEORGE/KOALA).
- exceptionLog: payment gateway errors with MachineName (SFWEBPRD11–13 seen); contains PII.

## GEORGE facts
- BMTRANP = posted ledger (no status/errors), not used. BMADPNDP = web payment adjustments (HPSTATUS A/B/P/S).
- BMMASTP balance used: BM$TBL + BM$TPB + BM$TDC + BM$TAD + BM$TPY ≤ 0 = paid.

## Storage and history
- PaymentTxn, BillingProgress, JobRun kept 400 days (`RetentionDays`); health snapshots 14 days.
- Steady state about 250–350 MB in a 1 GB data file. Database must be in the regular full and log backup jobs.

## Status (2026-11-14)
- Done: database, job on primary, export to AZDBAPRD01, page live; 06_config_payments.sql delivered.
- Kit v4 (2026-11-14): Phase 1 built (07_alerts.sql, upgrade_phase1.sql, 08_database_mail.sql,
  Test-billingdashboardRollout.ps1, page updated). Ships in AlertMode = LogOnly.
- Kit v5 (2026-11-19): proactive v5 built (09_proactive.sql, upgrade_v5.sql works from v3 or v4, page updated).
  Adds CpuSnapshot / LogSpaceSnapshot / VolumeSnapshot (14 days, usp_CollectCapacity = collector step 5b) and rules
  APP_QUIET, WEB_NODE_SILENT, LOG_SPACE, DISK_SPACE, CPU_HIGH, JOB_LATE (usp_EvaluateProactive, called from usp_EvaluateAlerts).
  Page: application health matrix, normal-volume line on hourly chart, SQL capacity card, members-paid pace/forecast,
  "Applications right now", alert count in tab title + coloured icon, sound toggle, wallboard (?wall=1).
  Deployment of v4/v5 not confirmed yet.
- To confirm: 06 results (check 6b, decision/status mix; are REJECT rows stored?), job on all 4 nodes,
  billingdashboard added to the AG + backups, share permissions, service account password reset.

## Open questions
- Does SFWEBPRD14 (South Central) normally carry traffic? If not, set WebSilentIgnoreHosts.
- Does the GEORGE posting batch (as400BMADPNDP) run on weekends? (PostingCheckWeekends)
- GEORGE team: meaning of HPSTATUS and BMBSTS; which charges are in BM$TBL.
- Which application is "Course Registration" (Online MCLE Self Study or Online School?).
- When the 2027 billing year starts taking payments (CycleStart / BillingYear).

## Next: proactive monitoring (proposed)
1. **Phase 1 (existing data) — BUILT in kit v4, see README "Phase 1":** split system failures (reason codes 150, 151, 152, 250, 236, 207) from customer declines;
   "too quiet" alert (no completed payment in 20 min / below 40% of 4-week same-hour baseline);
   gateway errors per web server from exceptionLog (counts only); Database Mail alerts with cooldown; 8 AM summary email.
   Needs: Database Mail on the instance, IT and management recipient lists.
   Design: rules in dbo.AlertRule, state in dbo.AlertState, every event in dbo.AlertLog; gateway errors in
   dbo.GatewayError (5-min counts per MachineName, kind Timeout/Connection/Other); reason-code class in dbo.ReasonClass.
   Hooked into usp_Collect as steps 7 (GatewayErr) and 8 (Alerts, Summary); the Agent job is unchanged.
   GatewayErrorQuery is generated by 07 from exceptionLog's columns (identity key, timestamp, MachineName, Message; UTC auto-detect).
   To confirm after deploy: 07 check 6a classes, 6b per-server counts, volume baseline vs QuietMinBaselinePerHour (30).
2. **Phase 2 (synthetic checks from AZDBAPRD01):** every minute, page availability and response time per server and via public URL;
   SSL certificate expiry. Needs: 443 from AZDBAPRD01 to the DMZ servers, public URLs.
3. **Phase 3 (IIS logs on SFWEBPRD11–14):** 5-minute summaries of requests, 4xx/5xx, slow requests and timeouts by server and zone;
   zone-bounce analysis. Needs: DMZ → SQL access for a scheduled task, IIS log path, `#Fields:` line with time-taken.

## Deliverables
- Kit: `billingdashboard-kit_5.zip` (sql/, scripts/, web/, README.md)
- Runbook (Claude Doc): https://claude.ai/artifact/BQgnGM6vFwG9kGZEuHz4xR
