/* =====================================================================
   10_history.sql  -  daily history for the range and comparison views
   (kit v6, 2026-11-19)
   Run on the LISTENER SFDBSLISTN01 (normal mode). Works on its own:
   creates its table if needed. Changes ONLY billingdashboard.
   Billing_V2 is only READ, and only by usp_BackfillHistory, which you
   run by hand (see section 4). Re-runnable.

   Adds
     dbo.DailySummary              one row per day per application, kept forever
     dbo.usp_RefreshDailySummary   rebuilds recent days from PaymentTxn
                                   (called by usp_Collect, step 5c)
     dbo.usp_BackfillHistory       ONE-TIME: earlier days from Billing_V2,
                                   read one day at a time through the
                                   modifiedDate index, counts only
   ===================================================================== */
USE billingdashboard;
GO

/* =====================================================================
   v6 HISTORY (added 2026-11-19) - one row per day per application.
   Kept forever (about 2,000 rows a year). Filled from PaymentTxn by
   dbo.usp_RefreshDailySummary and, for earlier cycles, once by
   dbo.usp_BackfillHistory (10_history.sql).
   ===================================================================== */
IF OBJECT_ID(N'dbo.DailySummary') IS NULL
CREATE TABLE dbo.DailySummary (
    Day         date          NOT NULL,
    AppCode     nvarchar(50)  NOT NULL,
    Completed   int           NOT NULL,
    Amount      decimal(14,2) NOT NULL,
    Failed      int           NOT NULL,      -- customer declines + system failures
    SysFailed   int           NOT NULL,      -- ReasonClass = System
    Pending     int           NOT NULL,
    Source      char(1)       NOT NULL,      -- L = live (PaymentTxn), B = backfill (Billing_V2)
    RefreshedTs datetime2(0)  NOT NULL,
    CONSTRAINT PK_bd_DailySummary PRIMARY KEY (Day, AppCode)
);
GO
MERGE dbo.Config AS t
USING (VALUES
 (N'HistoryDays',   N'400', N'Days of daily history sent to the page (plus earlier cycles below)'),
 (N'HistoryCycles', N'2',   N'Earlier billing cycles (same dates, previous years) sent to the page for comparison')
) AS s (ConfigKey, ConfigValue, Notes)
ON t.ConfigKey = s.ConfigKey
WHEN NOT MATCHED THEN INSERT (ConfigKey, ConfigValue, Notes) VALUES (s.ConfigKey, s.ConfigValue, s.Notes);
GO

/* =====================================================================
   1. Refresh recent days from PaymentTxn
      @full = 0: yesterday + today; @full = 1: last 60 days.
      Days before PaymentTxn's first complete day are never touched,
      so backfilled history is kept.
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.usp_RefreshDailySummary
    @now  datetime2(0) = NULL,
    @full bit = 0
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @now = ISNULL(@now, SYSDATETIME());

    DECLARE @today date = CAST(@now AS date);
    DECLARE @from  date = DATEADD(DAY, CASE WHEN @full = 1 THEN -59 ELSE -1 END, @today);
    DECLARE @liveStart date = DATEADD(DAY, 1, CAST((SELECT MIN(TranTs) FROM dbo.PaymentTxn) AS date));
    IF @liveStart IS NULL RETURN 0;
    IF @from < @liveStart SET @from = @liveStart;
    IF @from > @today RETURN 0;

    SELECT Day       = CAST(p.TranTs AS date),
           AppCode   = ISNULL(p.AppCode, N'OTHER'),
           Completed = SUM(CASE WHEN sm.Category = 'Completed' THEN 1 ELSE 0 END),
           Amount    = SUM(CASE WHEN sm.Category = 'Completed' THEN ISNULL(p.Amount, 0) ELSE 0 END),
           Failed    = SUM(CASE WHEN sm.Category = 'Failed' THEN 1 ELSE 0 END),
           SysFailed = SUM(CASE WHEN sm.Category = 'Failed' AND rc.Class = 'System' THEN 1 ELSE 0 END),
           Pending   = SUM(CASE WHEN ISNULL(sm.Category, 'Pending') = 'Pending' THEN 1 ELSE 0 END)
    INTO   #d
    FROM   dbo.PaymentTxn p
    LEFT JOIN dbo.StatusMap   sm ON sm.StatusCode = p.StatusCode
    LEFT JOIN dbo.ReasonClass rc ON rc.ReasonCode = ISNULL(p.ErrorCode, N'(no code)')
    WHERE  p.TranTs >= CAST(@from AS datetime2(0))
    GROUP BY CAST(p.TranTs AS date), ISNULL(p.AppCode, N'OTHER');

    DECLARE @rows int;
    BEGIN TRY
        BEGIN TRAN;
        DELETE dbo.DailySummary WHERE Day >= @from;
        INSERT dbo.DailySummary (Day, AppCode, Completed, Amount, Failed, SysFailed, Pending, Source, RefreshedTs)
        SELECT Day, AppCode, Completed, Amount, Failed, SysFailed, Pending, 'L', @now FROM #d;
        SET @rows = @@ROWCOUNT;
        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH;
    RETURN @rows;
END;
GO

/* =====================================================================
   2. ONE-TIME backfill of earlier days from Billing_V2 (read only)
      Uses the same LocalTxnQuery as the collector, with an upper bound
      on modifiedDate so each call reads one day of changes through the
      modifiedDate index. A payment counts in its final state on the day
      it was requested. Writes only dbo.DailySummary (Source = 'B').

      @from      first day to fill
      @to        first day NOT to fill (default: where live data starts)
      @lateDays  also read changes this many days after @to, so ACH
                 returns are counted (default 45)
      @pauseMs   pause between days to stay gentle on Billing_V2
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.usp_BackfillHistory
    @from     date,
    @to       date = NULL,
    @lateDays int  = 45,
    @pauseMs  int  = 200
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @liveStart date = DATEADD(DAY, 1, CAST((SELECT MIN(TranTs) FROM dbo.PaymentTxn) AS date));
    SET @to = ISNULL(@to, ISNULL(@liveStart, CAST(SYSDATETIME() AS date)));
    IF @from >= @to
    BEGIN
        RAISERROR(N'Nothing to do: @from must be before @to (%s).', 0, 1, N'check the dates') WITH NOWAIT;
        RETURN 0;
    END;

    DECLARE @q nvarchar(max) = dbo.fn_Cfg(N'LocalTxnQuery');
    IF ISNULL(@q, N'') = N'' OR @q NOT LIKE N'%t.modifiedDate >= @since%'
        THROW 50020, N'LocalTxnQuery is empty or does not contain "t.modifiedDate >= @since" - the backfill needs that filter to read one day at a time.', 1;
    SET @q = REPLACE(@q, N't.modifiedDate >= @since', N't.modifiedDate >= @since AND t.modifiedDate < @until');

    CREATE TABLE #stage (TranId nvarchar(64) NOT NULL, TranTs datetime2(0) NULL, AppCode nvarchar(50) NULL,
                         StatusCode nvarchar(50) NULL, Amount decimal(12,2) NULL,
                         ErrorCode nvarchar(100) NULL, ErrorText nvarchar(400) NULL);
    CREATE TABLE #agg (Day date, AppCode nvarchar(50), Completed int, Amount decimal(14,2),
                       Failed int, SysFailed int, Pending int);

    DECLARE @d datetime2(0) = CAST(@from AS datetime2(0)),
            @end datetime2(0) = DATEADD(DAY, @lateDays, CAST(@to AS datetime2(0))),
            @n int = 0, @rowsRead bigint = 0, @msg nvarchar(200),
            @delay varchar(12);
    IF @pauseMs < 0 OR @pauseMs > 59000 SET @pauseMs = 200;
    SET @delay = '00:00:' + RIGHT('0' + CAST(@pauseMs / 1000 AS varchar(2)), 2) + '.' + RIGHT('00' + CAST(@pauseMs % 1000 AS varchar(3)), 3);
    IF @end > SYSDATETIME() SET @end = SYSDATETIME();

    RAISERROR(N'Backfill: reading Billing_V2 changes one day at a time ...', 0, 1) WITH NOWAIT;
    WHILE @d < @end
    BEGIN
        TRUNCATE TABLE #stage;
        DECLARE @until datetime2(0) = DATEADD(DAY, 1, @d);
        INSERT #stage EXEC sys.sp_executesql @q, N'@since datetime2(0), @until datetime2(0)', @since = @d, @until = @until;
        SET @rowsRead += @@ROWCOUNT;

        INSERT #agg (Day, AppCode, Completed, Amount, Failed, SysFailed, Pending)
        SELECT CAST(s.TranTs AS date), ISNULL(s.AppCode, N'OTHER'),
               SUM(CASE WHEN sm.Category = 'Completed' THEN 1 ELSE 0 END),
               SUM(CASE WHEN sm.Category = 'Completed' THEN ISNULL(s.Amount, 0) ELSE 0 END),
               SUM(CASE WHEN sm.Category = 'Failed' THEN 1 ELSE 0 END),
               SUM(CASE WHEN sm.Category = 'Failed' AND rc.Class = 'System' THEN 1 ELSE 0 END),
               SUM(CASE WHEN ISNULL(sm.Category, 'Pending') = 'Pending' THEN 1 ELSE 0 END)
        FROM #stage s
        LEFT JOIN dbo.StatusMap   sm ON sm.StatusCode = s.StatusCode
        LEFT JOIN dbo.ReasonClass rc ON rc.ReasonCode = ISNULL(s.ErrorCode, N'(no code)')
        WHERE s.TranTs >= CAST(@from AS datetime2(0)) AND s.TranTs < CAST(@to AS datetime2(0))
        GROUP BY CAST(s.TranTs AS date), ISNULL(s.AppCode, N'OTHER');

        SET @n += 1;
        IF @n % 14 = 0
        BEGIN
            SET @msg = CONCAT(N'  read changes up to ', CONVERT(nvarchar(10), @until, 120), N' (', @rowsRead, N' rows so far)');
            RAISERROR(@msg, 0, 1) WITH NOWAIT;
        END;
        SET @d = @until;
        IF @pauseMs > 0 WAITFOR DELAY @delay;
    END;

    DECLARE @rows int;
    BEGIN TRY
        BEGIN TRAN;
        DELETE dbo.DailySummary WHERE Day >= @from AND Day < @to;
        INSERT dbo.DailySummary (Day, AppCode, Completed, Amount, Failed, SysFailed, Pending, Source, RefreshedTs)
        SELECT Day, AppCode, SUM(Completed), SUM(Amount), SUM(Failed), SUM(SysFailed), SUM(Pending), 'B', SYSDATETIME()
        FROM #agg GROUP BY Day, AppCode;
        SET @rows = @@ROWCOUNT;
        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH;

    SET @msg = CONCAT(N'Backfill done: ', @rowsRead, N' transactions read, ', @rows, N' day/application rows written for ',
                      CONVERT(nvarchar(10), @from, 120), N' to ', CONVERT(nvarchar(10), DATEADD(DAY, -1, @to), 120), N'.');
    RAISERROR(@msg, 0, 1) WITH NOWAIT;
    RETURN @rows;
END;
GO

/* =====================================================================
   3. Fill history from live data now (last 60 days)
   ===================================================================== */
DECLARE @r int;
EXEC @r = dbo.usp_RefreshDailySummary @full = 1;
SELECT CONCAT(@r, N' day/application rows refreshed from PaymentTxn') AS refresh_result;
GO

/* =====================================================================
   4. CHECKS and the backfill command to run (read the output)
   ===================================================================== */
DECLARE @cs date = TRY_CAST(dbo.fn_Cfg(N'CycleStart') AS date);
DECLARE @liveStart date = DATEADD(DAY, 1, CAST((SELECT MIN(TranTs) FROM dbo.PaymentTxn) AS date));
DECLARE @oldestB2 datetime2(0) = (SELECT MIN(modifiedDate) FROM Billing_V2.dbo.[transaction] WITH (NOLOCK));  -- modifiedDate index: cheap
DECLARE @suggest date = DATEADD(MONTH, -1, DATEADD(YEAR, -2, ISNULL(@cs, DATEFROMPARTS(YEAR(SYSDATETIME()) + 1, 1, 1))));
IF @suggest < CAST(@oldestB2 AS date) SET @suggest = CAST(@oldestB2 AS date);

SELECT MIN(Day) AS history_from, MAX(Day) AS history_to, COUNT(*) AS rows,
       SUM(CASE WHEN Source = 'B' THEN 1 ELSE 0 END) AS backfilled_rows,
       @liveStart AS live_data_starts, @oldestB2 AS billing_v2_oldest_change
FROM dbo.DailySummary;

-- How much the suggested backfill would read (index range count on modifiedDate)
SELECT @suggest AS suggested_from, @liveStart AS backfill_to,
       (SELECT COUNT_BIG(*) FROM Billing_V2.dbo.[transaction] WITH (NOLOCK)
        WHERE modifiedDate >= @suggest AND modifiedDate < DATEADD(DAY, 45, ISNULL(@liveStart, SYSDATETIME()))) AS transactions_to_read,
       CONCAT(N'EXEC billingdashboard.dbo.usp_BackfillHistory @from = ''', CONVERT(nvarchar(10), @suggest, 120), N''';') AS run_this_off_hours;

-- Completed payments and amount per billing cycle in history (after the backfill this shows earlier cycles too)
SELECT YEAR(Day) AS year, MONTH(Day) AS month, SUM(Completed) AS completed, SUM(Amount) AS amount,
       SUM(Failed) AS failed, SUM(SysFailed) AS system_failures
FROM dbo.DailySummary GROUP BY YEAR(Day), MONTH(Day) ORDER BY year DESC, month DESC;
