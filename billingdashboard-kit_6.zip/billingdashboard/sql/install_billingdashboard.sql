/* =====================================================================
   install_billingdashboard.sql
   Creates the DEDICATED database billingdashboard and installs 01-04.
   Existing user databases (Billing_V2, CABAR, ...) are NOT changed:
   they are only read, by the SQL Agent job.

   >>> Run in SQLCMD MODE (SSMS: Query > SQLCMD Mode) <<<
   >>> Connect to the LISTENER SFDBSLISTN01 (lands on the primary) <<<
   Safe to re-run.
   ===================================================================== */
:setvar KitPath    "C:\billingdashboard\sql"
:setvar SvcAccount "CALSB\svc_billingdashboard"
:on error exit

/* ---- 1. the dedicated database --------------------------------------- */
USE master;
GO
IF DB_ID(N'billingdashboard') IS NULL
BEGIN
    CREATE DATABASE billingdashboard;          -- instance default data/log paths
    ALTER DATABASE billingdashboard SET RECOVERY FULL;   -- required to join the AG
    ALTER AUTHORIZATION ON DATABASE::billingdashboard TO sa;
    ALTER DATABASE billingdashboard MODIFY FILE (NAME = N'billingdashboard',     SIZE = 1GB,   FILEGROWTH = 256MB);
    ALTER DATABASE billingdashboard MODIFY FILE (NAME = N'billingdashboard_log', SIZE = 512MB, FILEGROWTH = 256MB);
    PRINT 'Created database billingdashboard.';
END
ELSE PRINT 'Database billingdashboard already exists - keeping it.';
GO

/* ---- 2. objects ------------------------------------------------------- */
PRINT '== 01 tables and config ==';       :r $(KitPath)\01_schema.sql
PRINT '== 02 collector procedure ==';     :r $(KitPath)\02_collect_proc.sql
PRINT '== 03 dashboard JSON procedure =='; :r $(KitPath)\03_dashboard_json_proc.sql
PRINT '== 04 GEORGE config ==';           :r $(KitPath)\04_config_george.sql

/* ---- 3. service account: access to billingdashboard ONLY ------------ */
USE master;
GO
IF SUSER_ID(N'$(SvcAccount)') IS NULL
    CREATE LOGIN [$(SvcAccount)] FROM WINDOWS WITH DEFAULT_DATABASE = [billingdashboard];
GO
USE billingdashboard;
GO
IF DATABASE_PRINCIPAL_ID(N'$(SvcAccount)') IS NULL
    CREATE USER [$(SvcAccount)] FOR LOGIN [$(SvcAccount)];
ALTER ROLE billingdashboard_reader ADD MEMBER [$(SvcAccount)];
GO

/* ---- 4. what got installed + the AG to add it to ------------------- */
USE billingdashboard;
SELECT o.type_desc, o.name FROM sys.objects o
WHERE o.is_ms_shipped = 0 AND o.type IN ('U','P','FN') ORDER BY o.type_desc, o.name;

SELECT ag.name AS add_billingdashboard_to_this_AG, ag.automated_backup_preference_desc
FROM sys.availability_databases_cluster adc
JOIN sys.availability_groups ag ON ag.group_id = adc.group_id
WHERE adc.database_name = N'Billing_V2';
PRINT '== Done. Next: add billingdashboard to the AG shown above (runbook Step 5). ==';
