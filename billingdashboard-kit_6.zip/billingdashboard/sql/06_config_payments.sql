/* =====================================================================
   06_config_payments.sql  -  connects the payment charts to Billing_V2
   Run on the LISTENER SFDBSLISTN01 (normal mode, not SQLCMD).
   Changes ONLY the billingdashboard database. Billing_V2 is only read.

   Built from the discovery report of 2026-11-13:
     Billing_V2.dbo.[transaction]   one row per payment attempt
        transactionTypeId   1 ACH, 2 CreditCard
        transactionStatusId 1 Pending, 2 In Process, 3 Paid, 4 Rejected
        decision            gateway decision (ACCEPT / REJECT / ERROR / REVIEW)
        reasonCode          gateway reason (100 = success), text in transactionReason
        requestDateTime     when the attempt was made
        modifiedDate        indexed (MH_IX_transaction_modifiedDate_Includes)
     applicationTransactions  transactionId -> applicationId
     application              16 applications (Agency Billing, MSBP, COS ...)
     ccReportProcess / achReportProcess   daily 08:00 report runs
     as400BMADPNDP            payments queued for GEORGE (daily ~08:15)

   No card, bank, token, name or address column is read.
   ===================================================================== */
USE billingdashboard;
GO

/* ---------------------------------------------------------------------
   1. Application groups (editable). 16 applications fold into 5 groups
      so the charts stay readable. Change AppCode to regroup.
   --------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.AppGroup') IS NULL
CREATE TABLE dbo.AppGroup (
    applicationId   int           NOT NULL CONSTRAINT PK_AppGroup PRIMARY KEY,
    applicationName nvarchar(200) NOT NULL,
    AppCode         nvarchar(50)  NOT NULL
);
GO
MERGE dbo.AppGroup AS t
USING (
    SELECT a.applicationId, a.applicationName,
           AppCode = CASE
               WHEN a.applicationId IN (2, 12, 16)           THEN N'MSBP'    -- My State Bar Profile (+ fingerprint penalty, voluntary resignation)
               WHEN a.applicationId IN (1, 9, 11)            THEN N'AB'      -- Agency Billing (+ AB fingerprinting / penalty)
               WHEN a.applicationId = 3                      THEN N'COS'     -- Certificate of Standing
               WHEN a.applicationId IN (8, 10)               THEN N'ENT'     -- LLP / LLC renewals
               ELSE N'OTHER' END                                             -- MCLE self study, sections, contributions, online school ...
    FROM Billing_V2.dbo.application a WITH (NOLOCK)
) AS s ON t.applicationId = s.applicationId
WHEN NOT MATCHED THEN INSERT (applicationId, applicationName, AppCode)
                      VALUES (s.applicationId, s.applicationName, s.AppCode)
WHEN MATCHED AND t.applicationName <> s.applicationName
     THEN UPDATE SET applicationName = s.applicationName;
GO

DELETE dbo.AppMap;
INSERT dbo.AppMap (AppCode, AppName, SortOrder) VALUES
 (N'MSBP',  N'My State Bar Profile',    1),
 (N'AB',    N'Agency Billing',          2),
 (N'COS',   N'Certificate of Standing', 3),
 (N'ENT',   N'LLP / LLC renewals',      4),
 (N'OTHER', N'Other applications',      5);
GO

/* ---------------------------------------------------------------------
   2. Outcome codes produced by the query below -> dashboard category
   --------------------------------------------------------------------- */
DELETE dbo.StatusMap;
INSERT dbo.StatusMap (StatusCode, Category, Description) VALUES
 (N'ACCEPTED', 'Completed', N'Gateway decision ACCEPT, or status Paid'),
 (N'DECLINED', 'Failed',    N'Gateway decision REJECT or ERROR (see reason code)'),
 (N'RETURNED', 'Failed',    N'Accepted, later set to Rejected (ACH return / settlement reject)'),
 (N'REVIEW',   'Pending',   N'Gateway decision REVIEW'),
 (N'PENDING',  'Pending',   N'Status Pending, no decision yet');
GO

/* ---------------------------------------------------------------------
   3. The transaction query (runs every 2 minutes, reads ~6 hours of
      changes through the modifiedDate index)
   --------------------------------------------------------------------- */
UPDATE dbo.Config SET ConfigValue = N'SELECT CAST(t.transactionId AS nvarchar(64)) AS TRAN_ID,
       CAST(t.requestDateTime AS datetime2(0)) AS TRAN_TS,
       ISNULL(g.AppCode, N''OTHER'') AS APP_CODE,
       CASE WHEN t.decision IN (''REJECT'', ''ERROR'')                 THEN N''DECLINED''
            WHEN t.transactionStatusId = 4                           THEN N''RETURNED''
            WHEN t.decision = ''REVIEW''                               THEN N''REVIEW''
            WHEN t.decision = ''ACCEPT'' OR t.transactionStatusId = 3   THEN N''ACCEPTED''
            ELSE N''PENDING'' END AS STATUS_CODE,
       CAST(t.amount AS decimal(12,2)) AS AMOUNT,
       CASE WHEN t.decision IN (''REJECT'', ''ERROR'') OR t.transactionStatusId = 4
            THEN CASE WHEN t.reasonCode = 100 THEN N''RETURNED'' ELSE CAST(t.reasonCode AS nvarchar(100)) END
       END AS ERROR_CODE,
       CASE WHEN t.decision IN (''REJECT'', ''ERROR'') OR t.transactionStatusId = 4
            THEN CASE WHEN t.reasonCode = 100 THEN N''Rejected after acceptance (ACH return / settlement)''
                      ELSE ISNULL(r.txt, N''Reason code '' + CAST(t.reasonCode AS nvarchar(10))) END
       END AS ERROR_TEXT
FROM Billing_V2.dbo.[transaction] t WITH (NOLOCK)
OUTER APPLY (SELECT TOP (1) at.applicationId
             FROM Billing_V2.dbo.applicationTransactions at WITH (NOLOCK)
             WHERE at.transactionId = t.transactionId AND at.isDeleted = N''N''
             ORDER BY at.applicationTransactionId) a
LEFT JOIN billingdashboard.dbo.AppGroup g ON g.applicationId = a.applicationId
OUTER APPLY (SELECT TOP (1)
                 LTRIM(RTRIM(LEFT(REPLACE(REPLACE(d.x, CHAR(13), N'' ''), CHAR(10), N'' ''),
                                  CHARINDEX(N''Possible'', d.x + N''Possible'') - 1))) AS txt
             FROM Billing_V2.dbo.transactionReason tr WITH (NOLOCK)
             CROSS APPLY (SELECT CAST(tr.transactionReasonCodeDescription AS nvarchar(500)) AS x) d
             WHERE tr.transactionReasonCode = t.reasonCode
             ORDER BY tr.transactionReasonCodeId) r
WHERE t.modifiedDate >= @since
  AND t.isDeleted = ''N'''
WHERE ConfigKey = N'LocalTxnQuery';
GO

/* ---------------------------------------------------------------------
   4. Billing job runs, from Billing_V2's own process tables
      - ccReportProcess / achReportProcess: one row per daily 08:00 run;
        a row is marked isDeleted = Y when processed. A row still N more
        than 1 hour past its scheduled time = the run did not happen.
      - as400BMADPNDP: rows written for GEORGE each day (reads only the
        newest 20,000 rows by the clustered key, never the whole table)
   --------------------------------------------------------------------- */
UPDATE dbo.Config SET ConfigValue = N'SELECT N''Credit card report (ccReportProcess)'' AS JOB_NAME,
       CAST(p.modifiedDate AS datetime2(0)) AS RUN_START, CAST(p.modifiedDate AS datetime2(0)) AS RUN_END,
       ''Succeeded'' AS STATUS, CAST(NULL AS int) AS ROWS_PROCESSED,
       N''Processed run scheduled for '' + CONVERT(nvarchar(16), p.ccReportDateToProcess, 120) AS MESSAGE
FROM Billing_V2.dbo.ccReportProcess p WITH (NOLOCK)
WHERE p.isDeleted = ''Y'' AND p.modifiedDate >= DATEADD(DAY, -3, SYSDATETIME())
UNION ALL
SELECT N''Credit card report (ccReportProcess)'', CAST(p.ccReportDateToProcess AS datetime2(0)), NULL,
       ''Failed'', NULL, N''Scheduled run has not been processed''
FROM Billing_V2.dbo.ccReportProcess p WITH (NOLOCK)
WHERE p.isDeleted = ''N'' AND p.ccReportDateToProcess < DATEADD(HOUR, -1, SYSDATETIME())
UNION ALL
SELECT N''ACH report (achReportProcess)'',
       CAST(p.modifiedDate AS datetime2(0)), CAST(p.modifiedDate AS datetime2(0)),
       ''Succeeded'', NULL,
       N''Processed run scheduled for '' + CONVERT(nvarchar(16), p.achReportDateToProcess, 120)
FROM Billing_V2.dbo.achReportProcess p WITH (NOLOCK)
WHERE p.isDeleted = ''Y'' AND p.modifiedDate >= DATEADD(DAY, -3, SYSDATETIME())
UNION ALL
SELECT N''ACH report (achReportProcess)'', CAST(p.achReportDateToProcess AS datetime2(0)), NULL,
       ''Failed'', NULL, N''Scheduled run has not been processed''
FROM Billing_V2.dbo.achReportProcess p WITH (NOLOCK)
WHERE p.isDeleted = ''N'' AND p.achReportDateToProcess < DATEADD(HOUR, -1, SYSDATETIME())
UNION ALL
SELECT N''Post payments to GEORGE (as400BMADPNDP)'',
       CAST(MIN(x.createdDate) AS datetime2(0)), CAST(MAX(x.createdDate) AS datetime2(0)),
       ''Succeeded'', COUNT(*),
       CAST(SUM(CASE WHEN x.isPostedToKoala = 1 THEN 1 ELSE 0 END) AS nvarchar(10)) + N'' of '' +
       CAST(COUNT(*) AS nvarchar(10)) + N'' rows flagged posted to KOALA''
FROM (SELECT TOP (20000) b.createdDate, b.isPostedToKoala
      FROM Billing_V2.dbo.as400BMADPNDP b WITH (NOLOCK)
      ORDER BY b.bmadpndpId DESC) x
WHERE x.createdDate >= DATEADD(DAY, -3, SYSDATETIME())
GROUP BY CAST(x.createdDate AS date)'
WHERE ConfigKey = N'AppJobLogQuery';
GO

/* ---------------------------------------------------------------------
   5. Members-paid: count only members who were actually billed
      (BMMASTP holds ~370,000 rows per year, most with nothing billed)
   --------------------------------------------------------------------- */
UPDATE dbo.Config SET ConfigValue = N'SELECT COUNT(*) AS MEMBERS_BILLED,
       SUM(CASE WHEN M.BM$TBL + M.BM$TPB + M.BM$TDC + M.BM$TAD + M.BM$TPY <= 0
                THEN 1 ELSE 0 END)                       AS MEMBERS_PAID,
       SUM(M.BM$TBL + M.BM$TPB + M.BM$TDC)                AS AMOUNT_BILLED,
       SUM(0 - M.BM$TPY)                                  AS AMOUNT_PAID
FROM   PRDT.BMMASTP M
WHERE  M.BMBLYR = {CYCLE_YEAR}
  AND  M.BMBLPD = 1
  AND  M.BM$TBL > 0
WITH UR'
WHERE ConfigKey = N'GeorgeProgressQuery';

/* The old JobRun rows from the placeholder config are not needed */
DELETE dbo.JobRun WHERE Source = 'AppLog';
/* Force a fresh progress snapshot on the next run */
DELETE dbo.BillingProgress;
GO

/* =====================================================================
   6. CHECKS  (read only)
   ===================================================================== */
-- 6a. No placeholders left (expect: no rows)
SELECT ConfigKey FROM dbo.Config WHERE ConfigValue LIKE N'%<%_COL>%' AND ConfigKey <> N'GeorgeTxnQuery';

-- 6b. How the last 30 days of attempts map to outcomes (sanity check of the mapping)
SELECT t.decision, t.transactionStatusId, t.transactionTypeId,
       COUNT(*) AS attempts, MIN(t.requestDateTime) AS first_seen, MAX(t.requestDateTime) AS last_seen
FROM Billing_V2.dbo.[transaction] t WITH (NOLOCK)
WHERE t.modifiedDate >= DATEADD(DAY, -30, SYSDATETIME()) AND t.isDeleted = 'N'
GROUP BY t.decision, t.transactionStatusId, t.transactionTypeId
ORDER BY attempts DESC;

-- 6c. One-time backfill: load the last 60 days so the daily charts have
--     history, then go back to the normal 6-hour window. Run the collector
--     and show the result of each step.
UPDATE dbo.Config SET ConfigValue = N'1440' WHERE ConfigKey = N'TxnLookbackHours';
EXEC dbo.usp_Collect;
UPDATE dbo.Config SET ConfigValue = N'6'    WHERE ConfigKey = N'TxnLookbackHours';
SELECT TOP (6) RunTs, Step, Status, RowsAff, DurationMs, Message
FROM dbo.CollectLog ORDER BY LogId DESC;

-- 6d. What the dashboard will show for today
SELECT ISNULL(sm.Category, 'Pending') AS outcome, p.AppCode, COUNT(*) AS payments, SUM(p.Amount) AS amount
FROM dbo.PaymentTxn p
LEFT JOIN dbo.StatusMap sm ON sm.StatusCode = p.StatusCode
WHERE p.TranTs >= CAST(CAST(SYSDATETIME() AS date) AS datetime2(0))
GROUP BY ISNULL(sm.Category, 'Pending'), p.AppCode
ORDER BY outcome, payments DESC;
