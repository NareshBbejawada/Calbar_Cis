/* =====================================================================
   08_database_mail.sql  -  Database Mail profile for billingdashboard alerts
   >>> Run in SQLCMD MODE <<<
   >>> Run on EACH of the 4 AG nodes, connected to the node directly
       (the job runs on whichever node is primary, so every node needs
       the same profile name). <<<

   SKIP THIS SCRIPT if the instances already have a working Database
   Mail profile (e.g. the one used for SQL Agent operator alerts): just
   put its name in billingdashboard.dbo.Config 'MailProfile'.

   Instance-level only (msdb). No user database is touched.
   ===================================================================== */
:setvar ProfileName  "billingdashboard"
:setvar SmtpServer   "<smtp relay host, e.g. smtp.calbar.org>"
:setvar SmtpPort     "25"
:setvar FromAddress  "<sender, e.g. sqlalerts@calbar.ca.gov>"
:setvar DisplayName  "Billing Dashboard (SQL)"
:setvar TestTo       "<your email address>"
:on error exit

USE master;
GO
/* Database Mail XPs must be on */
IF (SELECT CAST(value_in_use AS int) FROM sys.configurations WHERE name = N'Database Mail XPs') = 0
BEGIN
    EXEC sys.sp_configure N'show advanced options', 1; RECONFIGURE;
    EXEC sys.sp_configure N'Database Mail XPs', 1;     RECONFIGURE;
    PRINT 'Database Mail XPs enabled.';
END;
GO

USE msdb;
GO
IF NOT EXISTS (SELECT 1 FROM msdb.dbo.sysmail_account WHERE name = N'$(ProfileName)')
    EXEC msdb.dbo.sysmail_add_account_sp
         @account_name    = N'$(ProfileName)',
         @email_address   = N'$(FromAddress)',
         @display_name    = N'$(DisplayName)',
         @mailserver_name = N'$(SmtpServer)',
         @port            = $(SmtpPort);

IF NOT EXISTS (SELECT 1 FROM msdb.dbo.sysmail_profile WHERE name = N'$(ProfileName)')
BEGIN
    EXEC msdb.dbo.sysmail_add_profile_sp
         @profile_name = N'$(ProfileName)',
         @description  = N'Alerts and daily summary from the billingdashboard database';
    EXEC msdb.dbo.sysmail_add_profileaccount_sp
         @profile_name = N'$(ProfileName)', @account_name = N'$(ProfileName)', @sequence_number = 1;
END;
GO

/* Test email from this node */
DECLARE @subj nvarchar(200) = N'billingdashboard Database Mail test from ' + @@SERVERNAME;
EXEC msdb.dbo.sp_send_dbmail @profile_name = N'$(ProfileName)', @recipients = N'$(TestTo)',
     @subject = @subj, @body = N'If you can read this, Database Mail works on this node.';
GO
WAITFOR DELAY '00:00:10';
SELECT TOP (5) mailitem_id, sent_status, sent_date, subject FROM msdb.dbo.sysmail_allitems ORDER BY mailitem_id DESC;
SELECT TOP (5) log_date, description FROM msdb.dbo.sysmail_event_log ORDER BY log_id DESC;
