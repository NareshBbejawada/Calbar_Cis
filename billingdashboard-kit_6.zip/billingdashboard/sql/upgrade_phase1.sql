/* =====================================================================
   upgrade_phase1.sql  -  adds Phase 1 (proactive alerts) to a running
   billingdashboard. Equivalent to running 01, 02, 03 and 07 in order.

   >>> Run in SQLCMD MODE <<<
   >>> Connect to the LISTENER SFDBSLISTN01 <<<
   Changes ONLY the billingdashboard database. Existing data, your edits
   to dbo.Config / AppGroup / AppMap / StatusMap are kept.
   Alerts start in AlertMode = 'LogOnly' (nothing is emailed).
   The SQL Agent job does NOT need to change.
   ===================================================================== */
:setvar KitPath "C:\billingdashboard\sql"
:on error exit

PRINT '== 01 tables and config (Phase 1 tables added) =='; :r $(KitPath)\01_schema.sql
PRINT '== 02 collector procedure (calls the alert steps) =='; :r $(KitPath)\02_collect_proc.sql
PRINT '== 03 dashboard JSON (gateway errors, alerts, system vs decline) =='; :r $(KitPath)\03_dashboard_json_proc.sql
PRINT '== 07 alert procedures + checks =='; :r $(KitPath)\07_alerts.sql
PRINT '== Done. Copy web\index.html to \\AZDBAPRD01\billingdashboard\ ==';
