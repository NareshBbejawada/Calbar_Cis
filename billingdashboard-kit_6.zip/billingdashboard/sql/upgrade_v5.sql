/* =====================================================================
   upgrade_v5.sql  -  brings a running billingdashboard to kit v5
   (Phase 1 alerts + proactive v5). Works from v3 or v4.
   >>> SQLCMD MODE, connected to the LISTENER SFDBSLISTN01 <<<
   Changes ONLY the billingdashboard database; your Config edits are kept.
   The SQL Agent job does not change. Re-runnable.
   ===================================================================== */
:setvar KitPath "C:\billingdashboard\sql"
:on error exit

PRINT '== 01 tables and config =='; :r $(KitPath)\01_schema.sql
PRINT '== 02 collector ==';         :r $(KitPath)\02_collect_proc.sql
PRINT '== 03 dashboard JSON ==';    :r $(KitPath)\03_dashboard_json_proc.sql
PRINT '== 07 alerts ==';            :r $(KitPath)\07_alerts.sql
PRINT '== 09 proactive v5 ==';      :r $(KitPath)\09_proactive.sql
PRINT '== Done. Copy web\index.html to \\AZDBAPRD01\billingdashboard\ ==';
