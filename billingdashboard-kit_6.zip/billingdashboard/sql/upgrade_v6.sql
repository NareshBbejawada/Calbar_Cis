/* =====================================================================
   upgrade_v6.sql  -  brings a running billingdashboard to kit v6
   (Phase 1 alerts + proactive v5 + daily history v6). Works from v3, v4, v5.
   >>> SQLCMD MODE, connected to the LISTENER SFDBSLISTN01 <<<
   Changes ONLY the billingdashboard database; your Config edits are kept.
   The SQL Agent job does not change. Re-runnable.
   The one-time history backfill is NOT run here: 10_history.sql prints
   the command to run off-hours.
   ===================================================================== */
:setvar KitPath "C:\billingdashboard\sql"
:on error exit

PRINT '== 01 tables and config =='; :r $(KitPath)\01_schema.sql
PRINT '== 02 collector ==';         :r $(KitPath)\02_collect_proc.sql
PRINT '== 03 dashboard JSON ==';    :r $(KitPath)\03_dashboard_json_proc.sql
PRINT '== 07 alerts ==';            :r $(KitPath)\07_alerts.sql
PRINT '== 09 proactive v5 ==';      :r $(KitPath)\09_proactive.sql
PRINT '== 10 daily history v6 ==';  :r $(KitPath)\10_history.sql
PRINT '== Done. Copy web\index.html to \\AZDBAPRD01\billingdashboard\ ==';
