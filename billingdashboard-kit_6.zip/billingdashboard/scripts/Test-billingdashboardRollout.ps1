<#
.SYNOPSIS
    Read-only rollout check for billingdashboard: AG membership, job on every
    node, credential/proxy, Database Mail, backups, data.json freshness, collector
    and alert settings. Changes nothing.

.DESCRIPTION
    Run from a DBA workstation (or any AG node) as a DBA with Windows auth.
    Finds the AG replicas from the listener, then connects to each node directly.
    Uses only System.Data.SqlClient (no SqlServer module).

.EXAMPLE
    .\Test-billingdashboardRollout.ps1
    .\Test-billingdashboardRollout.ps1 -Listener SFDBSLISTN01 -DataJson '\\AZDBAPRD01\billingdashboard\data.json'
#>
[CmdletBinding()]
param(
    [string] $Listener = 'SFDBSLISTN01',
    [string] $DataJson = '\\AZDBAPRD01\billingdashboard\data.json',
    [string] $JobName  = 'billingdashboard - Collect',
    [string] $ExportScriptLocalPath = 'D:\DBA\billingdashboard\Export-billingdashboard.ps1'
)

$results = New-Object System.Collections.Generic.List[object]
function Add-Result([string]$Area, [string]$Target, [string]$Status, [string]$Detail) {
    $results.Add([pscustomobject]@{ Area = $Area; Target = $Target; Status = $Status; Detail = $Detail })
}
function Invoke-Q([string]$Server, [string]$Query, [string]$Db = 'master') {
    $cs = "Server=$Server;Database=$Db;Integrated Security=SSPI;Connect Timeout=10;MultiSubnetFailover=True;Application Name=billingdashboard-check"
    $conn = New-Object System.Data.SqlClient.SqlConnection $cs
    try {
        $conn.Open()
        $cmd = $conn.CreateCommand(); $cmd.CommandText = $Query; $cmd.CommandTimeout = 30
        $t = New-Object System.Data.DataTable
        $t.Load($cmd.ExecuteReader())
        return ,$t
    } finally { $conn.Dispose() }
}

# ---------------------------------------------------------------- listener
try {
    $ag = Invoke-Q $Listener @"
SELECT ag.name AS ag_name, adc.database_name
FROM sys.availability_databases_cluster adc
JOIN sys.availability_groups ag ON ag.group_id = adc.group_id
WHERE adc.database_name IN (N'Billing_V2', N'billingdashboard');
"@
    $bv = $ag | Where-Object database_name -eq 'Billing_V2'
    $bd = $ag | Where-Object database_name -eq 'billingdashboard'
    if (-not $bd) { Add-Result 'AG' $Listener 'FAIL' 'billingdashboard is not in an availability group (job only works on the node where it lives)' }
    elseif ($bv -and $bd.ag_name -ne $bv.ag_name) { Add-Result 'AG' $Listener 'WARN' "billingdashboard is in $($bd.ag_name), Billing_V2 in $($bv.ag_name)" }
    else { Add-Result 'AG' $Listener 'PASS' "billingdashboard is in $($bd.ag_name) with Billing_V2" }

    $replicas = Invoke-Q $Listener @"
SELECT ar.replica_server_name, ars.role_desc, ar.availability_mode_desc,
       drs.synchronization_state_desc, drs.synchronization_health_desc
FROM sys.availability_replicas ar
JOIN sys.availability_groups ag ON ag.group_id = ar.group_id
JOIN sys.availability_databases_cluster adc ON adc.group_id = ag.group_id AND adc.database_name = N'Billing_V2'
LEFT JOIN sys.dm_hadr_availability_replica_states ars ON ars.replica_id = ar.replica_id
LEFT JOIN sys.dm_hadr_database_replica_states drs ON drs.replica_id = ar.replica_id
      AND drs.database_id = DB_ID(N'billingdashboard')
ORDER BY ar.replica_server_name;
"@
    foreach ($r in $replicas) {
        $h = "$($r.synchronization_health_desc)"
        $st = if ($h -eq 'HEALTHY') { 'PASS' } elseif ($h -eq '') { 'FAIL' } else { 'WARN' }
        Add-Result 'AG replica' $r.replica_server_name $st "$($r.role_desc) $($r.availability_mode_desc); billingdashboard: $(if ($h) { "$($r.synchronization_state_desc) / $h" } else { 'not joined on this replica' })"
    }

    $cfg = Invoke-Q $Listener @"
SELECT ConfigKey, ConfigValue FROM dbo.Config
WHERE ConfigKey IN (N'AlertMode', N'MailProfile', N'AlertRecipientsIT', N'AlertRecipientsMgmt', N'GatewayErrorQuery', N'CycleStart', N'BillingYear');
"@ 'billingdashboard'
    $c = @{}; foreach ($row in $cfg) { $c[$row.ConfigKey] = "$($row.ConfigValue)" }
    if (-not $c.ContainsKey('AlertMode')) { Add-Result 'Phase 1' $Listener 'FAIL' 'Phase 1 not installed (run sql\upgrade_phase1.sql)' }
    else {
        Add-Result 'Phase 1' 'AlertMode' $(if ($c.AlertMode -eq 'Send') { 'PASS' } else { 'INFO' }) "AlertMode = $($c.AlertMode)"
        Add-Result 'Phase 1' 'Recipients' $(if ($c.AlertRecipientsIT) { 'PASS' } else { 'WARN' }) "IT: '$($c.AlertRecipientsIT)'  Mgmt: '$($c.AlertRecipientsMgmt)'"
        Add-Result 'Phase 1' 'GatewayErrorQuery' $(if ($c.GatewayErrorQuery) { 'PASS' } else { 'WARN' }) $(if ($c.GatewayErrorQuery) { 'configured' } else { 'empty - exceptionLog columns not found by 07_alerts.sql' })
    }
    Add-Result 'Config' 'Cycle' 'INFO' "CycleStart $($c.CycleStart), BillingYear $($c.BillingYear)"

    $log = Invoke-Q $Listener @"
SELECT l.Step, l.Status, l.RunTs, l.Message
FROM dbo.CollectLog l
WHERE l.LogId IN (SELECT MAX(LogId) FROM dbo.CollectLog GROUP BY Step)
ORDER BY l.Step;
"@ 'billingdashboard'
    foreach ($l in $log) {
        $age = [int]((Get-Date) - [datetime]$l.RunTs).TotalMinutes
        $st = if ($l.Status -eq 'ERROR') { 'FAIL' } elseif ($l.Step -in 'Txn','SqlHealth' -and $age -gt 10) { 'WARN' } else { 'PASS' }
        Add-Result 'Collector' $l.Step $st ("{0} {1} min ago {2}" -f $l.Status, $age, "$($l.Message)")
    }
}
catch { Add-Result 'Listener' $Listener 'FAIL' $_.Exception.Message; $replicas = @() }

# ---------------------------------------------------------------- each node
$mailProfile = if ($c -and $c.MailProfile) { $c.MailProfile } else { 'billingdashboard' }
$lastFull = $null; $lastLog = $null
foreach ($node in ($replicas | ForEach-Object replica_server_name)) {
    try {
        $j = Invoke-Q $node @"
SELECT j.enabled,
       (SELECT COUNT(*) FROM msdb.dbo.sysjobschedules js JOIN msdb.dbo.sysschedules s ON s.schedule_id = js.schedule_id
         WHERE js.job_id = j.job_id AND s.enabled = 1) AS schedules,
       (SELECT TOP (1) CONCAT(h.run_status, '|', msdb.dbo.agent_datetime(h.run_date, h.run_time))
          FROM msdb.dbo.sysjobhistory h WHERE h.job_id = j.job_id AND h.step_id = 0
          ORDER BY h.instance_id DESC) AS last_run,
       (SELECT TOP (1) LEFT(h.message, 300) FROM msdb.dbo.sysjobhistory h
         WHERE h.job_id = j.job_id AND h.step_id = 3 ORDER BY h.instance_id DESC) AS last_export_msg
FROM msdb.dbo.sysjobs j WHERE j.name = N'$JobName';
"@ 'msdb'
        if ($j.Rows.Count -eq 0) { Add-Result 'Job' $node 'FAIL' "'$JobName' not found (run sql\05_agent_job.sql on this node)" }
        else {
            $r = $j.Rows[0]
            $lr = "$($r.last_run)"
            $st = if (-not $r.enabled -or $r.schedules -eq 0) { 'FAIL' } elseif ($lr -like '0|*') { 'WARN' } else { 'PASS' }
            Add-Result 'Job' $node $st ("enabled={0} schedules={1} last run={2}" -f $r.enabled, $r.schedules, $(if ($lr) { $lr -replace '^1\|','succeeded ' -replace '^0\|','FAILED ' } else { 'never' }))
        }

        $p = Invoke-Q $node @"
SELECT (SELECT CONCAT(c.credential_identity, ' (changed ', CONVERT(varchar(16), c.modify_date, 120), ')')
          FROM sys.credentials c WHERE c.name = N'billingdashboard_cred') AS cred,
       (SELECT COUNT(*) FROM msdb.dbo.sysproxies WHERE name = N'billingdashboard_proxy' AND enabled = 1) AS proxy,
       (SELECT COUNT(*) FROM msdb.dbo.sysmail_profile WHERE name = N'$mailProfile') AS mailprofile,
       (SELECT CAST(value_in_use AS int) FROM sys.configurations WHERE name = N'Database Mail XPs') AS mailxps;
"@
        $r = $p.Rows[0]
        Add-Result 'Credential' $node $(if ("$($r.cred)" -and $r.proxy -eq 1) { 'PASS' } else { 'FAIL' }) ("credential: {0}; proxy enabled: {1}. If the service account password was reset after this date, re-run 05 on this node." -f $(if ("$($r.cred)") { $r.cred } else { 'missing' }), ($r.proxy -eq 1))
        Add-Result 'Database Mail' $node $(if ($r.mailprofile -eq 1 -and $r.mailxps -eq 1) { 'PASS' } else { 'WARN' }) ("profile '{0}': {1}; Database Mail XPs: {2}" -f $mailProfile, $(if ($r.mailprofile -eq 1) { 'present' } else { 'missing (sql\08_database_mail.sql)' }), $r.mailxps)

        $b = Invoke-Q $node @"
SELECT MAX(CASE WHEN type = 'D' THEN backup_finish_date END) AS last_full,
       MAX(CASE WHEN type = 'L' THEN backup_finish_date END) AS last_log
FROM msdb.dbo.backupset WHERE database_name = N'billingdashboard';
"@ 'msdb'
        foreach ($x in $b) {
            if ($x.last_full -isnot [DBNull] -and ($null -eq $lastFull -or $x.last_full -gt $lastFull)) { $lastFull = $x.last_full }
            if ($x.last_log  -isnot [DBNull] -and ($null -eq $lastLog  -or $x.last_log  -gt $lastLog))  { $lastLog  = $x.last_log }
        }

        $share = '\\' + $node + '\' + ($ExportScriptLocalPath -replace '^([A-Za-z]):', '$1$')
        try { Add-Result 'Export script' $node $(if (Test-Path -LiteralPath $share) { 'PASS' } else { 'FAIL' }) $share }
        catch { Add-Result 'Export script' $node 'INFO' "could not check $share" }
    }
    catch { Add-Result 'Node' $node 'FAIL' $_.Exception.Message }
}

# ---------------------------------------------------------------- backups + web
if ($replicas) {
    Add-Result 'Backup' 'full' $(if ($lastFull -and $lastFull -gt (Get-Date).AddDays(-8)) { 'PASS' } else { 'FAIL' }) $(if ($lastFull) { "last full $lastFull (any node)" } else { 'no full backup of billingdashboard on any node' })
    Add-Result 'Backup' 'log'  $(if ($lastLog -and $lastLog -gt (Get-Date).AddHours(-2)) { 'PASS' } else { 'FAIL' }) $(if ($lastLog) { "last log $lastLog (any node)" } else { 'no log backup of billingdashboard on any node (full recovery: the log will grow)' })
}
try {
    $f = Get-Item -LiteralPath $DataJson -ErrorAction Stop
    $age = [int]((Get-Date) - $f.LastWriteTime).TotalMinutes
    Add-Result 'Web' 'data.json' $(if ($age -le 5) { 'PASS' } elseif ($age -le 15) { 'WARN' } else { 'FAIL' }) ("written {0} min ago, {1:N0} bytes (proves the service account can write to the share)" -f $age, $f.Length)
}
catch { Add-Result 'Web' 'data.json' 'FAIL' $_.Exception.Message }

$results | Format-Table -AutoSize -Wrap
$bad = @($results | Where-Object Status -in 'FAIL','WARN').Count
Write-Output ("{0} checks, {1} FAIL/WARN" -f $results.Count, $bad)
