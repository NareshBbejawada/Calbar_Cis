/* =====================================================================
   00_discover_columns.sql
   Run FIRST, on the SQL instance that owns the George_PRDT linked server.
   Purpose: find the real column names in the GEORGE billing tables so the
   pass-through queries in mon.Config (01_mon_schema.sql) can be filled in.

   The four-part name [George_PRDT].[George].[PRDT].[BMTRANP] and the
   xxxxP table naming suggest GEORGE is DB2 for IBM i. Section B only works
   if that is true; Section A works for any OLE DB / ODBC provider.
   ===================================================================== */

/* ---- A. Column list via the linked server (any provider) ---------- */
EXEC sp_columns_ex @table_server = N'George_PRDT', @table_catalog = N'George',
                   @table_schema = N'PRDT', @table_name = N'BMTRANP';
EXEC sp_columns_ex @table_server = N'George_PRDT', @table_catalog = N'George',
                   @table_schema = N'PRDT', @table_name = N'BMADPNDP';
EXEC sp_columns_ex @table_server = N'George_PRDT', @table_catalog = N'George',
                   @table_schema = N'PRDT', @table_name = N'BMMASTP';
EXEC sp_columns_ex @table_server = N'George_PRDT', @table_catalog = N'George',
                   @table_schema = N'PRDT', @table_name = N'BMCITMP';

/* ---- B. Column text/descriptions (DB2 for i only) ----------------- */
SELECT *
FROM OPENQUERY(George_PRDT, '
    SELECT TABLE_NAME, ORDINAL_POSITION, COLUMN_NAME, DATA_TYPE,
           LENGTH, NUMERIC_SCALE, COLUMN_TEXT
    FROM   QSYS2.SYSCOLUMNS
    WHERE  TABLE_SCHEMA = ''PRDT''
      AND  TABLE_NAME IN (''BMTRANP'',''BMADPNDP'',''BMMASTP'',''BMCITMP'')
    ORDER BY TABLE_NAME, ORDINAL_POSITION');

/* ---- C. Sample rows (small; OPENQUERY so the filter runs remotely) - */
SELECT * FROM OPENQUERY(George_PRDT, 'SELECT * FROM PRDT.BMTRANP  FETCH FIRST 5 ROWS ONLY');
SELECT * FROM OPENQUERY(George_PRDT, 'SELECT * FROM PRDT.BMADPNDP FETCH FIRST 5 ROWS ONLY');
SELECT * FROM OPENQUERY(George_PRDT, 'SELECT * FROM PRDT.BMMASTP  FETCH FIRST 5 ROWS ONLY');
SELECT * FROM OPENQUERY(George_PRDT, 'SELECT * FROM PRDT.BMCITMP  FETCH FIRST 5 ROWS ONLY');

/* ---- D. Once you know the status / app-source columns, list values -
   Replace <STATUS_COL> / <SOURCE_COL> and run, then seed mon.StatusMap
   and mon.AppMap with the results.                                    */
-- SELECT * FROM OPENQUERY(George_PRDT, '
--     SELECT <STATUS_COL>, <SOURCE_COL>, COUNT(*) AS CNT
--     FROM PRDT.BMTRANP
--     GROUP BY <STATUS_COL>, <SOURCE_COL>');

/* ---- E. Where do the .NET billing jobs log in Billing_V2? --------- */
USE Billing_V2;
SELECT s.name AS schema_name, t.name AS table_name,
       SUM(p.rows) AS row_count,
       MAX(us.last_user_update) AS last_write
FROM sys.tables t
JOIN sys.schemas s ON s.schema_id = t.schema_id
JOIN sys.partitions p ON p.object_id = t.object_id AND p.index_id IN (0,1)
LEFT JOIN sys.dm_db_index_usage_stats us
       ON us.object_id = t.object_id AND us.database_id = DB_ID()
GROUP BY s.name, t.name
ORDER BY last_write DESC;
