/* =====================================================================
   03_mon_dashboard_json.sql  -  mon.usp_GetDashboardJson
   Returns ONE JSON document consumed by billing_dashboard.html.
   Reads only local mon.* tables - never touches the linked server, so
   the dashboard puts no load on GEORGE no matter how many people open it.
   ===================================================================== */
USE Billing_V2;
GO
CREATE OR ALTER FUNCTION mon.fn_Cfg (@key sysname)
RETURNS nvarchar(max)
AS
BEGIN
    RETURN (SELECT ConfigValue FROM mon.Config WHERE ConfigKey = @key);
END;
GO

CREATE OR ALTER PROCEDURE mon.usp_GetDashboardJson
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @now      datetime2(0) = SYSDATETIME();
    DECLARE @today    date         = CAST(@now AS date);
    DECLARE @base     datetime2(0) = '2000-01-01';
    DECLARE @cs       date = TRY_CAST(mon.fn_Cfg(N'CycleStart') AS date);
    DECLARE @ce       date = TRY_CAST(mon.fn_Cfg(N'CycleEnd')   AS date);
    DECLARE @inCycle  bit  = CASE WHEN @today BETWEEN @cs AND @ce THEN 1 ELSE 0 END;
    /* Outside the cycle (e.g. while testing in November) show the last 60 days */
    DECLARE @dStart   date = CASE WHEN @inCycle = 1 THEN @cs ELSE DATEADD(DAY, -59, @today) END;
    DECLARE @h48      datetime2(0) = DATEADD(HOUR, DATEDIFF(HOUR, @base, @now) - 47, @base);
    DECLARE @stuckMin int = ISNULL(TRY_CAST(mon.fn_Cfg(N'StuckPendingMinutes') AS int), 30);

    /* Categorised transactions for the windows we need */
    SELECT p.TranTs, p.AppCode, p.Amount, p.ErrorCode, p.ErrorText,
           Cat = ISNULL(sm.Category, 'Pending')       -- unmapped codes count as pending
    INTO   #tx
    FROM   mon.PaymentTxn p
    LEFT JOIN mon.StatusMap sm ON sm.StatusCode = p.StatusCode
    WHERE  p.TranTs >= CAST(@dStart AS datetime2(0));

    /* Wait-stat deltas: latest snapshot vs the one nearest 60 minutes earlier */
    DECLARE @wNow datetime2(0) = (SELECT MAX(SnapTs) FROM mon.WaitSnapshot);
    DECLARE @wOld datetime2(0) = (SELECT MAX(SnapTs) FROM mon.WaitSnapshot
                                  WHERE SnapTs <= DATEADD(MINUTE, -60, @wNow));
    IF @wOld IS NULL SET @wOld = (SELECT MIN(SnapTs) FROM mon.WaitSnapshot);

    DECLARE @agTs   datetime2(0) = (SELECT MAX(SnapTs) FROM mon.AgSnapshot);
    DECLARE @webTs  datetime2(0) = (SELECT MAX(SnapTs) FROM mon.WebNodeSnapshot);
    DECLARE @lastRun datetime2(0) = (SELECT MAX(RunTs) FROM mon.CollectLog);

    SELECT
      meta = JSON_QUERY((SELECT
                generatedAt  = @now,
                cycleStart   = @cs,
                cycleEnd     = @ce,
                inCycle      = @inCycle,
                windowStart  = @dStart,
                server       = @@SERVERNAME,
                lastCollect  = @lastRun,
                collect      = JSON_QUERY((
                    SELECT step = l.Step, status = l.Status, ts = l.RunTs,
                           durationMs = l.DurationMs, message = l.Message
                    FROM mon.CollectLog l
                    WHERE l.LogId IN (SELECT MAX(LogId) FROM mon.CollectLog GROUP BY Step)
                    FOR JSON PATH))
             FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)),

      thresholds = JSON_QUERY((SELECT
                failRateWarnPct     = TRY_CAST(mon.fn_Cfg(N'FailRateWarnPct')  AS decimal(9,2)),
                failRateCritPct     = TRY_CAST(mon.fn_Cfg(N'FailRateCritPct')  AS decimal(9,2)),
                stuckPendingMinutes = @stuckMin,
                pingWarnMs          = TRY_CAST(mon.fn_Cfg(N'PingWarnMs')       AS int),
                pingCritMs          = TRY_CAST(mon.fn_Cfg(N'PingCritMs')       AS int),
                redoQueueWarnKb     = TRY_CAST(mon.fn_Cfg(N'RedoQueueWarnKb')  AS bigint),
                blockWarnSec        = TRY_CAST(mon.fn_Cfg(N'BlockWarnSec')     AS int)
             FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)),

      apps = JSON_QUERY((SELECT code = AppCode, name = AppName
                         FROM mon.AppMap ORDER BY SortOrder FOR JSON PATH)),

      /* last 48 hours, hourly, per app */
      hourly = JSON_QUERY((
          SELECT h = DATEADD(HOUR, DATEDIFF(HOUR, @base, TranTs), @base),
                 app = ISNULL(AppCode, N'?'),
                 completed = SUM(CASE WHEN Cat = 'Completed' THEN 1 ELSE 0 END),
                 failed    = SUM(CASE WHEN Cat = 'Failed'    THEN 1 ELSE 0 END),
                 pending   = SUM(CASE WHEN Cat = 'Pending'   THEN 1 ELSE 0 END),
                 cancelled = SUM(CASE WHEN Cat = 'Cancelled' THEN 1 ELSE 0 END),
                 amount    = SUM(CASE WHEN Cat = 'Completed' THEN Amount ELSE 0 END)
          FROM #tx WHERE TranTs >= @h48
          GROUP BY DATEADD(HOUR, DATEDIFF(HOUR, @base, TranTs), @base), ISNULL(AppCode, N'?')
          FOR JSON PATH)),

      /* cycle (or last 60 days), daily, per app */
      daily = JSON_QUERY((
          SELECT d = CAST(TranTs AS date),
                 app = ISNULL(AppCode, N'?'),
                 completed = SUM(CASE WHEN Cat = 'Completed' THEN 1 ELSE 0 END),
                 failed    = SUM(CASE WHEN Cat = 'Failed'    THEN 1 ELSE 0 END),
                 amount    = SUM(CASE WHEN Cat = 'Completed' THEN Amount ELSE 0 END)
          FROM #tx
          GROUP BY CAST(TranTs AS date), ISNULL(AppCode, N'?')
          FOR JSON PATH)),

      stuck = JSON_QUERY((
          SELECT app = ISNULL(AppCode, N'?'), [count] = COUNT(*),
                 oldestMinutes = MAX(DATEDIFF(MINUTE, TranTs, @now))
          FROM #tx
          WHERE Cat = 'Pending' AND TranTs < DATEADD(MINUTE, -@stuckMin, @now)
            AND TranTs >= DATEADD(DAY, -3, @now)
          GROUP BY ISNULL(AppCode, N'?')
          FOR JSON PATH)),

      failures = JSON_QUERY((
          SELECT TOP (60) app = ISNULL(AppCode, N'?'),
                 code = ISNULL(ErrorCode, N'(no code)'),
                 [text] = MAX(ErrorText), [count] = COUNT(*),
                 lastSeen = MAX(TranTs)
          FROM #tx
          WHERE Cat = 'Failed' AND TranTs >= DATEADD(HOUR, -24, @now)
          GROUP BY ISNULL(AppCode, N'?'), ISNULL(ErrorCode, N'(no code)')
          ORDER BY COUNT(*) DESC
          FOR JSON PATH)),

      progress = JSON_QUERY((
          SELECT TOP (1) snapTs = SnapTs, membersBilled = MembersBilled, membersPaid = MembersPaid,
                 amountBilled = AmountBilled, amountPaid = AmountPaid
          FROM mon.BillingProgress ORDER BY SnapTs DESC
          FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)),

      webNodes = JSON_QUERY((
          SELECT host = w.HostName, zone = z.Zone, program = w.ProgramName, db = w.DbName,
                 sessions = w.Sessions, active = w.ActiveRequests
          FROM mon.WebNodeSnapshot w
          JOIN mon.ZoneMap z ON z.HostName = w.HostName
          WHERE w.SnapTs = @webTs
          FOR JSON PATH)),

      nodeHourly = JSON_QUERY((
          SELECT h = DATEADD(HOUR, DATEDIFF(HOUR, @base, SnapTs), @base), host = HostName,
                 sessions = AVG(CAST(s AS int))
          FROM (SELECT SnapTs, HostName, s = SUM(Sessions)
                FROM mon.WebNodeSnapshot
                WHERE SnapTs >= DATEADD(HOUR, -24, @now)
                GROUP BY SnapTs, HostName) x
          GROUP BY DATEADD(HOUR, DATEDIFF(HOUR, @base, SnapTs), @base), HostName
          FOR JSON PATH)),

      ping = JSON_QUERY((
          SELECT ts = PingTs, ms = DurationMs, ok = Success, err = ErrorText
          FROM mon.LinkedServerPing
          WHERE PingTs >= DATEADD(HOUR, -6, @now)
          ORDER BY PingTs
          FOR JSON PATH)),

      ag = JSON_QUERY((
          SELECT ag = AgName, replica = ReplicaServer, db = DbName, role = RoleDesc,
                 mode = AvailMode, syncState = SyncState, health = SyncHealth,
                 logSendKb = LogSendQueueKb, redoKb = RedoQueueKb
          FROM mon.AgSnapshot WHERE SnapTs = @agTs
          ORDER BY AgName, RoleDesc DESC, ReplicaServer
          FOR JSON PATH)),

      instance = JSON_QUERY((
          SELECT TOP (1) snapTs = SnapTs, activeRequests = ActiveRequests,
                 blocked = BlockedSessions, longestBlockSec = LongestBlockSec
          FROM mon.InstanceSnapshot ORDER BY SnapTs DESC
          FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)),

      jobs = JSON_QUERY((
          SELECT TOP (1000) source = Source, name = JobName, start = RunStart, [end] = RunEnd,
                 status = Status, [rows] = RowsProcessed, message = Message
          FROM mon.JobRun
          WHERE RunStart >= DATEADD(DAY, -2, @now)
          ORDER BY RunStart DESC
          FOR JSON PATH)),

      waits = JSON_QUERY((
          SELECT TOP (8) wait = n.WaitType, ms = n.WaitMs - ISNULL(o.WaitMs, 0)
          FROM mon.WaitSnapshot n
          LEFT JOIN mon.WaitSnapshot o ON o.SnapTs = @wOld AND o.WaitType = n.WaitType
          WHERE n.SnapTs = @wNow AND @wOld < @wNow
            AND n.WaitMs - ISNULL(o.WaitMs, 0) > 0
          ORDER BY n.WaitMs - ISNULL(o.WaitMs, 0) DESC
          FOR JSON PATH))

    FOR JSON PATH, WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES;
END;
GO

/* Read-only role for the exporter account */
IF DATABASE_PRINCIPAL_ID(N'mon_dashboard_reader') IS NULL
    CREATE ROLE mon_dashboard_reader;
GRANT EXECUTE ON mon.usp_GetDashboardJson TO mon_dashboard_reader;
GO
