/* =====================================================================
   04_agent_job.sql  -  "Billing Cycle Dashboard - Collect"
   Create this job on EVERY replica that can host Billing_V2 (all 4 AG
   nodes). Step 1 quits quietly on secondaries, so only the primary runs.

   Before running, set:
     @ScriptPath  - where Export-BillingDashboard.ps1 lives on each node
     @OutFile     - UNC path to data.json in the INTERNAL web folder
                    that serves billing_dashboard.html
                    (never on the DMZ servers SFWEBPRD11-14)
   The Agent service account (or a CmdExec proxy) needs:
     - a login mapping on linked server George_PRDT
     - write access to @OutFile's folder
   ===================================================================== */
USE msdb;
GO
DECLARE @ScriptPath nvarchar(400) = N'D:\DBA\Scripts\Export-BillingDashboard.ps1';
DECLARE @OutFile    nvarchar(400) = N'\\<INTRANET-WEB-SERVER>\BillingDashboard$\data.json';
DECLARE @JobName    sysname       = N'Billing Cycle Dashboard - Collect';
DECLARE @cmd        nvarchar(2000);
DECLARE @jobId      uniqueidentifier;

IF EXISTS (SELECT 1 FROM msdb.dbo.sysjobs WHERE name = @JobName)
    EXEC msdb.dbo.sp_delete_job @job_name = @JobName, @delete_unused_schedule = 1;

EXEC msdb.dbo.sp_add_job
     @job_name = @JobName, @enabled = 1,
     @description = N'Collects GEORGE payment activity + SQL health into Billing_V2.mon and exports data.json for the billing dashboard.',
     @category_name = N'[Uncategorized (Local)]', @owner_login_name = N'sa',
     @job_id = @jobId OUTPUT;

/* Step 1: run only on the AG primary for Billing_V2 */
EXEC msdb.dbo.sp_add_jobstep
     @job_id = @jobId, @step_name = N'Primary check', @subsystem = N'TSQL',
     @database_name = N'master',
     @command = N'IF ISNULL(sys.fn_hadr_is_primary_replica(N''Billing_V2''), 1) = 0
    THROW 50001, N''Not the primary replica for Billing_V2 - skipping.'', 1;',
     @on_success_action = 3,      -- go to next step
     @on_fail_action    = 1;      -- quit reporting SUCCESS (secondary = normal)

/* Step 2: collect */
EXEC msdb.dbo.sp_add_jobstep
     @job_id = @jobId, @step_name = N'Collect', @subsystem = N'TSQL',
     @database_name = N'Billing_V2',
     @command = N'EXEC mon.usp_Collect;',
     @on_success_action = 3, @on_fail_action = 3;   -- export even if a step had issues

/* Step 3: export JSON for the web page */
SET @cmd = N'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' + @ScriptPath
         + N'" -SqlInstance "SFDBSLISTN01" -Database "Billing_V2" -OutFile "' + @OutFile + N'"';
EXEC msdb.dbo.sp_add_jobstep
     @job_id = @jobId, @step_name = N'Export data.json', @subsystem = N'CmdExec',
     @command = @cmd,
     @on_success_action = 1, @on_fail_action = 2;

EXEC msdb.dbo.sp_add_jobschedule
     @job_id = @jobId, @name = N'Every 2 minutes',
     @freq_type = 4, @freq_interval = 1,
     @freq_subday_type = 4, @freq_subday_interval = 2,
     @active_start_time = 0;

EXEC msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)';
GO

/* Tip: outside the billing window, change the schedule to every 15 minutes:
   EXEC msdb.dbo.sp_update_schedule @name = N'Every 2 minutes', @freq_subday_interval = 15; */
