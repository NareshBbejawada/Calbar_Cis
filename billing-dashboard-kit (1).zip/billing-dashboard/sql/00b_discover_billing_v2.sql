/* =====================================================================
   00b_discover_billing_v2.sql  -  discovery round 2
   Run on SFDBSLISTN01 (Billing_V2), Results to Text, and send back the
   .rpt as before. Everything is read-only; TOP queries are small.
   ===================================================================== */
USE Billing_V2;
SET NOCOUNT ON;

/* ---- 1. Columns of the Online Payment Service tables ---------------- */
SELECT t.name AS table_name, c.column_id, c.name AS column_name,
       ty.name AS data_type, c.max_length, c.is_nullable, c.is_identity
FROM sys.tables t
JOIN sys.columns c ON c.object_id = t.object_id
JOIN sys.types ty ON ty.user_type_id = c.user_type_id
WHERE t.schema_id = SCHEMA_ID(N'dbo')
  AND t.name IN (N'transaction', N'transactionDetail', N'applicationTransactions', N'billingItems',
                 N'transactionStatus', N'transactionReason', N'transactionType', N'application',
                 N'exceptionLog', N'exceptionCategoryLog', N'exceptionCategory',
                 N'as400BMADPNDP', N'paymentEventsReport', N'processedRejectPayments',
                 N'paymentType', N'reportProcess', N'ccReportProcess', N'achReportProcess')
ORDER BY t.name, c.column_id;

/* ---- 2. Indexes on the big tables (is the date filter indexed?) ----- */
SELECT OBJECT_NAME(i.object_id) AS table_name, i.name AS index_name, i.type_desc,
       STUFF((SELECT N', ' + c.name FROM sys.index_columns ic
              JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
              WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.is_included_column = 0
              ORDER BY ic.key_ordinal FOR XML PATH('')), 1, 2, N'') AS key_columns
FROM sys.indexes i
WHERE i.object_id IN (OBJECT_ID(N'dbo.[transaction]'), OBJECT_ID(N'dbo.applicationTransactions'),
                      OBJECT_ID(N'dbo.transactionDetail'), OBJECT_ID(N'dbo.exceptionLog'),
                      OBJECT_ID(N'dbo.as400BMADPNDP'))
  AND i.type > 0
ORDER BY table_name, i.index_id;

/* ---- 3. Lookup tables (small, full content) ------------------------- */
SELECT * FROM dbo.transactionStatus;
SELECT * FROM dbo.transactionType;
SELECT * FROM dbo.transactionReason;
SELECT * FROM dbo.application;
SELECT * FROM dbo.exceptionCategory;
SELECT * FROM dbo.paymentType;

/* ---- 4. Most recent rows (column 1 is assumed to be the clustered
          identity key; if a query is slow, cancel it and tell me) ----- */
SELECT TOP (10) * FROM dbo.[transaction]            ORDER BY 1 DESC;
SELECT TOP (10) * FROM dbo.applicationTransactions  ORDER BY 1 DESC;
SELECT TOP (10) * FROM dbo.transactionDetail        ORDER BY 1 DESC;
SELECT TOP (10) * FROM dbo.exceptionLog             ORDER BY 1 DESC;
SELECT TOP (10) * FROM dbo.exceptionCategoryLog     ORDER BY 1 DESC;
SELECT TOP (5)  * FROM dbo.as400BMADPNDP            ORDER BY 1 DESC;
SELECT TOP (10) * FROM dbo.ccReportProcess          ORDER BY 1 DESC;
SELECT TOP (10) * FROM dbo.achReportProcess         ORDER BY 1 DESC;
SELECT TOP (10) * FROM dbo.reportProcess            ORDER BY 1 DESC;

/* ---- 5. GEORGE: status codes and last year's cycle shape ------------ */
-- BMADPNDP record status / adjustment codes for billing year 2026
SELECT * FROM OPENQUERY(George_PRDT, '
SELECT HPSTATUS, HPADCD, HPPMTMETH, COUNT(*) AS CNT, SUM(HPAMT) AS AMT,
       MIN(HP@ENTRY) AS FIRST_ENTRY, MAX(HP@ENTRY) AS LAST_ENTRY
FROM PRDT.BMADPNDP
WHERE HPBLYR = 2026
GROUP BY HPSTATUS, HPADCD, HPPMTMETH
ORDER BY CNT DESC
FETCH FIRST 60 ROWS ONLY
WITH UR');

-- Web payments per day for billing year 2026 (when does the cycle really start/peak?)
SELECT * FROM OPENQUERY(George_PRDT, '
SELECT HP@ENTRY AS ENTRY_DATE, COUNT(DISTINCT HPWEBREF#) AS WEB_PAYMENTS, SUM(HPAMT) AS AMT
FROM PRDT.BMADPNDP
WHERE HPBLYR = 2026 AND HPADCD LIKE ''P%''
GROUP BY HP@ENTRY
ORDER BY HP@ENTRY
WITH UR');

-- BMMASTP billing status / type distribution for 2026
SELECT * FROM OPENQUERY(George_PRDT, '
SELECT BMBSTS, BMBLTP, COUNT(*) AS CNT, SUM(BM$TBL) AS BILLED, SUM(BM$TPY) AS PAID
FROM PRDT.BMMASTP
WHERE BMBLYR = 2026 AND BMBLPD = 1
GROUP BY BMBSTS, BMBLTP
WITH UR');
