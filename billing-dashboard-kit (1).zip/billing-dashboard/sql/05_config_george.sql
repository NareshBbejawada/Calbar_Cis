/* =====================================================================
   05_config_george.sql
   Fills in the GEORGE (DB2 for i) queries using the real column names
   from the discovery report of 2026-11-13. Run on the primary
   (SFDBSLISTN01) after 01_mon_schema.sql.
   ===================================================================== */
USE Billing_V2;
GO

/* Billing year being monitored (BMMASTP.BMBLYR / BMADPNDP.HPBLYR) */
UPDATE mon.Config SET ConfigValue = N'2027' WHERE ConfigKey = N'BillingYear';

/* ---------------------------------------------------------------------
   Billed vs paid, from BMMASTP (key: BMBLYR, BMBLPD, BMMEM#)
   Balance = billed + penalties + donations + adjustments + payments
   (BM$TAD and BM$TPY are stored negative). In all five sample rows,
   paid accounts net to exactly 0.00, e.g. 520 + 130 - 260 - 390 = 0.
   >>> CONFIRM WITH THE GEORGE TEAM <<< whether other charge columns
   (BM$TOB, BM$TSB, BM$TDB, BM$TLB, BM$TCR, BM$FEA ...) are already
   included in BM$TBL or must be added to the balance.
   --------------------------------------------------------------------- */
UPDATE mon.Config SET ConfigValue = N'SELECT COUNT(*) AS MEMBERS_BILLED,
       SUM(CASE WHEN M.BM$TBL + M.BM$TPB + M.BM$TDC + M.BM$TAD + M.BM$TPY <= 0
                THEN 1 ELSE 0 END)                       AS MEMBERS_PAID,
       SUM(M.BM$TBL + M.BM$TPB + M.BM$TDC)                AS AMOUNT_BILLED,
       SUM(0 - M.BM$TPY)                                  AS AMOUNT_PAID
FROM   PRDT.BMMASTP M
WHERE  M.BMBLYR = {CYCLE_YEAR}
  AND  M.BMBLPD = 1
WITH UR'
WHERE ConfigKey = N'GeorgeProgressQuery';

/* Cheap round trip for the latency panel */
UPDATE mon.Config SET ConfigValue = N'SELECT 1 AS OK FROM SYSIBM.SYSDUMMY1 WITH UR'
WHERE ConfigKey = N'GeorgePingQuery';

/* BMTRANP is the posted ledger (adjustment codes, batch dates), not
   online payment attempts. It has no status or error columns, so it is
   not used as a transaction source. Transactions come from Billing_V2
   (LocalTxnQuery) instead.                                              */
UPDATE mon.Config SET ConfigValue = N'' WHERE ConfigKey = N'GeorgeTxnQuery';
GO

/* Test before relying on it */
SELECT * FROM OPENQUERY(George_PRDT, '
SELECT COUNT(*) AS MEMBERS_BILLED,
       SUM(CASE WHEN M.BM$TBL + M.BM$TPB + M.BM$TDC + M.BM$TAD + M.BM$TPY <= 0 THEN 1 ELSE 0 END) AS MEMBERS_PAID,
       SUM(M.BM$TBL + M.BM$TPB + M.BM$TDC) AS AMOUNT_BILLED,
       SUM(0 - M.BM$TPY) AS AMOUNT_PAID
FROM PRDT.BMMASTP M WHERE M.BMBLYR = 2026 AND M.BMBLPD = 1 WITH UR');
