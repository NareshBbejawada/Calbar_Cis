<#
.SYNOPSIS
    Exports the billing dashboard JSON from Billing_V2 to data.json.

.DESCRIPTION
    Calls mon.usp_GetDashboardJson on the AG listener and writes the result
    next to billing_dashboard.html. Writes to a temp file and swaps it in,
    so the page never reads a half-written file.
    Uses only .NET (System.Data.SqlClient) - no SqlServer module needed.

.EXAMPLE
    .\Export-BillingDashboard.ps1 -SqlInstance SFDBSLISTN01 -Database Billing_V2 `
        -OutFile '\\intranet01\BillingDashboard$\data.json'
#>
[CmdletBinding()]
param(
    [string] $SqlInstance = 'SFDBSLISTN01',
    [string] $Database    = 'Billing_V2',
    [Parameter(Mandatory)] [string] $OutFile,
    [int]    $TimeoutSec  = 60
)

$ErrorActionPreference = 'Stop'

# MultiSubnetFailover: the listener spans DC01 / DC02 subnets
$connStr = "Server=$SqlInstance;Database=$Database;Integrated Security=SSPI;" +
           "MultiSubnetFailover=True;Application Name=BillingDashboardExport;" +
           "ApplicationIntent=ReadWrite;Connect Timeout=15"

$conn = New-Object System.Data.SqlClient.SqlConnection $connStr
try {
    $conn.Open()
    $cmd = $conn.CreateCommand()
    $cmd.CommandText    = 'mon.usp_GetDashboardJson'
    $cmd.CommandType    = [System.Data.CommandType]::StoredProcedure
    $cmd.CommandTimeout = $TimeoutSec

    # FOR JSON output arrives split across rows of ~2 KB - stitch them together
    $sb = New-Object System.Text.StringBuilder
    $rdr = $cmd.ExecuteReader()
    while ($rdr.Read()) { [void]$sb.Append($rdr.GetString(0)) }
    $rdr.Close()

    $json = $sb.ToString()
    if ([string]::IsNullOrWhiteSpace($json)) { throw 'Procedure returned no JSON.' }
    $null = $json | ConvertFrom-Json        # sanity check: must parse

    $tmp = "$OutFile.tmp"
    [System.IO.File]::WriteAllText($tmp, $json, (New-Object System.Text.UTF8Encoding $false))
    Move-Item -LiteralPath $tmp -Destination $OutFile -Force
    Write-Output ("Wrote {0:N0} bytes to {1}" -f $json.Length, $OutFile)
}
catch {
    Write-Error "Billing dashboard export failed: $($_.Exception.Message)"
    exit 1
}
finally {
    $conn.Dispose()
}
