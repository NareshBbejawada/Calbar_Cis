#requires -Version 7.4
[CmdletBinding()]
param([string]$ConfigPath="$PSScriptRoot/settings.json",[switch]$TestSolarWinds,[switch]$TestZendesk,[switch]$TestAI)
. "$PSScriptRoot/lib/Poc.Common.ps1"
$c=Read-PocSettings $ConfigPath;Connect-PocAzure $c
Invoke-PocDb $c 'poc.GetHealth' | Format-Table -AutoSize
Invoke-PocQuery $c 'print PocConnectivity=1' | Format-Table -AutoSize
Write-Host 'SQL and government Log Analytics query succeeded.'
if($TestSolarWinds){
 Invoke-PocSwis $c 'SELECT TOP 30 AlertObjectID, AlertID, EntityCaption, RelatedNodeCaption FROM Orion.AlertObjects ORDER BY AlertObjectID DESC' | Format-Table -AutoSize
 Write-Host 'Review these IDs with the SolarWinds owner. This is only a discovery sample, not a full inventory.'
}
if($TestZendesk){
 if($c.Zendesk.Subdomain -notmatch '^[a-z0-9][a-z0-9-]{0,62}$'){throw 'Invalid Zendesk subdomain.'}
 $cred=Read-PocCredential $c Zendesk
 $r=Invoke-RestMethod -Uri "https://$($c.Zendesk.Subdomain).zendesk.com/api/v2/users/me.json" `
    -Headers @{Authorization="Bearer $($cred.GetNetworkCredential().Password)"} -TimeoutSec 30 -MaximumRedirection 0
 [pscustomobject]@{ZendeskAuthenticatedUserId=$r.user.id;Role=$r.user.role}|Format-Table -AutoSize
 Write-Host 'No Zendesk write was performed.'
}
if($TestAI){
 if(-not $c.AI.Enabled){throw 'Set AI.Enabled=true and configure the approved endpoint before this test.'}
 $e=[pscustomobject]@{EventKey=('A'*64);EpisodeKey='CALBAR-SW-POC|101|1001|999';EventType='triggered';OccurredUtc=[DateTime]::UtcNow;SourceSummary='Synthetic connectivity test: monitored node reported down.'}
 $route=[pscustomobject]@{Asset='POC-ONLY';Condition='node_down';Resource='node';Environment='NonProduction';PolicyAction='Ticket';Priority='P2';OwnerKey='infrastructure_operations'}
 $advice=Get-PocAIAdvice $c $e $route
 if(-not $advice.available){throw "AI test failed: $($advice.error)"}
 $advice|ConvertTo-Json -Depth 10
 Write-Host 'Government AI call and output validation succeeded. No ticket was created.'
}
