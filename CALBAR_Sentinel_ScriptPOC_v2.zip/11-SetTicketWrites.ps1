#requires -Version 7.4
[CmdletBinding(SupportsShouldProcess)]
param([string]$ConfigPath="$PSScriptRoot/settings.json",[Parameter(Mandatory)][bool]$Enabled,[switch]$AcknowledgePocScope)
. "$PSScriptRoot/lib/Poc.Common.ps1"
$c=Read-PocSettings $ConfigPath
if($Enabled -and -not $AcknowledgePocScope){throw 'Enabling writes requires -AcknowledgePocScope after sandbox/routing tests and approval.'}
if(-not $PSCmdlet.ShouldProcess("$($c.Sql.Server)/$($c.Sql.Database)","Set ticket writes to $Enabled")){return}
$cn=New-PocSqlConnection $c
try{
 $cn.Open();$cmd=$cn.CreateCommand();$cmd.CommandText='UPDATE poc.Config SET TicketWritesEnabled=@enabled WHERE ConfigId=1;'
 [void]$cmd.Parameters.AddWithValue('@enabled',$Enabled)
 if($cmd.ExecuteNonQuery() -ne 1){throw 'Expected one configuration row.'}
 Write-Host "TicketWritesEnabled=$Enabled. Creation cap and existing decisions were not reset."
 if(-not $Enabled){Write-Warning 'This cannot cancel an HTTP request already in flight. Also stop the worker/task for an immediate stop.'}
}finally{$cn.Dispose()}
