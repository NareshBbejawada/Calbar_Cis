#requires -Version 7.4
[CmdletBinding(SupportsShouldProcess)]
param([string]$ConfigPath="$PSScriptRoot/settings.json",[Parameter(Mandatory)][bool]$Enabled)
. "$PSScriptRoot/lib/Poc.Common.ps1"
. "$PSScriptRoot/lib/Poc.Deploy.ps1"
$c=Read-PocSettings $ConfigPath;Connect-PocAzure $c -Deployment;$s=Get-PocState $c
if(-not $PSCmdlet.ShouldProcess($s.RuleResourceId,"Set analytics enabled=$Enabled")){return}
$r=Invoke-PocArm GET $s.RuleResourceId $s.RuleApiVersion
$p=$r.properties
foreach($readOnly in @('lastModifiedUtc','createdUtc')){[void]$p.Remove($readOnly)}
$p.enabled=$Enabled
$body=@{kind=$r.kind;properties=$p}
if($r.ContainsKey('etag')){$body.etag=$r.etag}
Invoke-PocArm PUT $s.RuleResourceId $s.RuleApiVersion $body|Out-Null
Write-Host "POC analytics enabled=$Enabled. This does not change SQL ticket-write permission."
