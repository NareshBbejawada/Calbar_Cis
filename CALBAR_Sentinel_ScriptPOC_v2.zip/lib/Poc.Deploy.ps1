# Deployment-only helpers; do not run with the runtime identity.
function Get-PocApiVersion {
 param([string]$Namespace,[string]$Type,[string[]]$Preferred)
 $provider=Get-AzResourceProvider -ProviderNamespace $Namespace -ErrorAction Stop
 $rt=@($provider.ResourceTypes|Where-Object ResourceTypeName -eq $Type)
 if($rt.Count -ne 1){throw "Cannot find $Namespace/$Type in this government subscription."}
 foreach($version in $Preferred){if($rt[0].ApiVersions -contains $version){return $version}}
 throw "None of the tested API versions is advertised for $Namespace/$Type. Review available API versions; do not silently substitute commercial endpoints."
}
function Invoke-PocArm {
 param([ValidateSet('GET','PUT','PATCH')][string]$Method,[string]$Id,[string]$ApiVersion,$Body=$null)
 $p=@{Method=$Method;Path="$Id`?api-version=$ApiVersion";ErrorAction='Stop'}
 if($null -ne $Body){$p.Payload=$Body|ConvertTo-Json -Depth 50 -Compress}
 $r=Invoke-AzRestMethod @p
 if([int]$r.StatusCode -notin 200..299){throw "ARM request failed with HTTP $($r.StatusCode). Review resource deployment errors."}
 if($r.Content){return $r.Content|ConvertFrom-Json -AsHashtable}
}
function Wait-PocResource {
 param([string]$Id,[string]$ApiVersion)
 for($i=0;$i -lt 60;$i++){
  $r=Invoke-PocArm GET $Id $ApiVersion
  $state=$r['properties']['provisioningState']
  if(-not $state -or $state -eq 'Succeeded'){return $r}
  if($state -in @('Failed','Canceled')){throw "Provisioning $Id returned $state."}
  Start-Sleep -Seconds 5
 }
 throw "Provisioning not confirmed for $Id. Check the resource before rerunning."
}
function Grant-PocRole {
 param([string]$ObjectId,[string]$Role,[string]$Scope)
 $existing=@(Get-AzRoleAssignment -ObjectId $ObjectId -RoleDefinitionName $Role -Scope $Scope -ErrorAction Stop |
     Where-Object Scope -eq $Scope)
 if(-not $existing){New-AzRoleAssignment -ObjectId $ObjectId -RoleDefinitionName $Role -Scope $Scope -ErrorAction Stop|Out-Null}
}
