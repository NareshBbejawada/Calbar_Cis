#requires -Version 7.4
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:PocRoot = Split-Path $PSScriptRoot -Parent

function Read-PocSettings {
    param([string]$Path = (Join-Path $script:PocRoot 'settings.json'))
    if (-not (Test-Path -LiteralPath $Path)) { throw 'Create settings.json from settings.example.json first.' }
    $c = Get-Content -Raw -LiteralPath $Path | ConvertFrom-Json -AsHashtable
    if ($c.Worker.Mode -notin @('Shadow','PolicyWithAISummary')) { throw 'Unsupported Worker.Mode.' }
    if ($c.Azure.AuthMode -notin @('Interactive','ManagedIdentity','Certificate')) { throw 'Unsupported Azure.AuthMode.' }
    if ($c.Sql.Database -notmatch '^[A-Za-z][A-Za-z0-9_]{0,63}$' -or $c.Sql.Database -notmatch '(?i)poc') { throw 'Use a simple, dedicated database name containing POC; system/application databases are not permitted.' }
    if ([int]$c.Worker.QueryLookbackHours -notin 1..336) { throw 'QueryLookbackHours must be 1..336.' }
    if ([int]$c.Worker.MaxQueryRows -notin 1..10000) { throw 'MaxQueryRows must be 1..10000.' }
    $c['_Directory'] = Split-Path (Resolve-Path -LiteralPath $Path).Path -Parent
    return $c
}
function Get-PocState {
    param([hashtable]$Config)
    $path = Join-Path $Config._Directory 'state.azure.json'
    if (-not (Test-Path $path)) { throw 'Run 02-DeployAzure.ps1 first; state.azure.json is missing.' }
    return (Get-Content -Raw $path | ConvertFrom-Json -AsHashtable)
}
function Assert-PocGuid { param([string]$Value,[string]$Name)
    $g=[guid]::Empty
    if (-not [guid]::TryParse($Value,[ref]$g) -or $g -eq [guid]::Empty) { throw "Configure $Name with a real GUID." }
}
function Connect-PocAzure {
    param([hashtable]$Config,[switch]$Deployment)
    Import-Module Az.Accounts -ErrorAction Stop
    Assert-PocGuid $Config.Azure.TenantId 'Azure.TenantId'
    Assert-PocGuid $Config.Azure.SubscriptionId 'Azure.SubscriptionId'
    if (-not $Deployment) {
        Disable-AzContextAutosave -Scope Process | Out-Null
        if ($Config.Azure.AuthMode -eq 'ManagedIdentity') {
            $p=@{Environment='AzureUSGovernment';Identity=$true;Subscription=$Config.Azure.SubscriptionId;Scope='Process'}
            if ($Config.Azure.ManagedIdentityClientId) { $p.AccountId=$Config.Azure.ManagedIdentityClientId }
            Connect-AzAccount @p | Out-Null
        } elseif ($Config.Azure.AuthMode -eq 'Certificate') {
            if (-not $Config.Azure.ApplicationId -or -not $Config.Azure.CertificateThumbprint) { throw 'Configure ApplicationId and CertificateThumbprint.' }
            Connect-AzAccount -Environment AzureUSGovernment -ServicePrincipal `
                -ApplicationId $Config.Azure.ApplicationId -CertificateThumbprint $Config.Azure.CertificateThumbprint `
                -Tenant $Config.Azure.TenantId -Subscription $Config.Azure.SubscriptionId -Scope Process | Out-Null
        }
    }
    $ctx=Get-AzContext
    if (-not $ctx -or $ctx.Environment.Name -ne 'AzureUSGovernment' -or
        $ctx.Tenant.Id -ne $Config.Azure.TenantId -or $ctx.Subscription.Id -ne $Config.Azure.SubscriptionId) {
        throw 'Connect to the configured Azure Government tenant/subscription first. Interactive logins are never launched inside the worker.'
    }
}
function Get-PocToken {
    param([string]$Audience)
    $ctx=Get-AzContext
    if (-not $ctx -or $ctx.Environment.Name -ne 'AzureUSGovernment') { throw 'Azure Government context is required.' }
    $token=(Get-AzAccessToken -ResourceUrl $Audience -ErrorAction Stop).Token
    if ($token -is [securestring]) { return [Net.NetworkCredential]::new('', $token).Password }
    return [string]$token
}
function Get-PocSafeError {
    param($ErrorRecord)
    $status='unknown'
    try { $status=[int]$ErrorRecord.Exception.Response.StatusCode } catch { }
    # Avoid returning HTTP bodies, credentials, source data or request headers.
    return "Failure: $($ErrorRecord.Exception.GetType().Name); HTTP=$status. Inspect the protected service logs."
}
function Initialize-PocSqlClient {
    if (-not ('Microsoft.Data.SqlClient.SqlConnection' -as [type])) {
        Import-Module SqlServer -ErrorAction Stop
        if (-not ('Microsoft.Data.SqlClient.SqlConnection' -as [type])) {
            $module=Get-Module SqlServer | Select-Object -First 1
            $dll=Get-ChildItem -Path $module.ModuleBase -Filter Microsoft.Data.SqlClient.dll -Recurse |
                 Where-Object { $_.FullName -notmatch '[\\/]ref[\\/]' } |
                 Sort-Object { $_.FullName.Length } | Select-Object -First 1
            if ($dll) { Add-Type -Path $dll.FullName -ErrorAction Stop }
        }
    }
    if (-not ('Microsoft.Data.SqlClient.SqlConnection' -as [type])) {
        throw 'Install/import the approved current SqlServer PowerShell module (Microsoft.Data.SqlClient is required).'
    }
}
function New-PocSqlConnection {
    param([hashtable]$Config,[string]$Database = '')
    Initialize-PocSqlClient
    $b=[Microsoft.Data.SqlClient.SqlConnectionStringBuilder]::new()
    $b.DataSource=[string]$Config.Sql.Server
    $b.InitialCatalog= $(if ($Database) {$Database} else {$Config.Sql.Database})
    $b.IntegratedSecurity=$true
    $b['Encrypt']='True'
    $b.TrustServerCertificate=$false
    $b.ConnectTimeout=[int]$Config.Sql.ConnectTimeoutSeconds
    $b.ApplicationName='CALBAR-Sentinel-ScriptPOC-v2'
    return [Microsoft.Data.SqlClient.SqlConnection]::new($b.ConnectionString)
}
function Invoke-PocDb {
    param([hashtable]$Config,[string]$Procedure,[hashtable]$Parameters=@{})
    if ($Procedure -notmatch '^poc\.[A-Za-z]+$') { throw 'Only named POC stored procedures are allowed.' }
    $cn=New-PocSqlConnection $Config
    try {
        $cn.Open(); $cmd=$cn.CreateCommand()
        $cmd.CommandType=[System.Data.CommandType]::StoredProcedure
        $cmd.CommandText=$Procedure; $cmd.CommandTimeout=[int]$Config.Sql.CommandTimeoutSeconds
        foreach($key in $Parameters.Keys) {
            $value=$Parameters[$key]; if ($null -eq $value) {$value=[DBNull]::Value}
            [void]$cmd.Parameters.AddWithValue("@$key",$value)
        }
        $r=$cmd.ExecuteReader()
        try {
            do {
                while ($r.Read()) {
                    $row=[ordered]@{}
                    for($i=0;$i -lt $r.FieldCount;$i++) { $row[$r.GetName($i)]=$(if($r.IsDBNull($i)){$null}else{$r.GetValue($i)}) }
                    [pscustomobject]$row
                }
            } while($r.NextResult())
        } finally { $r.Dispose(); $cmd.Dispose() }
    } finally { $cn.Dispose() }
}
function Invoke-PocQuery {
    param([hashtable]$Config,[string]$Query)
    $s=Get-PocState $Config
    $token=Get-PocToken 'https://api.loganalytics.us'
    $uri="https://api.loganalytics.us/v1/workspaces/$($s.WorkspaceCustomerId)/query"
    $response=Invoke-RestMethod -Method Post -Uri $uri -Headers @{Authorization="Bearer $token"} `
       -ContentType 'application/json' -Body (@{query=$Query}|ConvertTo-Json -Compress) `
       -TimeoutSec 90 -MaximumRetryCount 0 -MaximumRedirection 0
    if ($response.PSObject.Properties.Name -contains 'error') { throw 'Log query returned a partial/error response; refusing incomplete processing.' }
    foreach($table in @($response.tables)) {
        foreach($row in @($table.rows)) {
            $result=[ordered]@{}
            for($i=0;$i -lt $table.columns.Count;$i++) { $result[$table.columns[$i].name]=$row[$i] }
            [pscustomobject]$result
        }
    }
}
function Read-PocCredential {
    param([hashtable]$Config,[ValidateSet('SolarWinds','Zendesk')][string]$Name)
    if (-not $IsWindows) { throw 'This POC uses Windows DPAPI credentials. Run on the approved Windows worker.' }
    $path=Join-Path $Config._Directory "secrets/$Name.clixml"
    if (-not (Test-Path $path)) { throw "Initialize the $Name credential under the actual worker Windows account." }
    $credential=Import-Clixml -LiteralPath $path
    if ($credential -isnot [pscredential]) { throw 'Invalid credential file.' }
    return $credential
}
function Invoke-PocSwis {
    param([hashtable]$Config,[string]$Query,[hashtable]$Parameters=@{})
    $uri=[uri]$Config.SolarWinds.QueryUri
    if ($uri.Scheme -ne 'https' -or $uri.AbsolutePath -ne '/SolarWinds/InformationService/v3/Json/Query') {
        throw 'Configure the exact HTTPS SWIS Query endpoint. No write endpoints are allowed.'
    }
    $credential=Read-PocCredential $Config SolarWinds
    $body=@{query=$Query;parameters=$Parameters}|ConvertTo-Json -Depth 10 -Compress
    $r=Invoke-RestMethod -Method Post -Uri $uri -Authentication Basic -Credential $credential `
        -ContentType 'application/json' -Body $body -TimeoutSec 60 -MaximumRetryCount 0 -MaximumRedirection 0
    if ($r.PSObject.Properties.Name -notcontains 'results') { throw 'SWIS did not return a results collection.' }
    return @($r.results)
}
function Get-PocRoute {
    param([hashtable]$Config,$Event)
    $rows=@(Invoke-PocDb $Config 'poc.GetRoute' @{
      SourceInstance=[string]$Event.SourceInstance;AlertRuleId=[string]$Event.AlertRuleId;AlertObjectId=[string]$Event.AlertObjectId})
    if($rows.Count -ne 1) { throw 'Expected exactly one approved route or triage fallback.' }
    return $rows[0]
}
function Assert-PocAIResponse {
    param([string]$Json,[string]$EventKey)
    if ($Json.Length -gt 6000) { throw 'AI response too large.' }
    if (-not (Test-Json -Json $Json -SchemaFile (Join-Path $PSScriptRoot 'AI-response.schema.json') -ErrorAction Stop)) { throw 'Invalid AI response schema.' }
    $r=$Json|ConvertFrom-Json
    if($r.evidence_ids.Count -ne 1 -or $r.evidence_ids[0] -cne $EventKey) { throw 'AI evidence does not match the supplied event.' }
    return $r
}
function Get-PocAIAdvice {
    param([hashtable]$Config,$Event,$Route)
    if (-not $Config.AI.Enabled) { return @{available=$false;error='AI disabled; deterministic policy fallback.'} }
    try {
        $base=[uri]$Config.AI.Endpoint
        if($base.Scheme -ne 'https' -or -not ($base.Host.EndsWith('.openai.azure.us') -or $base.Host.EndsWith('.cognitiveservices.azure.us'))) {
            throw 'Use the approved Azure Government resource endpoint, not a commercial endpoint.'
        }
        if($Config.AI.DeploymentName -notmatch '^[A-Za-z0-9_.-]+$' -or $Config.AI.ApiVersion -notmatch '^\d{4}-\d{2}-\d{2}(-preview)?$') { throw 'Invalid AI deployment/API version.' }
        $evidence=@{EventKey=$Event.EventKey;EpisodeKey=$Event.EpisodeKey;EventType=$Event.EventType;
            Asset=$Route.Asset;Condition=$Route.Condition;Resource=$Route.Resource;Environment=$Route.Environment;
            OccurredUtc=$Event.OccurredUtc;SourceSummary=$Event.SourceSummary;
            ApprovedPolicy=@{Action=$Route.PolicyAction;Priority=$Route.Priority;Owner=$Route.OwnerKey}}
        $body=@{temperature=0;max_tokens=700;response_format=@{type='json_object'};messages=@(
           @{role='system';content=(Get-Content -Raw (Join-Path $PSScriptRoot 'AI-system.txt'))},
           @{role='user';content=($evidence|ConvertTo-Json -Depth 12 -Compress)}
        )}|ConvertTo-Json -Depth 15 -Compress
        $url="$($Config.AI.Endpoint.TrimEnd('/'))/openai/deployments/$($Config.AI.DeploymentName)/chat/completions?api-version=$($Config.AI.ApiVersion)"
        $token=Get-PocToken 'https://cognitiveservices.azure.us'
        $r=Invoke-RestMethod -Method Post -Uri $url -Headers @{Authorization="Bearer $token"} `
          -ContentType 'application/json' -Body $body -TimeoutSec 45 -MaximumRetryCount 0 -MaximumRedirection 0
        if($r.choices.Count -ne 1 -or $r.choices[0].finish_reason -ne 'stop') { throw 'AI refused, filtered, truncated or returned unexpected output.' }
        $advice=Assert-PocAIResponse -Json ([string]$r.choices[0].message.content) -EventKey $Event.EventKey
        return @{available=$true;recommendation=$advice}
    } catch { return @{available=$false;error=(Get-PocSafeError $_)} }
}
function Get-PocFinalAction {
    param([string]$Mode,[string]$EventType,[string]$PolicyAction)
    if($Mode -eq 'Shadow') { return 'record' }
    if($Mode -ne 'PolicyWithAISummary') { throw 'Unsupported mode.' }
    if($EventType -eq 'reset') { return 'update' }
    if($PolicyAction -eq 'Digest') { return 'record' }
    return 'create' # Ticket and Review policies: never let AI silently suppress them.
}
function Send-PocZendesk {
    param([hashtable]$Config,[string]$Action,[string]$Body,[guid]$DecisionId,[long]$TicketId=0)
    if($Config.Zendesk.Subdomain -notmatch '^[a-z0-9][a-z0-9-]{0,62}$' -or $Config.Zendesk.Subdomain -like 'REPLACE*') { throw 'Configure the approved Zendesk subdomain.' }
    $credential=Read-PocCredential $Config Zendesk
    $token=$credential.GetNetworkCredential().Password
    $headers=@{Authorization="Bearer $token"}
    $url="https://$($Config.Zendesk.Subdomain).zendesk.com/api/v2/tickets.json"; $method='Post'
    if($Action -eq 'create') { $headers['Idempotency-Key']=$DecisionId.ToString() }
    elseif($Action -eq 'update' -and $TicketId -gt 0) { $method='Put'; $url="https://$($Config.Zendesk.Subdomain).zendesk.com/api/v2/tickets/$TicketId.json" }
    else { throw 'Invalid Zendesk action.' }
    # Deliberately no retries: ambiguous outcomes are quarantined for review.
    return Invoke-RestMethod -Method $method -Uri $url -Headers $headers -ContentType 'application/json' `
      -Body $Body -TimeoutSec 45 -MaximumRetryCount 0 -MaximumRedirection 0
}
