function Submit-PocPendingEvents {
 param([hashtable]$Config)
 $state=Get-PocState $Config
 $events=@(Invoke-PocDb $Config 'poc.GetPendingEvents' @{BatchSize=[int]$Config.Worker.IngestBatchSize})
 if($events.Count -eq 0){return}
 $records=@(foreach($e in $events){
   $route=Get-PocRoute $Config $e
   [ordered]@{TimeGenerated=[DateTime]::UtcNow.ToString('o');EventKey=$e.EventKey;EpisodeKey=$e.EpisodeKey;
   EventType=$e.EventType;SourceInstance=$e.SourceInstance;AlertRuleId=$e.AlertRuleId;AlertObjectId=$e.AlertObjectId;
   SourceOccurrenceId=$e.SourceOccurrenceId;OccurredUtc=[DateTime]::SpecifyKind($e.OccurredUtc,[DateTimeKind]::Utc).ToString('o');
   ReceivedUtc=[DateTime]::SpecifyKind($e.ReceivedUtc,[DateTimeKind]::Utc).ToString('o');Asset=$route.Asset;
   Condition=$route.Condition;Environment=$route.Environment;Resource=$route.Resource;IsPoc=$true}
 })
 $base=[uri]$state.LogsIngestionEndpoint
 if($base.Scheme -ne 'https' -or -not $base.Host.EndsWith('.monitor.azure.us')){throw 'Unexpected government ingestion endpoint in state.azure.json.'}
 $url="$($state.LogsIngestionEndpoint.TrimEnd('/'))/dataCollectionRules/$($state.DcrImmutableId)/streams/$($state.StreamName)?api-version=2023-01-01"
 try{
  $token=Get-PocToken 'https://monitor.azure.us'
  # InputObject preserves the JSON array even for one record.
  $body=ConvertTo-Json -InputObject $records -Depth 10 -Compress
  $r=Invoke-WebRequest -Method Post -Uri $url -Headers @{Authorization="Bearer $token"} -ContentType 'application/json' `
       -Body $body -TimeoutSec 60 -MaximumRetryCount 0 -MaximumRedirection 0
  if([int]$r.StatusCode -ne 204){throw 'Ingestion did not return HTTP 204.'}
  foreach($e in $events){Invoke-PocDb $Config 'poc.MarkIngestion' @{EventKey=$e.EventKey;Success=$true}|Out-Null}
  Write-Host "Ingestion API accepted $($events.Count) event(s). Verify table arrival separately."
 }catch{
  $safe=Get-PocSafeError $_
  foreach($e in $events){try{Invoke-PocDb $Config 'poc.MarkIngestion' @{EventKey=$e.EventKey;Success=$false;Error=$safe}|Out-Null}catch{}}
  throw # Events remain retryable; duplicate table rows are permitted, tickets are deduplicated.
 }
}
function Invoke-PocDecision {
 param([hashtable]$Config,$Candidate)
 $key=[string]$Candidate.EventKey
 if($key -cnotmatch '^[A-F0-9]{64}$'){throw 'Invalid Sentinel event key.'}
 $rows=@(Invoke-PocDb $Config 'poc.GetInputEvent' @{EventKey=$key})
 if($rows.Count -ne 1){throw 'Sentinel referenced an event not in this POC SQL store. Refusing external action.'}
 $e=$rows[0]
 $claims=@(Invoke-PocDb $Config 'poc.ClaimDecision' @{EpisodeKey=$e.EpisodeKey;EventType=$e.EventType})
 if($claims.Count -ne 1){throw 'Unexpected SQL claim result.'}
 if(-not $claims[0].IsNewClaim){return}
 $id=[guid]$claims[0].DecisionId;$remoteTicketId=[long]0
 try{
   Invoke-PocDb $Config 'poc.AttachSentinelAlert' @{DecisionId=$id;AlertId=[string]$Candidate.SystemAlertId}|Out-Null
   $route=Get-PocRoute $Config $e
   $advice=$(if($e.EventType -eq 'reset'){@{available=$false;error='No model call for a reset transition.'}}else{Get-PocAIAdvice $Config $e $route})
   $action=Get-PocFinalAction $Config.Worker.Mode $e.EventType $route.PolicyAction
   $evidence=@{Event=$e;Route=$route;SentinelAlertId=$Candidate.SystemAlertId;Mode=$Config.Worker.Mode;
       FinalPolicyAction=$action;AIIsAdvisory=$true}|ConvertTo-Json -Depth 15 -Compress
   $adviceJson=$advice|ConvertTo-Json -Depth 12 -Compress
   if($action -eq 'record'){
     Invoke-PocDb $Config 'poc.SaveDecision' @{DecisionId=$id;FinalAction='record';AIResult=$adviceJson;Evidence=$evidence}|Out-Null
     Write-Host "Recorded $($e.EpisodeKey) / $($e.EventType) ($($Config.Worker.Mode)).";return
   }
   if($action -eq 'update'){
     $tickets=@(Invoke-PocDb $Config 'poc.GetEpisodeTicket' @{EpisodeKey=$e.EpisodeKey})
     if($tickets.Count -ne 1 -or [long]$tickets[0].TicketId -le 0){throw 'Reset has no known matching episode ticket. Manual review required.'}
     $ticketId=[long]$tickets[0].TicketId
     $request=@{ticket=@{comment=@{public=$false;body="[POC] SolarWinds reported a reset for EXACT episode $($e.EpisodeKey). This is evidence of a source transition, not verified service recovery. No status or assignment was changed. Decision: $id"}}}
   }else{
     if([long]$route.ZendeskGroupId -le 0 -or [long]$route.MonitoringRequesterId -le 0){throw 'Approved Zendesk group and requester IDs are required.'}
     $ticketId=[long]0
     $priority=@{P1='urgent';P2='high';P3='normal';P4='low'}[[string]$route.Priority]
     $aiText=$(if($advice.available){"AI advisory (unreviewed): $($advice.recommendation.summary)`nAI suggested action: $($advice.recommendation.action); owner: $($advice.recommendation.owner_key)."}else{'AI unavailable/disabled. Approved deterministic policy was used.'})
     $summary="[POC][$($route.Priority)][$($route.Asset)] $($route.Condition)"
     $comment=@"
POC - reported monitoring condition, not an assertion of independently verified impact.
Source: $($e.SourceInstance)
Episode: $($e.EpisodeKey)
Source occurrence UTC: $([DateTime]::SpecifyKind($e.OccurredUtc,[DateTimeKind]::Utc).ToString('o'))
Asset: $($route.Asset)
Condition/resource: $($route.Condition) / $($route.Resource)
Approved owner: $($route.OwnerKey)
SecurityAlert ID: $($Candidate.SystemAlertId)
Integration decision ID: $id
$aiText
A responder must acknowledge and investigate. This POC does not automatically remediate or resolve.
"@
     $request=@{ticket=@{subject=$summary;type='incident';priority=$priority;status='open';
       group_id=[long]$route.ZendeskGroupId;requester_id=[long]$route.MonitoringRequesterId;
       external_id="CBAR-POC-$id";tags=@('calbar_poc','source_solarwinds');comment=@{public=$false;body=$comment}}}
   }
   $frozen=$request|ConvertTo-Json -Depth 12 -Compress
   Invoke-PocDb $Config 'poc.SaveDecision' @{DecisionId=$id;FinalAction=$action;AIResult=$adviceJson;Evidence=$evidence;FrozenRequest=$frozen;TicketId=$(if($ticketId -gt 0){$ticketId}else{$null})}|Out-Null
   $gate=@(Invoke-PocDb $Config 'poc.BeginSend' @{DecisionId=$id})
   if($gate.Count -ne 1 -or -not $gate[0].SendAllowed){
     Invoke-PocDb $Config 'poc.MarkReview' @{DecisionId=$id;Reason='Outbound admission denied: ticket switch off, ticket cap reached, or unexpected decision state. No send occurred.'}|Out-Null
     Write-Warning "Zendesk send blocked for decision $id.";return
   }
   $r=Send-PocZendesk $Config $action ([string]$gate[0].FrozenRequest) $id $ticketId
   $remoteTicketId=[long]$r.ticket.id
   if($remoteTicketId -le 0){throw 'Zendesk response has no valid ticket ID.'}
   Invoke-PocDb $Config 'poc.CompleteSend' @{DecisionId=$id;TicketId=$remoteTicketId}|Out-Null
   Write-Host "Completed $action for Zendesk ticket $remoteTicketId; decision=$id."
 }catch{
   $safe="$(Get-PocSafeError $_) Known returned Zendesk ticket ID=$remoteTicketId. Reconcile decision $id; do not delete its claim or blindly resend."
   try{Invoke-PocDb $Config 'poc.MarkReview' @{DecisionId=$id;Reason=$safe}|Out-Null}catch{Write-Warning 'SQL review marking also failed; inspect pending Claimed/Ready/Attempting rows.'}
   Write-Warning $safe
 }
}
function Invoke-PocSentinelCandidates {
 param([hashtable]$Config)
 $query=Get-Content -Raw (Join-Path $PSScriptRoot '../kql/Candidates.kql')
 $query=$query.Replace('{LOOKBACK}',[string][int]$Config.Worker.QueryLookbackHours).Replace('{LIMIT}',[string][int]$Config.Worker.MaxQueryRows)
 $rows=@(Invoke-PocQuery $Config $query)
 if($rows.Count -ge [int]$Config.Worker.MaxQueryRows){throw 'Candidate query reached its row limit. Split the recovery window and reconcile before continuing; truncation is not accepted.'}
 foreach($r in $rows){Invoke-PocDecision $Config $r}
 Write-Host "Examined $($rows.Count) unique Sentinel candidate(s); existing SQL claims were skipped."
}
