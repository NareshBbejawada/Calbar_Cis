#requires -Version 7.4
[CmdletBinding()]
param([string]$ConfigPath="$PSScriptRoot/settings.json",[switch]$Continuous,[switch]$IngestOnly)
. "$PSScriptRoot/lib/Poc.Common.ps1"
. "$PSScriptRoot/lib/Poc.Worker.ps1"
$c=Read-PocSettings $ConfigPath
if(-not $IsWindows){throw 'Use the approved Windows worker; SQL Windows authentication and DPAPI are required.'}
if([int]$c.Worker.PollSeconds -lt 30){throw 'PollSeconds must be at least 30 for this POC.'}
Connect-PocAzure $c
$lockPath=Join-Path $c._Directory 'worker.lock'
try{$lock=[IO.File]::Open($lockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}
catch{throw 'Another worker holds the lock on this host, or the directory permissions prevent locking.'}
try{
 do{
   # Reload switches between cycles; switching Azure identity requires restarting the worker.
   $c=Read-PocSettings $ConfigPath
   $stages=@()
   if($c.Worker.CollectorEnabled){$stages+='Collector'}
   $stages+='Ingestion'
   if(-not $IngestOnly){$stages+='Sentinel'}
   $failed=$false
   foreach($stage in $stages){
    try{
      switch($stage){
       'Collector' { & "$PSScriptRoot/07-CollectSolarWinds.ps1" -ConfigPath $ConfigPath }
       'Ingestion' { Submit-PocPendingEvents $c }
       'Sentinel' { Invoke-PocSentinelCandidates $c }
      }
      Invoke-PocDb $c 'poc.RecordHealth' @{Stage=$stage;Success=$true}|Out-Null
    }catch{
      $failed=$true;$safe=Get-PocSafeError $_
      try{Invoke-PocDb $c 'poc.RecordHealth' @{Stage=$stage;Success=$false;Error=$safe}|Out-Null}catch{}
      Write-Warning "Stage=$stage. $safe"
    }
   }
   Invoke-PocDb $c 'poc.GetHealth'|Format-Table -AutoSize
   if(-not $Continuous -and $failed){throw 'One or more POC stages failed. Review health and the documented troubleshooting steps.'}
   if($Continuous){Start-Sleep -Seconds ([int]$c.Worker.PollSeconds)}
 }while($Continuous)
}finally{$lock.Dispose()}
