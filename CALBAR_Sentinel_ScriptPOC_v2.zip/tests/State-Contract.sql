/* DBA only, in the NEW POC database. All test changes are rolled back.
   No HTTP call is made; the fake ticket ID is never committed. */
SET NOCOUNT ON; SET XACT_ABORT ON;
BEGIN TRY
 BEGIN TRAN;
 DECLARE @occ varchar(30)=CONVERT(varchar(30),ABS(CONVERT(bigint,CHECKSUM(NEWID()))));
 DECLARE @ep varchar(200)=CONCAT('UNIT-POC|101|1001|',@occ),@id uniqueidentifier,@stamp datetime2(3)=SYSUTCDATETIME();
 EXEC poc.AddInputEvent 'UNIT-POC','101','1001',@occ,'triggered',@stamp,N'Test';
 EXEC poc.AddInputEvent 'UNIT-POC','101','1001',@occ,'triggered',@stamp,N'Test';
 IF (SELECT COUNT(*) FROM poc.InputEvent WHERE EpisodeKey=@ep)<>1 THROW 51501,'Duplicate event storage.',1;
 IF (SELECT Deliveries FROM poc.InputEvent WHERE EpisodeKey=@ep)<>2 THROW 51502,'Delivery count mismatch.',1;
 EXEC poc.ClaimDecision @ep,'triggered';
 EXEC poc.ClaimDecision @ep,'triggered';
 IF (SELECT COUNT(*) FROM poc.Decision WHERE EpisodeKey=@ep)<>1 THROW 51503,'Duplicate claim.',1;
 SELECT @id=DecisionId FROM poc.Decision WHERE EpisodeKey=@ep AND EventType='triggered';
 EXEC poc.SaveDecision @id,'create',NULL,N'{}',N'{"ticket":{"subject":"transaction-only unit test"}}',NULL;
 UPDATE poc.Config SET TicketWritesEnabled=0,CreateAttempts=0,MaxCreateAttempts=1 WHERE ConfigId=1;
 EXEC poc.BeginSend @id;
 IF (SELECT Status FROM poc.Decision WHERE DecisionId=@id)<>'Ready' THROW 51504,'Disabled writes admitted send.',1;
 UPDATE poc.Config SET TicketWritesEnabled=1 WHERE ConfigId=1;
 EXEC poc.BeginSend @id;
 EXEC poc.BeginSend @id;
 IF (SELECT CreateAttempts FROM poc.Config WHERE ConfigId=1)<>1 THROW 51505,'Repeated admission or cap bug.',1;
 EXEC poc.CompleteSend @id,999999999;
 IF (SELECT Status FROM poc.Decision WHERE DecisionId=@id)<>'Complete' THROW 51506,'Completion failed.',1;
 ROLLBACK;
 PRINT 'PASS: SQL duplicate storage, claim, stop switch and send admission. All test rows rolled back; no external calls.';
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK;
 THROW;
END CATCH;
