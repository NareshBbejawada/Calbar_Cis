#requires -Version 7.4
# No cloud, SQL, SolarWinds or Zendesk calls. Run before any deployment.
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$errorsFound=@()
foreach($file in Get-ChildItem $root -Filter *.ps1 -Recurse){
 $tokens=$null;$errors=$null
 [void][Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
 foreach($e in $errors){$errorsFound += "$($file.Name):$($e.Extent.StartLineNumber): $($e.Message)"}
}
if($errorsFound.Count){$errorsFound|Write-Output;throw 'PowerShell parser validation failed.'}
. "$root/lib/Poc.Common.ps1"
function Assert-Equal($Expected,$Actual,$Name){if($Expected -cne $Actual){throw "FAILED $Name expected=$Expected actual=$Actual"}}
Assert-Equal record (Get-PocFinalAction Shadow triggered Ticket) 'shadow'
Assert-Equal create (Get-PocFinalAction PolicyWithAISummary triggered Ticket) 'mandatory ticket'
Assert-Equal create (Get-PocFinalAction PolicyWithAISummary triggered Review) 'unknown triage'
Assert-Equal record (Get-PocFinalAction PolicyWithAISummary triggered Digest) 'informational'
Assert-Equal update (Get-PocFinalAction PolicyWithAISummary reset Ticket) 'reset note'
$key='A'*64
$valid=@{action='ticket';priority='P2';owner_key='infrastructure_operations';summary='Node reportedly unavailable.';reason='Approved ticket rule.';evidence_ids=@($key);requires_review=$false}|ConvertTo-Json
$r=Assert-PocAIResponse $valid $key
Assert-Equal ticket $r.action 'valid advice'
$failed=$false;try{Assert-PocAIResponse $valid ('B'*64)|Out-Null}catch{$failed=$true}
if(-not $failed){throw 'Mismatched AI evidence was accepted.'}
$obj=$valid|ConvertFrom-Json -AsHashtable;$obj.owner_key='made_up_admins'
$failed=$false;try{Assert-PocAIResponse ($obj|ConvertTo-Json) $key|Out-Null}catch{$failed=$true}
if(-not $failed){throw 'Unknown AI owner was accepted.'}
$obj=$valid|ConvertFrom-Json -AsHashtable;$obj['execute_command']='do-something'
$failed=$false;try{Assert-PocAIResponse ($obj|ConvertTo-Json) $key|Out-Null}catch{$failed=$true}
if(-not $failed){throw 'Unexpected AI action field was accepted.'}
$validConfig=Read-PocSettings "$root/settings.example.json"
Assert-Equal Shadow $validConfig.Worker.Mode 'default safe mode'
Write-Host 'PASS: PowerShell parsing and offline policy/AI validation cases. This does NOT validate Azure, SQL, SWIS, AI or Zendesk connectivity.'
