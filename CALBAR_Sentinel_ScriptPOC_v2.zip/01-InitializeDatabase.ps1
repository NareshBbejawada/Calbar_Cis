#requires -Version 7.4
[CmdletBinding(SupportsShouldProcess)]
param([string]$ConfigPath="$PSScriptRoot/settings.json",[switch]$CreateDatabase)
. "$PSScriptRoot/lib/Poc.Common.ps1"
$c=Read-PocSettings $ConfigPath
if(-not $IsWindows){throw 'This script uses Windows integrated SQL authentication.'}
if($CreateDatabase -and $PSCmdlet.ShouldProcess("$($c.Sql.Server)/$($c.Sql.Database)",'Create new POC database if absent')){
 $cn=New-PocSqlConnection $c master
 try{
  $cn.Open();$cmd=$cn.CreateCommand();$cmd.CommandTimeout=120
  $cmd.CommandText="IF DB_ID(@name) IS NULL CREATE DATABASE [$($c.Sql.Database)];"
  [void]$cmd.Parameters.AddWithValue('@name',$c.Sql.Database)
  [void]$cmd.ExecuteNonQuery()
 }finally{$cn.Dispose()}
}
if(-not $PSCmdlet.ShouldProcess("$($c.Sql.Server)/$($c.Sql.Database)",'Install POC tables and procedures; refuses existing poc schema')){return}
$cn=New-PocSqlConnection $c
try{
 $cn.Open();$cmd=$cn.CreateCommand();$cmd.CommandTimeout=120
 $cmd.CommandText="SELECT COUNT(*) FROM sys.objects WHERE is_ms_shipped=0 AND type IN ('U','P','V','FN','IF','TF','TR')"
 if([int]$cmd.ExecuteScalar() -gt 0){throw 'The database already contains user objects. Refusing installation; use an empty dedicated POC database.'}
 foreach($file in @('sql/01-State.sql','sql/02-Collector.sql')){
   $text=Get-Content -Raw (Join-Path $PSScriptRoot $file)
   foreach($batch in [regex]::Split($text,'(?im)^\s*GO\s*(?:--[^\r\n]*)?\r?$')){
     if(-not [string]::IsNullOrWhiteSpace($batch)){$cmd.CommandText=$batch;[void]$cmd.ExecuteNonQuery()}
   }
 }
 Write-Host 'Database objects installed. Configure Zendesk IDs using sql/03-Configure.sql. Ticket writes remain OFF.'
}finally{$cn.Dispose()}
