#requires -Version 7.4
[CmdletBinding()]
param([switch]$Install)
$ErrorActionPreference='Stop'
$modules=@('Az.Accounts','Az.Resources','SqlServer')
if(-not $IsWindows){throw 'Use PowerShell 7.4 or later on an approved Windows management host.'}
foreach($name in $modules){
 $found=Get-Module -ListAvailable -Name $name | Sort-Object Version -Descending | Select-Object -First 1
 if(-not $found -and $Install){
   Install-Module -Name $name -Scope CurrentUser -Repository PSGallery -ErrorAction Stop
   $found=Get-Module -ListAvailable -Name $name | Sort-Object Version -Descending | Select-Object -First 1
 }
 if(-not $found){throw "Missing $name. Install from your approved repository, or rerun with -Install after approval."}
 [pscustomobject]@{Module=$name;Version=$found.Version.ToString();Path=$found.ModuleBase}
}
# This does not change execution policy, trust a new repository or install PowerShell itself.
