#requires -Version 7.4
[CmdletBinding()]
param([string]$ConfigPath="$PSScriptRoot/settings.json",[switch]$InitializeFromNow)
. "$PSScriptRoot/lib/Poc.Common.ps1"
$c=Read-PocSettings $ConfigPath
$pairs=@($c.SolarWinds.PilotPairs)
if($pairs.Count -lt 1 -or $pairs.Count -gt 6){throw 'Configure one to six explicit SolarWinds.PilotPairs. No estate-wide collection is allowed.'}
if($c.SolarWinds.SourceInstance -notmatch '^[A-Za-z0-9_.-]{1,60}$'){throw 'Invalid SolarWinds SourceInstance.'}
$pageSize=[int]$c.SolarWinds.PageSize
if($pageSize -notin 1..500){throw 'SolarWinds.PageSize must be 1..500.'}
$maxPages=[int]$c.SolarWinds.MaxPagesPerPairPerRun
if($maxPages -notin 1..20){throw 'MaxPagesPerPairPerRun must be 1..20.'}
foreach($pair in $pairs){
 if([string]$pair.RuleId -notmatch '^\d{1,10}$' -or [string]$pair.ObjectId -notmatch '^\d{1,10}$'){throw 'Pilot rule/object IDs must be numeric.'}
 $params=@{RuleId=[long]$pair.RuleId;ObjectId=[long]$pair.ObjectId}
 $identity=@{SourceInstance=$c.SolarWinds.SourceInstance;AlertRuleId=[string]$pair.RuleId;AlertObjectId=[string]$pair.ObjectId}
 $maxQuery=@'
SELECT MAX(h.AlertHistoryID) AS MaxId
FROM Orion.AlertHistory h
JOIN Orion.AlertObjects o ON o.AlertObjectID=h.AlertObjectID
WHERE o.AlertID=@RuleId AND h.AlertObjectID=@ObjectId
'@
 $maxRows=@(Invoke-PocSwis $c $maxQuery $params)
 if($maxRows.Count -ne 1){throw 'Unexpected SWIS maximum-history response.'}
 $high=$(if($null -eq $maxRows[0].MaxId){[long]0}else{[long]$maxRows[0].MaxId})
 $check=@(Invoke-PocDb $c 'poc.GetCheckpoint' $identity)
 if($InitializeFromNow){
   if($check.Count -gt 0){throw 'Checkpoint already exists. Refusing to rebaseline and skip uncollected history.'}
   $set=$identity.Clone();$set.HistoryId=$high;Invoke-PocDb $c 'poc.SetCheckpoint' $set|Out-Null
   Write-Host "Initialized rule=$($pair.RuleId), object=$($pair.ObjectId) at history=$high. Older occurrences were NOT imported."
   continue
 }
 if($check.Count -ne 1){throw 'Initialize each new pilot pair explicitly with -InitializeFromNow before collecting.'}
 $after=[long]$check[0].LastHistoryId
 if($high -lt $after){throw 'Source history high-water mark decreased. Possible restore/purge; reconcile manually. No checkpoint rewind performed.'}
 $pages=0
 while($after -lt $high -and $pages -lt $maxPages){
   $pages++
   $query=@"
SELECT TOP $pageSize h.AlertHistoryID, h.AlertActiveID, h.AlertObjectID,
       h.EventType, h.TimeStamp, o.AlertID
FROM Orion.AlertHistory h
JOIN Orion.AlertObjects o ON o.AlertObjectID=h.AlertObjectID
WHERE o.AlertID=@RuleId AND h.AlertObjectID=@ObjectId
  AND h.AlertHistoryID>@AfterId AND h.AlertHistoryID<=@HighId
  AND h.EventType IN (0,1)
ORDER BY h.AlertHistoryID
"@
   $p=$params.Clone();$p.AfterId=$after;$p.HighId=$high
   $rows=@(Invoke-PocSwis $c $query $p)
   if($rows.Count -eq 0){
      $set=$identity.Clone();$set.HistoryId=$high;Invoke-PocDb $c 'poc.SetCheckpoint' $set|Out-Null
      $after=$high;break
   }
   foreach($row in $rows){
     $history=[long]$row.AlertHistoryID
     if($history -le $after -or $history -gt $high){throw 'SWIS returned history outside the requested ordered bounds.'}
     $eventType=$(if([int]$row.EventType -eq 0){'triggered'}elseif([int]$row.EventType -eq 1){'reset'}else{throw 'Unexpected history type.'})
     $valid=$null -ne $row.AlertActiveID -and [long]$row.AlertActiveID -gt 0
     $occurred=$null
     try{
       $occurred=[DateTimeOffset]::Parse([string]$row.TimeStamp,[Globalization.CultureInfo]::InvariantCulture,
          ([Globalization.DateTimeStyles]::AssumeUniversal -bor [Globalization.DateTimeStyles]::AdjustToUniversal)).UtcDateTime
     }catch{$valid=$false}
     if(-not $valid){
       Invoke-PocDb $c 'poc.RecordCollectionIssue' @{SourceInstance=$c.SolarWinds.SourceInstance;HistoryId=$history;Reason='Missing/invalid native occurrence ID or UTC timestamp; manual review required.'}|Out-Null
     }else{
       $add=$identity.Clone();$add.SourceOccurrenceId=[string]$row.AlertActiveID;$add.EventType=$eventType
       $add.OccurredUtc=$occurred;$add.SourceSummary='SolarWinds history transition. Condition and ownership come from the approved routing table.'
       Invoke-PocDb $c 'poc.AddInputEvent' $add|Out-Null
     }
     # Only advance AFTER durable event storage or durable exception recording.
     $set=$identity.Clone();$set.HistoryId=$history;Invoke-PocDb $c 'poc.SetCheckpoint' $set|Out-Null
     $after=$history
   }
 }
 if($after -lt $high){Write-Warning "Collector page limit reached for rule=$($pair.RuleId), object=$($pair.ObjectId). Remaining history is deferred, not skipped."}
}
Invoke-PocDb $c 'poc.RecordHealth' @{Stage='SolarWindsCollector';Success=$true}|Out-Null
