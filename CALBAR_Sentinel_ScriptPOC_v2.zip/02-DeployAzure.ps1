#requires -Version 7.4
[CmdletBinding(SupportsShouldProcess)]
param([string]$ConfigPath="$PSScriptRoot/settings.json",[switch]$ApproveMeteredResources,[switch]$ApproveAuthenticatedPublicIngestion)
. "$PSScriptRoot/lib/Poc.Common.ps1"
. "$PSScriptRoot/lib/Poc.Deploy.ps1"
$c=Read-PocSettings $ConfigPath
if(-not $ApproveMeteredResources -or -not $ApproveAuthenticatedPublicIngestion){
 throw 'This script creates paid resources and authenticated public Azure Monitor endpoints. Both approval switches are required. Private-only tenants must obtain an approved AMPLS/private-link deployment instead; do not weaken policy.'
}
Connect-PocAzure $c -Deployment
Import-Module Az.Resources -ErrorAction Stop
Assert-PocGuid $c.Azure.RuntimePrincipalObjectId 'Azure.RuntimePrincipalObjectId'
if($c.Azure.ResourceGroup -notmatch '(?i)poc'){throw 'Use a dedicated resource group with poc in its name.'}
foreach($n in @($c.Azure.WorkspaceName,$c.Azure.DceName,$c.Azure.DcrName)){
 if($n -notmatch '^[A-Za-z][A-Za-z0-9-]{3,60}$'){throw "Invalid resource name: $n"}
}
if(-not $PSCmdlet.ShouldProcess($c.Azure.ResourceGroup,'Create isolated Azure Government Sentinel POC resources')){return}
$project='CALBAR-AlertOps-ScriptPOC-v2'
$rg=Get-AzResourceGroup -Name $c.Azure.ResourceGroup -ErrorAction SilentlyContinue
if($rg -and $rg.Tags.Project -ne $project){throw 'Existing resource group is not tagged for this kit. Refusing to change it.'}
if(-not $rg){New-AzResourceGroup -Name $c.Azure.ResourceGroup -Location $c.Azure.Location -Tag @{Project=$project}|Out-Null}
foreach($ns in @('Microsoft.OperationalInsights','Microsoft.Insights','Microsoft.SecurityInsights')){
 $p=Get-AzResourceProvider -ProviderNamespace $ns
 if($p.RegistrationState -ne 'Registered'){Register-AzResourceProvider -ProviderNamespace $ns|Out-Null}
}
$wv=Get-PocApiVersion Microsoft.OperationalInsights workspaces @('2022-10-01','2023-09-01')
$tv=Get-PocApiVersion Microsoft.OperationalInsights workspaces/tables @('2022-10-01','2023-09-01')
$ev=Get-PocApiVersion Microsoft.Insights dataCollectionEndpoints @('2022-06-01','2023-03-11')
$dv=Get-PocApiVersion Microsoft.Insights dataCollectionRules @('2022-06-01','2023-03-11')
$ov=Get-PocApiVersion Microsoft.SecurityInsights onboardingStates @('2024-03-01','2023-11-01','2023-02-01','2022-11-01')
$rv=Get-PocApiVersion Microsoft.SecurityInsights alertRules @('2024-03-01','2023-11-01','2023-02-01','2022-11-01')
$root="/subscriptions/$($c.Azure.SubscriptionId)/resourceGroups/$($c.Azure.ResourceGroup)"
$ws="$root/providers/Microsoft.OperationalInsights/workspaces/$($c.Azure.WorkspaceName)"
$dce="$root/providers/Microsoft.Insights/dataCollectionEndpoints/$($c.Azure.DceName)"
$dcr="$root/providers/Microsoft.Insights/dataCollectionRules/$($c.Azure.DcrName)"
$table='CALBARMonitoringEvents_CL';$stream="Custom-$table"
$columns=@(
 @{name='TimeGenerated';type='datetime'},@{name='EventKey';type='string'},@{name='EpisodeKey';type='string'},
 @{name='EventType';type='string'},@{name='SourceInstance';type='string'},@{name='AlertRuleId';type='string'},
 @{name='AlertObjectId';type='string'},@{name='SourceOccurrenceId';type='string'},@{name='OccurredUtc';type='datetime'},
 @{name='ReceivedUtc';type='datetime'},@{name='Asset';type='string'},@{name='Condition';type='string'},
 @{name='Environment';type='string'},@{name='Resource';type='string'},@{name='IsPoc';type='boolean'}
)
# Only a dedicated, kit-tagged resource group is touched. Existing names must be kit-owned too.
foreach($id in @($ws,$dce,$dcr)){
 $resource=Get-AzResource -ResourceId $id -ErrorAction SilentlyContinue
 if($resource -and $resource.Tags.Project -ne $project){throw "Resource is not owned by this POC: $id"}
}
Invoke-PocArm PUT $ws $wv @{location=$c.Azure.Location;tags=@{Project=$project};properties=@{
 sku=@{name='PerGB2018'};retentionInDays=30;publicNetworkAccessForIngestion='Enabled';publicNetworkAccessForQuery='Enabled'}}|Out-Null
$workspace=Wait-PocResource $ws $wv
Invoke-PocArm PUT "$ws/tables/$table" $tv @{properties=@{schema=@{name=$table;columns=$columns};plan='Analytics';retentionInDays=30}}|Out-Null
Wait-PocResource "$ws/tables/$table" $tv|Out-Null
Invoke-PocArm PUT $dce $ev @{location=$c.Azure.Location;tags=@{Project=$project};properties=@{networkAcls=@{publicNetworkAccess='Enabled'}}}|Out-Null
$endpoint=Wait-PocResource $dce $ev
$streams=@{};$streams[$stream]=@{columns=$columns}
Invoke-PocArm PUT $dcr $dv @{location=$c.Azure.Location;tags=@{Project=$project};properties=@{
 dataCollectionEndpointId=$dce;streamDeclarations=$streams;
 destinations=@{logAnalytics=@(@{name='poc-workspace';workspaceResourceId=$ws})};
 dataFlows=@(@{streams=@($stream);destinations=@('poc-workspace');transformKql='source';outputStream=$stream})}}|Out-Null
$rule=Wait-PocResource $dcr $dv
Invoke-PocArm PUT "$ws/providers/Microsoft.SecurityInsights/onboardingStates/default" $ov @{properties=@{customerManagedKey=$false}}|Out-Null
$ruleId='271d6d42-7b65-4f0b-b9c5-9fed174acb1f'
$ruleArmId="$ws/providers/Microsoft.SecurityInsights/alertRules/$ruleId"
$analytics=@{kind='Scheduled';properties=@{
 displayName='CALBAR-ScriptPOC-SolarWinds-Candidates';description='Isolated infrastructure POC. No security tactic classification. SQL enforces ticket idempotency.';
 severity='Low';enabled=$false;tactics=@();techniques=@();query=(Get-Content -Raw "$PSScriptRoot/kql/Analytics.kql");
 queryFrequency='PT5M';queryPeriod='PT30M';triggerOperator='GreaterThan';triggerThreshold=0;suppressionDuration='PT1H';suppressionEnabled=$false;
 eventGroupingSettings=@{aggregationKind='AlertPerResult'};
 customDetails=@{EventKey='EventKey';EpisodeKey='EpisodeKey';EventType='EventType';SourceInstance='SourceInstance'};
 alertDetailsOverride=@{alertDisplayNameFormat='CBAR-POC-v2|{{EventKey}}';alertDescriptionFormat='POC {{EventType}} condition {{Condition}} on {{Asset}}'};
 incidentConfiguration=@{createIncident=$true;groupingConfiguration=@{enabled=$true;reopenClosedIncident=$false;lookbackDuration='PT24H';matchingMethod='Selected';groupByEntities=@();groupByAlertDetails=@();groupByCustomDetails=@('EpisodeKey')}}
}}
Invoke-PocArm PUT $ruleArmId $rv $analytics|Out-Null
Grant-PocRole $c.Azure.RuntimePrincipalObjectId 'Monitoring Metrics Publisher' $dcr
Grant-PocRole $c.Azure.RuntimePrincipalObjectId 'Log Analytics Reader' $ws
$state=@{Project=$project;WorkspaceResourceId=$ws;WorkspaceCustomerId=$workspace.properties.customerId;
 DceResourceId=$dce;DcrResourceId=$dcr;LogsIngestionEndpoint=$endpoint.properties.logsIngestion.endpoint;
 DcrImmutableId=$rule.properties.immutableId;StreamName=$stream;RuleResourceId=$ruleArmId;RuleApiVersion=$rv;
 DeployedUtc=[DateTime]::UtcNow.ToString('o')}
$state|ConvertTo-Json -Depth 10|Set-Content -Encoding utf8 (Join-Path $c._Directory 'state.azure.json')
Write-Host 'Foundation created. Analytics rule is DISABLED. Review paid resources, then run the test steps before enabling it.'
Write-Warning 'Rerunning this foundation script sets the POC rule back to disabled. It does not delete or reset SQL decisions.'
