#requires -Version 7.4
param([string]$ConfigPath="$PSScriptRoot/settings.json",[switch]$IncludeSentinel)
. "$PSScriptRoot/lib/Poc.Common.ps1"
$c=Read-PocSettings $ConfigPath
Invoke-PocDb $c 'poc.GetHealth'|Format-Table -AutoSize
if($IncludeSentinel){
 Connect-PocAzure $c
 Invoke-PocQuery $c "CALBARMonitoringEvents_CL | where TimeGenerated > ago(24h) | summarize Rows=count(), UniqueTransitions=dcount(EventKey), LastArrival=max(TimeGenerated)"|Format-Table -AutoSize
}
