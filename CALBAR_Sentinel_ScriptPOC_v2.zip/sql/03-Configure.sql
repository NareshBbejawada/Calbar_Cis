/* DBA: edit these NULLs to actual verified numeric IDs, then execute. */
SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE @TriageGroupId bigint=NULL, @RequesterId bigint=NULL,
        @InfrastructureGroupId bigint=NULL, @DatabaseGroupId bigint=NULL;
IF @TriageGroupId IS NULL OR @RequesterId IS NULL OR @InfrastructureGroupId IS NULL OR @DatabaseGroupId IS NULL
 THROW 51200,'Replace all four NULL values with approved Zendesk IDs before executing.',1;
BEGIN TRAN;
UPDATE poc.Config SET TriageGroupId=@TriageGroupId,MonitoringRequesterId=@RequesterId,TicketWritesEnabled=0
WHERE ConfigId=1;
UPDATE poc.Route SET ZendeskGroupId=CASE OwnerKey
 WHEN 'infrastructure_operations' THEN @InfrastructureGroupId
 WHEN 'database_operations' THEN @DatabaseGroupId ELSE @TriageGroupId END;
COMMIT;
SELECT * FROM poc.Config;
SELECT * FROM poc.Route;
/* Real pilot example: replace IDs/asset/condition; do not run unchanged.
INSERT poc.Route(SourceInstance,AlertRuleId,AlertObjectId,Asset,Environment,Condition,Resource,PolicyAction,Priority,OwnerKey,ZendeskGroupId)
VALUES('CALBAR-SW-PILOT','ACTUAL_RULE','ACTUAL_OBJECT',N'ACTUAL_TEST_SERVER','NonProduction',
'node_down',N'node','Ticket','P2','infrastructure_operations',@InfrastructureGroupId);
*/
