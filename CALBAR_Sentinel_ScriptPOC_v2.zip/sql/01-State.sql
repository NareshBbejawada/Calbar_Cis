/*
CALBAR Sentinel POC state -- run in a NEW, approved, empty POC database.
Targets SQL Server 2016+ / Azure SQL. Does not create a database or login.
No production readiness claim: failed/uncertain sends require MANUAL reconciliation.
No automatic reclaims, no automatic retries, no full-source reconciliation.
Run DDL as DBA. Give runtime identity EXECUTE only on required procedures.
Sample Zendesk IDs are NULL intentionally; configure them before enabling writes.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
IF SCHEMA_ID(N'poc') IS NULL EXEC(N'CREATE SCHEMA poc AUTHORIZATION dbo;');
GO
IF OBJECT_ID(N'poc.Config',N'U') IS NOT NULL
    THROW 51000, 'POC objects already exist. Review before rerunning this first-install script.', 1;
GO
CREATE TABLE poc.Config (
    ConfigId tinyint NOT NULL CONSTRAINT PK_PocConfig PRIMARY KEY CHECK (ConfigId=1),
    TicketWritesEnabled bit NOT NULL DEFAULT 0,
    MaxCreateAttempts int NOT NULL DEFAULT 25 CHECK(MaxCreateAttempts BETWEEN 1 AND 100),
    CreateAttempts int NOT NULL DEFAULT 0,
    TriageGroupId bigint NULL,
    MonitoringRequesterId bigint NULL
);
INSERT poc.Config(ConfigId) VALUES(1);
CREATE TABLE poc.Route (
    SourceInstance varchar(60) NOT NULL,
    AlertRuleId varchar(20) NOT NULL,
    AlertObjectId varchar(20) NOT NULL,
    Asset nvarchar(128) NOT NULL,
    Environment varchar(20) NOT NULL,
    Condition varchar(80) NOT NULL,
    Resource nvarchar(128) NOT NULL,
    PolicyAction varchar(12) NOT NULL CHECK(PolicyAction IN ('Ticket','Digest','Review')),
    Priority varchar(2) NOT NULL CHECK(Priority IN ('P1','P2','P3','P4')),
    OwnerKey varchar(40) NOT NULL,
    ZendeskGroupId bigint NULL,
    CONSTRAINT PK_PocRoute PRIMARY KEY(SourceInstance,AlertRuleId,AlertObjectId)
);
INSERT poc.Route(SourceInstance,AlertRuleId,AlertObjectId,Asset,Environment,Condition,Resource,PolicyAction,Priority,OwnerKey)
VALUES
('CALBAR-SW-POC','101','1001',N'POC-SQL01','NonProduction','node_down',N'node','Ticket','P2','infrastructure_operations'),
('CALBAR-SW-POC','102','1002',N'POC-SQL01','NonProduction','disk_free_low',N'E:','Ticket','P3','database_operations'),
('CALBAR-SW-POC','103','1003',N'POC-SQL01','NonProduction','routine_success',N'test','Digest','P4','monitoring_triage');
CREATE TABLE poc.Decision (
    EpisodeKey varchar(200) NOT NULL,
    EventType varchar(12) NOT NULL CHECK(EventType IN ('triggered','reset')),
    DecisionId uniqueidentifier NOT NULL DEFAULT NEWID(),
    SentinelIncidentArmId nvarchar(1000) NULL,
    CreatedUtc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
    UpdatedUtc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
    Status varchar(16) NOT NULL CHECK(Status IN ('Claimed','Recorded','Ready','Attempting','Complete','NeedsReview')),
    FinalAction varchar(12) NULL CHECK(FinalAction IN ('create','update','record')),
    AIResult nvarchar(max) NULL CHECK(AIResult IS NULL OR ISJSON(AIResult)=1),
    Evidence nvarchar(max) NULL CHECK(Evidence IS NULL OR ISJSON(Evidence)=1),
    FrozenRequest nvarchar(max) NULL CHECK(FrozenRequest IS NULL OR ISJSON(FrozenRequest)=1),
    TicketId bigint NULL,
    FirstAttemptUtc datetime2(3) NULL,
    ReviewReason nvarchar(2000) NULL,
    CONSTRAINT PK_PocDecision PRIMARY KEY(EpisodeKey,EventType),
    CONSTRAINT UQ_PocDecisionId UNIQUE(DecisionId)
);
GO
CREATE PROCEDURE poc.GetRoute
 @SourceInstance varchar(60), @AlertRuleId varchar(20), @AlertObjectId varchar(20)
AS
BEGIN
 SET NOCOUNT ON;
 SELECT r.Asset,r.Environment,r.Condition,r.Resource,r.PolicyAction,r.Priority,r.OwnerKey,
        COALESCE(r.ZendeskGroupId,c.TriageGroupId) AS ZendeskGroupId,
        c.MonitoringRequesterId,c.TicketWritesEnabled
 FROM poc.Config c JOIN poc.Route r ON r.SourceInstance=@SourceInstance
 AND r.AlertRuleId=@AlertRuleId AND r.AlertObjectId=@AlertObjectId
 WHERE c.ConfigId=1;
 IF @@ROWCOUNT=0
 SELECT N'UNMAPPED' AS Asset,'Unknown' AS Environment,'unmapped_condition' AS Condition,
        N'unknown' AS Resource,'Review' AS PolicyAction,'P2' AS Priority,
        'monitoring_triage' AS OwnerKey,TriageGroupId AS ZendeskGroupId,
        MonitoringRequesterId,TicketWritesEnabled
 FROM poc.Config WHERE ConfigId=1;
END;
GO
CREATE PROCEDURE poc.ClaimDecision
 @EpisodeKey varchar(200), @EventType varchar(12), @SentinelIncidentArmId nvarchar(1000)=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 IF NULLIF(@EpisodeKey,'') IS NULL OR @EventType NOT IN ('triggered','reset')
    THROW 51001,'Valid episode and transition are required.',1;
 DECLARE @existing uniqueidentifier, @new bit=0;
 BEGIN TRAN;
 SELECT @existing=DecisionId FROM poc.Decision WITH(UPDLOCK,HOLDLOCK)
 WHERE EpisodeKey=@EpisodeKey AND EventType=@EventType;
 IF @existing IS NULL BEGIN
   SET @existing=NEWID(); SET @new=1;
   INSERT poc.Decision(EpisodeKey,EventType,DecisionId,SentinelIncidentArmId,Status)
   VALUES(@EpisodeKey,@EventType,@existing,@SentinelIncidentArmId,'Claimed');
 END;
 COMMIT;
 SELECT @new AS IsNewClaim,d.* FROM poc.Decision d WHERE DecisionId=@existing;
END;
GO
CREATE PROCEDURE poc.GetEpisodeTicket @EpisodeKey varchar(200)
AS
BEGIN
 SET NOCOUNT ON;
 SELECT TicketId,Status FROM poc.Decision
 WHERE EpisodeKey=@EpisodeKey AND EventType='triggered' AND TicketId IS NOT NULL;
END;
GO
CREATE PROCEDURE poc.SaveDecision
 @DecisionId uniqueidentifier,@FinalAction varchar(12),
 @AIResult nvarchar(max)=NULL,@Evidence nvarchar(max)=NULL,
 @FrozenRequest nvarchar(max)=NULL,@TicketId bigint=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 IF @FinalAction NOT IN ('create','update','record')
    THROW 51002,'Unsupported final action.',1;
 IF (@AIResult IS NOT NULL AND ISJSON(@AIResult)<>1)
 OR (@Evidence IS NOT NULL AND ISJSON(@Evidence)<>1)
    THROW 51003,'Evidence and AI output must be valid JSON.',1;
 IF @FinalAction IN ('create','update') AND (@FrozenRequest IS NULL OR ISJSON(@FrozenRequest)<>1)
    THROW 51004,'A frozen JSON request is required.',1;
 IF @FinalAction='update' AND (@TicketId IS NULL OR @TicketId<=0)
    THROW 51005,'A known ticket is required for recovery updates.',1;
 UPDATE poc.Decision SET FinalAction=@FinalAction,AIResult=@AIResult,Evidence=@Evidence,
 FrozenRequest=@FrozenRequest,TicketId=@TicketId,
 Status=CASE WHEN @FinalAction='record' THEN 'Recorded' ELSE 'Ready' END,
 UpdatedUtc=SYSUTCDATETIME()
 WHERE DecisionId=@DecisionId AND Status='Claimed';
 IF @@ROWCOUNT<>1 THROW 51006,'Decision not in Claimed state; do not overwrite or resend.',1;
 SELECT DecisionId,Status FROM poc.Decision WHERE DecisionId=@DecisionId;
END;
GO
CREATE PROCEDURE poc.BeginSend @DecisionId uniqueidentifier
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 DECLARE @enabled bit,@used int,@max int,@action varchar(12),@status varchar(16),@send bit=0;
 BEGIN TRAN;
 -- Serialize ticket-send admission and cap updates.
 SELECT @enabled=TicketWritesEnabled,@used=CreateAttempts,@max=MaxCreateAttempts
 FROM poc.Config WITH(UPDLOCK,HOLDLOCK) WHERE ConfigId=1;
 SELECT @action=FinalAction,@status=Status FROM poc.Decision WITH(UPDLOCK,HOLDLOCK)
 WHERE DecisionId=@DecisionId;
 IF @status='Ready' AND @enabled=1 AND (@action='update' OR @used<@max) BEGIN
   IF @action='create' UPDATE poc.Config SET CreateAttempts=CreateAttempts+1 WHERE ConfigId=1;
   UPDATE poc.Decision SET Status='Attempting',FirstAttemptUtc=SYSUTCDATETIME(),UpdatedUtc=SYSUTCDATETIME()
   WHERE DecisionId=@DecisionId;
   SET @send=1;
 END;
 COMMIT;
 SELECT @send AS SendAllowed,DecisionId,FinalAction,FrozenRequest,TicketId,Status
 FROM poc.Decision WHERE DecisionId=@DecisionId;
END;
GO
CREATE PROCEDURE poc.CompleteSend @DecisionId uniqueidentifier,@TicketId bigint
AS
BEGIN
 SET NOCOUNT ON;
 IF @TicketId IS NULL OR @TicketId<=0 THROW 51007,'Valid Zendesk ticket ID required.',1;
 UPDATE poc.Decision SET TicketId=@TicketId,Status='Complete',UpdatedUtc=SYSUTCDATETIME()
 WHERE DecisionId=@DecisionId AND Status='Attempting';
 IF @@ROWCOUNT<>1 THROW 51008,'Decision not Attempting; inspect before changing state.',1;
 SELECT DecisionId,Status,TicketId FROM poc.Decision WHERE DecisionId=@DecisionId;
END;
GO
CREATE PROCEDURE poc.MarkReview @DecisionId uniqueidentifier,@Reason nvarchar(2000)
AS
BEGIN
 SET NOCOUNT ON;
 UPDATE poc.Decision SET Status='NeedsReview',ReviewReason=@Reason,UpdatedUtc=SYSUTCDATETIME()
 WHERE DecisionId=@DecisionId AND Status IN ('Claimed','Ready','Attempting','NeedsReview');
 SELECT DecisionId,Status,ReviewReason FROM poc.Decision WHERE DecisionId=@DecisionId;
END;
GO
/* DBA configuration examples -- REPLACE IDs, then execute intentionally:
UPDATE poc.Config SET TriageGroupId=111111, MonitoringRequesterId=222222 WHERE ConfigId=1;
UPDATE poc.Route SET ZendeskGroupId=333333 WHERE OwnerKey='infrastructure_operations';
UPDATE poc.Route SET ZendeskGroupId=444444 WHERE OwnerKey='database_operations';
-- Do not enable until shadow cases and Zendesk sandbox tests pass:
UPDATE poc.Config SET TicketWritesEnabled=1 WHERE ConfigId=1;
-- Emergency outbound stop (also disable the playbook if immediate shutdown is required):
UPDATE poc.Config SET TicketWritesEnabled=0 WHERE ConfigId=1;
*/
/* Runtime identity: create using your approved Entra authentication and grant only
EXECUTE on the seven runtime procedures above. Do not grant write access to Config/Route.
A script batch error in SSMS does not stop subsequent GO batches. Configure your runner
(e.g. sqlcmd -b) to stop on the first error. This is a FIRST-INSTALL script.
*/
