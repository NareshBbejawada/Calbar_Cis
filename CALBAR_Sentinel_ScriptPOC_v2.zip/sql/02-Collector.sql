SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
CREATE TABLE poc.Build (Version varchar(20) NOT NULL PRIMARY KEY);
INSERT poc.Build VALUES ('script-poc-v2');
CREATE TABLE poc.InputEvent (
 EventKey char(64) NOT NULL PRIMARY KEY,
 EpisodeKey varchar(200) NOT NULL,
 EventType varchar(12) NOT NULL CHECK(EventType IN ('triggered','reset')),
 SourceInstance varchar(60) NOT NULL,
 AlertRuleId varchar(20) NOT NULL,
 AlertObjectId varchar(20) NOT NULL,
 SourceOccurrenceId varchar(30) NOT NULL,
 OccurredUtc datetime2(3) NOT NULL,
 ReceivedUtc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
 LastReceivedUtc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
 Deliveries int NOT NULL DEFAULT 1,
 SourceSummary nvarchar(1000) NOT NULL DEFAULT N'',
 IngestedUtc datetime2(3) NULL,
 IngestAttempts int NOT NULL DEFAULT 0,
 LastIngestError nvarchar(500) NULL,
 CONSTRAINT UQ_InputTransition UNIQUE(EpisodeKey,EventType)
);
CREATE TABLE poc.SourceCheckpoint (
 SourceInstance varchar(60) NOT NULL, AlertRuleId varchar(20) NOT NULL, AlertObjectId varchar(20) NOT NULL,
 LastHistoryId bigint NOT NULL CHECK(LastHistoryId>=0), UpdatedUtc datetime2(3) NOT NULL,
 CONSTRAINT PK_Checkpoint PRIMARY KEY(SourceInstance,AlertRuleId,AlertObjectId)
);
CREATE TABLE poc.CollectionIssue (
 SourceInstance varchar(60) NOT NULL, HistoryId bigint NOT NULL, Reason nvarchar(1000) NOT NULL,
 CreatedUtc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
 CONSTRAINT PK_CollectionIssue PRIMARY KEY(SourceInstance,HistoryId)
);
CREATE TABLE poc.WorkerHealth (
 Stage varchar(40) NOT NULL PRIMARY KEY, LastRunUtc datetime2(3) NOT NULL,
 LastSuccessUtc datetime2(3) NULL, LastError nvarchar(500) NULL
);
ALTER TABLE poc.Decision ADD SentinelAlertId varchar(100) NULL;
GO
CREATE PROCEDURE poc.AddInputEvent
 @SourceInstance varchar(60),@AlertRuleId varchar(20),@AlertObjectId varchar(20),
 @SourceOccurrenceId varchar(30),@EventType varchar(12),@OccurredUtc datetime2(3),
 @SourceSummary nvarchar(1000)=N''
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 IF @SourceInstance IS NULL OR @SourceInstance='' OR @SourceInstance LIKE '%[^A-Za-z0-9_.-]%'
 OR @AlertRuleId IS NULL OR @AlertRuleId='' OR @AlertRuleId LIKE '%[^0-9]%'
 OR @AlertObjectId IS NULL OR @AlertObjectId='' OR @AlertObjectId LIKE '%[^0-9]%'
 OR @SourceOccurrenceId IS NULL OR @SourceOccurrenceId='' OR @SourceOccurrenceId LIKE '%[^0-9]%'
 OR @EventType NOT IN ('triggered','reset') OR @OccurredUtc IS NULL
 THROW 51101,'Invalid source identity or transition.',1;
 DECLARE @episode varchar(200)=CONCAT(@SourceInstance,'|',@AlertRuleId,'|',@AlertObjectId,'|',@SourceOccurrenceId);
 DECLARE @key char(64)=CONVERT(char(64),HASHBYTES('SHA2_256',CONCAT(@episode,'|',@EventType)),2);
 BEGIN TRAN;
 IF EXISTS(SELECT 1 FROM poc.InputEvent WITH(UPDLOCK,HOLDLOCK) WHERE EventKey=@key)
   UPDATE poc.InputEvent SET Deliveries=Deliveries+1,LastReceivedUtc=SYSUTCDATETIME() WHERE EventKey=@key;
 ELSE
   INSERT poc.InputEvent(EventKey,EpisodeKey,EventType,SourceInstance,AlertRuleId,AlertObjectId,
       SourceOccurrenceId,OccurredUtc,SourceSummary)
   VALUES(@key,@episode,@EventType,@SourceInstance,@AlertRuleId,@AlertObjectId,
       @SourceOccurrenceId,@OccurredUtc,@SourceSummary);
 COMMIT;
 SELECT EventKey,EpisodeKey,EventType,Deliveries FROM poc.InputEvent WHERE EventKey=@key;
END;
GO
CREATE PROCEDURE poc.GetPendingEvents @BatchSize int=25
AS
BEGIN
 SET NOCOUNT ON;
 IF @BatchSize NOT BETWEEN 1 AND 100 THROW 51102,'BatchSize must be 1..100.',1;
 SELECT TOP (@BatchSize) * FROM poc.InputEvent WHERE IngestedUtc IS NULL ORDER BY ReceivedUtc,EventKey;
END;
GO
CREATE PROCEDURE poc.MarkIngestion @EventKey char(64),@Success bit,@Error nvarchar(500)=NULL
AS
BEGIN
 SET NOCOUNT ON;
 UPDATE poc.InputEvent SET IngestAttempts=IngestAttempts+1,
 IngestedUtc=CASE WHEN @Success=1 THEN SYSUTCDATETIME() ELSE IngestedUtc END,
 LastIngestError=CASE WHEN @Success=1 THEN NULL ELSE @Error END WHERE EventKey=@EventKey;
END;
GO
CREATE PROCEDURE poc.GetInputEvent @EventKey char(64)
AS
BEGIN SET NOCOUNT ON; SELECT * FROM poc.InputEvent WHERE EventKey=@EventKey; END;
GO
CREATE PROCEDURE poc.AttachSentinelAlert @DecisionId uniqueidentifier,@AlertId varchar(100)
AS
BEGIN SET NOCOUNT ON; UPDATE poc.Decision SET SentinelAlertId=@AlertId WHERE DecisionId=@DecisionId; END;
GO
CREATE PROCEDURE poc.GetCheckpoint @SourceInstance varchar(60),@AlertRuleId varchar(20),@AlertObjectId varchar(20)
AS
BEGIN SET NOCOUNT ON;
 SELECT LastHistoryId FROM poc.SourceCheckpoint WHERE SourceInstance=@SourceInstance
 AND AlertRuleId=@AlertRuleId AND AlertObjectId=@AlertObjectId;
END;
GO
CREATE PROCEDURE poc.SetCheckpoint @SourceInstance varchar(60),@AlertRuleId varchar(20),@AlertObjectId varchar(20),@HistoryId bigint
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 IF @HistoryId<0 THROW 51103,'Negative checkpoint.',1;
 BEGIN TRAN;
 IF EXISTS(SELECT 1 FROM poc.SourceCheckpoint WITH(UPDLOCK,HOLDLOCK) WHERE SourceInstance=@SourceInstance
 AND AlertRuleId=@AlertRuleId AND AlertObjectId=@AlertObjectId)
 BEGIN
   IF EXISTS(SELECT 1 FROM poc.SourceCheckpoint WHERE SourceInstance=@SourceInstance
   AND AlertRuleId=@AlertRuleId AND AlertObjectId=@AlertObjectId AND LastHistoryId>@HistoryId)
   THROW 51104,'Refusing checkpoint rewind. Reconcile source restoration manually.',1;
   UPDATE poc.SourceCheckpoint SET LastHistoryId=@HistoryId,UpdatedUtc=SYSUTCDATETIME()
   WHERE SourceInstance=@SourceInstance AND AlertRuleId=@AlertRuleId AND AlertObjectId=@AlertObjectId;
 END
 ELSE INSERT poc.SourceCheckpoint VALUES(@SourceInstance,@AlertRuleId,@AlertObjectId,@HistoryId,SYSUTCDATETIME());
 COMMIT;
END;
GO
CREATE PROCEDURE poc.RecordCollectionIssue @SourceInstance varchar(60),@HistoryId bigint,@Reason nvarchar(1000)
AS
BEGIN SET NOCOUNT ON; SET XACT_ABORT ON;
 BEGIN TRAN;
 IF NOT EXISTS(SELECT 1 FROM poc.CollectionIssue WITH(UPDLOCK,HOLDLOCK)
 WHERE SourceInstance=@SourceInstance AND HistoryId=@HistoryId)
 INSERT poc.CollectionIssue(SourceInstance,HistoryId,Reason) VALUES(@SourceInstance,@HistoryId,@Reason);
 COMMIT;
END;
GO
CREATE PROCEDURE poc.RecordHealth @Stage varchar(40),@Success bit,@Error nvarchar(500)=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 BEGIN TRAN;
 IF NOT EXISTS(SELECT 1 FROM poc.WorkerHealth WITH(UPDLOCK,HOLDLOCK) WHERE Stage=@Stage)
 INSERT poc.WorkerHealth(Stage,LastRunUtc) VALUES(@Stage,SYSUTCDATETIME());
 UPDATE poc.WorkerHealth SET LastRunUtc=SYSUTCDATETIME(),
 LastSuccessUtc=CASE WHEN @Success=1 THEN SYSUTCDATETIME() ELSE LastSuccessUtc END,
 LastError=CASE WHEN @Success=1 THEN NULL ELSE @Error END WHERE Stage=@Stage;
 COMMIT;
END;
GO
CREATE PROCEDURE poc.GetHealth
AS
BEGIN SET NOCOUNT ON;
 SELECT 'Worker' AS Category,Stage AS Item,CONVERT(varchar(33),LastSuccessUtc,126) AS LastSuccess,
 LastError AS Detail FROM poc.WorkerHealth
 UNION ALL SELECT 'PendingIngest',CONVERT(varchar(40),COUNT_BIG(*)),NULL,
 CONVERT(nvarchar(500),MIN(ReceivedUtc),126) FROM poc.InputEvent WHERE IngestedUtc IS NULL
 UNION ALL SELECT 'Decision',Status,NULL,CONVERT(nvarchar(500),COUNT_BIG(*)) FROM poc.Decision GROUP BY Status
 UNION ALL SELECT 'WaitingForSentinel',CONVERT(varchar(40),COUNT_BIG(*)),NULL,
 CONVERT(nvarchar(500),MIN(e.ReceivedUtc),126) FROM poc.InputEvent e
 LEFT JOIN poc.Decision d ON e.EpisodeKey=d.EpisodeKey AND e.EventType=d.EventType
 WHERE e.IngestedUtc IS NOT NULL AND d.DecisionId IS NULL
 UNION ALL SELECT 'CollectionIssue',CONVERT(varchar(40),COUNT_BIG(*)),NULL,NULL FROM poc.CollectionIssue
 UNION ALL SELECT 'TicketSwitch',CONVERT(varchar(40),TicketWritesEnabled),NULL,
 CONCAT('Create attempts ',CreateAttempts,' / ',MaxCreateAttempts) FROM poc.Config;
END;
GO
CREATE ROLE poc_runtime AUTHORIZATION dbo;
GO
GRANT EXECUTE ON OBJECT::poc.GetRoute TO poc_runtime;
GRANT EXECUTE ON OBJECT::poc.ClaimDecision TO poc_runtime;
GRANT EXECUTE ON OBJECT::poc.GetEpisodeTicket TO poc_runtime;
GRANT EXECUTE ON OBJECT::poc.SaveDecision TO poc_runtime;
GRANT EXECUTE ON OBJECT::poc.BeginSend TO poc_runtime;
GRANT EXECUTE ON OBJECT::poc.CompleteSend TO poc_runtime;
GRANT EXECUTE ON OBJECT::poc.MarkReview TO poc_runtime;
GRANT EXECUTE ON OBJECT::poc.AddInputEvent TO poc_runtime;
GRANT EXECUTE ON OBJECT::poc.GetPendingEvents TO poc_runtime;
GRANT EXECUTE ON OBJECT::poc.MarkIngestion TO poc_runtime;
GRANT EXECUTE ON OBJECT::poc.GetInputEvent TO poc_runtime;
GRANT EXECUTE ON OBJECT::poc.AttachSentinelAlert TO poc_runtime;
GRANT EXECUTE ON OBJECT::poc.GetCheckpoint TO poc_runtime;
GRANT EXECUTE ON OBJECT::poc.SetCheckpoint TO poc_runtime;
GRANT EXECUTE ON OBJECT::poc.RecordCollectionIssue TO poc_runtime;
GRANT EXECUTE ON OBJECT::poc.RecordHealth TO poc_runtime;
GRANT EXECUTE ON OBJECT::poc.GetHealth TO poc_runtime;
-- DBA: CREATE LOGIN/USER for the Windows identity using your approved process.
-- ALTER ROLE poc_runtime ADD MEMBER [CALSB\approved-service-identity];
-- No db_owner, SELECT or table-write grants are needed by the worker.
