-- Read-only review. Runtime users can use EXEC poc.GetHealth instead.
SELECT * FROM poc.Config;
SELECT EpisodeKey,EventType,Status,FinalAction,TicketId,SentinelAlertId,CreatedUtc,ReviewReason
FROM poc.Decision ORDER BY CreatedUtc DESC;
SELECT EventKey,EpisodeKey,EventType,Deliveries,OccurredUtc,ReceivedUtc,IngestedUtc,LastIngestError
FROM poc.InputEvent ORDER BY ReceivedUtc DESC;
SELECT * FROM poc.SourceCheckpoint;
SELECT * FROM poc.CollectionIssue ORDER BY CreatedUtc DESC;
SELECT * FROM poc.WorkerHealth;
SELECT * FROM poc.Decision WHERE Status IN ('NeedsReview','Ready','Claimed','Attempting');
-- An unfinished claim must be investigated, not deleted or blindly resubmitted.
-- Stop outbound writes (DBA); also stop the running worker for an immediate stop:
-- UPDATE poc.Config SET TicketWritesEnabled=0 WHERE ConfigId=1;
-- Enable after successful shadow review only:
-- UPDATE poc.Config SET TicketWritesEnabled=1 WHERE ConfigId=1;
