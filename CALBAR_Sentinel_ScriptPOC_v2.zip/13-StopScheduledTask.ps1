#requires -Version 7.4
[CmdletBinding(SupportsShouldProcess)]
param([string]$TaskName='DBA_CALBAR_SentinelPOC')
$ErrorActionPreference='Stop'
if($PSCmdlet.ShouldProcess($TaskName,'Disable and stop only the POC task')){
 Disable-ScheduledTask -TaskName $TaskName|Out-Null
 Stop-ScheduledTask -TaskName $TaskName
 Write-Warning 'Also run 11-SetTicketWrites.ps1 -Enabled $false. Preserve SQL decisions; do not delete/replay ambiguous sends.'
}
