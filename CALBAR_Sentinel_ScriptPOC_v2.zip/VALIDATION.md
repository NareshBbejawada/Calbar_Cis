# Validation record

Date: 2026-10-31

## Checks executed in the preparation environment

- PASS JSON syntax: settings.example.json
- PASS JSON syntax: lib/AI-response.schema.json
- PASS AI schema: valid advisory payload
- PASS AI schema rejection: unknown owner
- PASS AI schema rejection: wrong action
- PASS AI schema rejection: nonboolean review
- PASS AI schema rejection: extra command
- PASS static procedure-reference check: all 17 referenced procedures have definitions
- PASS conservative delimiter/here-string checks across 18 PowerShell files (not parser/compiler validation)
- PASS safe-default/static checks: Shadow, collector off, AI off, SQL writes off; no listed certificate/execution-policy bypasses

## Not executed here

PowerShell AST/parser/runtime tests, T-SQL parsing/execution, Azure deployments, RBAC changes,
SWIS calls, model inference, Zendesk writes and Windows Task Scheduler were **not** executed.
PowerShell and SQL runtimes and the user's cloud credentials are not available in this environment.
Static and JSON checks are not a substitute for these tests.

Before deployment, run `tests/Test-Offline.ps1` on the approved Windows host.
After SQL setup, run `tests/State-Contract.sql` in the new POC database.
Then follow the connection, shadow and sandbox-write acceptance gates in README.md.

## Packaging

The archive contains no credentials, runtime state or font files. SHA256SUMS.txt records
hashes of the delivered files (excluding itself). Verify hashes before reviewing/signing scripts.
