#requires -Version 7.4
[CmdletBinding()]
param([string]$ConfigPath="$PSScriptRoot/settings.json",
 [ValidatePattern('^\d{1,20}$')][string]$OccurrenceId='10001',
 [ValidateSet('Node','Disk','Success','Unknown')][string]$Scenario='Node',
 [ValidateSet('triggered','reset')][string]$EventType='triggered',
 [ValidateRange(1,100)][int]$Repeat=1,
 [string]$Summary='Synthetic POC condition; no actual outage implied.')
. "$PSScriptRoot/lib/Poc.Common.ps1"
$c=Read-PocSettings $ConfigPath
if($Summary.Length -gt 1000){throw 'Summary must be at most 1000 characters.'}
$map=@{Node=@('101','1001');Disk=@('102','1002');Success=@('103','1003');Unknown=@('999','9999')}
for($i=0;$i -lt $Repeat;$i++){
 $r=Invoke-PocDb $c 'poc.AddInputEvent' @{SourceInstance='CALBAR-SW-POC';AlertRuleId=$map[$Scenario][0];
 AlertObjectId=$map[$Scenario][1];SourceOccurrenceId=$OccurrenceId;EventType=$EventType;
 OccurredUtc=[DateTime]::UtcNow;SourceSummary=$Summary}
}
$r|Format-Table -AutoSize
Write-Host 'Stored durably in SQL. Run 09-RunPoc.ps1 to ingest it. This script does not call Zendesk.'
