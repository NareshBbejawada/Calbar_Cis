#requires -Version 7.4
[CmdletBinding()]
param([string]$ConfigPath="$PSScriptRoot/settings.json",[ValidateSet('Zendesk','SolarWinds')][string]$For)
. "$PSScriptRoot/lib/Poc.Common.ps1"
$c=Read-PocSettings $ConfigPath
if(-not $IsWindows){throw 'Windows DPAPI is required.'}
if(-not $For){throw 'Specify -For Zendesk or -For SolarWinds.'}
$dir=Join-Path $c._Directory 'secrets';New-Item -ItemType Directory -Path $dir -Force|Out-Null
$acl=Get-Acl $dir;$acl.SetAccessRuleProtection($true,$false)
foreach($entry in @($acl.Access)){$acl.RemoveAccessRuleAll($entry)}
$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User
foreach($identity in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'),[Security.Principal.SecurityIdentifier]::new('S-1-5-32-544'))){
 $rule=[Security.AccessControl.FileSystemAccessRule]::new($identity,'FullControl','ContainerInherit,ObjectInherit','None','Allow')
 $acl.AddAccessRule($rule)
}
Set-Acl -Path $dir -AclObject $acl
if($For -eq 'Zendesk'){
 $secret=Read-Host 'Paste approved Zendesk OAuth access token (not an API token)' -AsSecureString
 $credential=[pscredential]::new('ZendeskOAuth',$secret)
}else{$credential=Get-Credential -Message 'Read-only SolarWinds SWIS identity'}
$path=Join-Path $dir "$For.clixml"
$credential|Export-Clixml -LiteralPath $path
# Ensure a previously existing file cannot retain permissive explicit ACEs.
$fileAcl=Get-Acl $path;$fileAcl.SetAccessRuleProtection($false,$false)
foreach($entry in @($fileAcl.Access|Where-Object {-not $_.IsInherited})){$fileAcl.RemoveAccessRuleAll($entry)}
Set-Acl -Path $path -AclObject $fileAcl
Write-Host "Saved $For credential with Windows user/machine encryption. Run the worker under this same Windows identity on this host."
