#requires -Version 7.4
[CmdletBinding(SupportsShouldProcess)]
param([string]$ConfigPath="$PSScriptRoot/settings.json",[string]$TaskName='DBA_CALBAR_SentinelPOC',[switch]$ApproveUnattended)
. "$PSScriptRoot/lib/Poc.Common.ps1"
$c=Read-PocSettings $ConfigPath
if(-not $IsWindows -or -not $ApproveUnattended){throw 'Run on Windows with -ApproveUnattended only after foreground testing.'}
if($c.Azure.AuthMode -eq 'Interactive'){throw 'Scheduled tasks require ManagedIdentity on the Azure Government VM or certificate-based Azure authentication, not an interactive user token.'}
if(Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue){throw 'Task already exists. Review it instead of overwriting it.'}
$credential=Get-Credential -Message 'Same Windows worker account that saved the DPAPI credentials; Windows will store this task logon.'
$account=[Security.Principal.NTAccount]::new($credential.UserName)
$sid=$account.Translate([Security.Principal.SecurityIdentifier])
if($sid -ne [Security.Principal.WindowsIdentity]::GetCurrent().User){throw 'Save credentials and register the task from the actual worker Windows identity. Different-user DPAPI will not decrypt.'}
if(-not $PSCmdlet.ShouldProcess($TaskName,'Register task every two minutes')){return}
$exe=(Get-Command pwsh.exe -ErrorAction Stop).Source
$cfg=(Resolve-Path $ConfigPath).Path
$script=(Resolve-Path "$PSScriptRoot/09-RunPoc.ps1").Path
$arguments="-NoProfile -NonInteractive -File `"$script`" -ConfigPath `"$cfg`""
$action=New-ScheduledTaskAction -Execute $exe -Argument $arguments -WorkingDirectory $PSScriptRoot
$trigger=New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 2)
$settings=New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 10) -StartWhenAvailable
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings `
    -User $credential.UserName -Password $credential.GetNetworkCredential().Password -RunLevel Limited | Out-Null
Write-Host 'Task registered. Monitor Task Scheduler last-run results AND SQL health/NeedsReview records. No independent pager was installed.'
