#requires -Version 7.4
[CmdletBinding(SupportsShouldProcess)]
param([string]$ConfigPath="$PSScriptRoot/settings.json",[string]$ApprovedEgressIPv4,[switch]$ApproveMeteredResources)
. "$PSScriptRoot/lib/Poc.Common.ps1"
. "$PSScriptRoot/lib/Poc.Deploy.ps1"
$c=Read-PocSettings $ConfigPath
if(-not $ApproveMeteredResources){throw 'Model hosting/inference costs require -ApproveMeteredResources.'}
$ip=$null
if(-not [Net.IPAddress]::TryParse($ApprovedEgressIPv4,[ref]$ip) -or $ip.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork){throw 'Provide the approved public NAT egress IPv4 of the worker. Private-only deployments must be provisioned by your Azure team instead.'}
if($c.AI.AccountName -notmatch '^[a-z0-9][a-z0-9-]{2,62}$' -or $c.AI.AccountName -like 'REPLACE*'){throw 'Configure a unique lower-case AI.AccountName.'}
Connect-PocAzure $c -Deployment;Import-Module Az.Resources
Assert-PocGuid $c.Azure.RuntimePrincipalObjectId 'Azure.RuntimePrincipalObjectId'
$project='CALBAR-AlertOps-ScriptPOC-v2'
$rg=Get-AzResourceGroup -Name $c.Azure.ResourceGroup
if($rg.Tags.Project -ne $project){throw 'Run the foundation deployment in its dedicated group first.'}
if(-not $PSCmdlet.ShouldProcess($c.AI.AccountName,'Create approved Azure Government AI resource and model deployment')){return}
Register-AzResourceProvider -ProviderNamespace Microsoft.CognitiveServices|Out-Null
$av=Get-PocApiVersion Microsoft.CognitiveServices accounts @('2024-10-01','2023-05-01')
$dv=Get-PocApiVersion Microsoft.CognitiveServices accounts/deployments @('2024-10-01','2023-05-01')
$id="/subscriptions/$($c.Azure.SubscriptionId)/resourceGroups/$($c.Azure.ResourceGroup)/providers/Microsoft.CognitiveServices/accounts/$($c.AI.AccountName)"
$existing=Get-AzResource -ResourceId $id -ErrorAction SilentlyContinue
if($existing -and $existing.Tags.Project -ne $project){throw 'Refusing to change an AI resource not owned by this kit.'}
Invoke-PocArm PUT $id $av @{kind='OpenAI';location=$c.Azure.Location;tags=@{Project=$project};sku=@{name='S0'};
 properties=@{customSubDomainName=$c.AI.AccountName;disableLocalAuth=$true;publicNetworkAccess='Enabled';
 networkAcls=@{defaultAction='Deny';ipRules=@(@{value=$ApprovedEgressIPv4});virtualNetworkRules=@()}}}|Out-Null
$account=Wait-PocResource $id $av
$deployment="$id/deployments/$($c.AI.DeploymentName)"
Invoke-PocArm PUT $deployment $dv @{sku=@{name=$c.AI.DeploymentSku;capacity=[int]$c.AI.Capacity};properties=@{
 model=@{format='OpenAI';name=$c.AI.ModelName;version=$c.AI.ModelVersion};versionUpgradeOption='NoAutoUpgrade'}}|Out-Null
Wait-PocResource $deployment $dv|Out-Null
Grant-PocRole $c.Azure.RuntimePrincipalObjectId 'Cognitive Services OpenAI User' $id
$endpoint=$account.properties.endpoint
Write-Host 'Copy the following returned endpoint into AI.Endpoint, then set AI.Enabled=true after security approval:'
Write-Output $endpoint
Write-Host 'Entra authentication is used; local API-key authentication is disabled. Confirm deployed model/region/quota and approved content policy in the portal.'
