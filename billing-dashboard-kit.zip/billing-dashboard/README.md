# Billing Cycle Monitor: deployment guide

An interactive dashboard for the Jan–Feb online fee billing cycle, built for two audiences:
**Executive** (amounts collected, payments, success rate, % of members paid) and
**IT Operations** (hourly outcomes, failure reasons, stuck payments, DMZ web-server split,
GEORGE linked-server latency, AG health, billing jobs, SQL waits, collector status).

## How it works

```
GEORGE (BMTRANP, BMMASTP …)  --OPENQUERY every 2 min-->  Billing_V2.mon.*  (SFDBSLISTN01)
SQL DMVs (sessions, AG, waits, blocking) ----------------^        |
Billing_V2 .NET job log + SQL Agent history -------------^        | mon.usp_GetDashboardJson
                                                                  v
                                 Export-BillingDashboard.ps1 -> data.json
                                                                  v
                     billing_dashboard.html (internal IIS site, auto-refresh 60 s)
```

* The dashboard reads **only** `data.json`. However many people open it, it adds no load to GEORGE or SQL.
* Each run reads only the last `TxnLookbackHours` (default 6) of BMTRANP through the linked server.
  The filter runs on GEORGE, inside OPENQUERY.
* If `data.json` is missing, the page shows built-in **SAMPLE DATA** (yellow badge).

## Files

| File | Purpose |
|---|---|
| `sql/00_discover_columns.sql` | Lists columns and sample rows of BMTRANP / BMADPNDP / BMMASTP / BMCITMP, and finds the job log tables in Billing_V2 |
| `sql/01_mon_schema.sql` | `mon` schema, config, mapping tables, snapshot tables, seed values |
| `sql/02_mon_collect.sql` | `mon.usp_Collect`: collection, with each step isolated and logged |
| `sql/03_mon_dashboard_json.sql` | `mon.usp_GetDashboardJson`: one JSON document for the page |
| `sql/04_agent_job.sql` | SQL Agent job (primary-only, every 2 min): collect, then export |
| `Export-BillingDashboard.ps1` | Writes `data.json` atomically (MultiSubnetFailover on) |
| `billing_dashboard.html` | The dashboard: one self-contained file with no internet dependencies |

## Deployment steps

1. **Discover columns.** Run `00_discover_columns.sql` on the instance that owns linked server `George_PRDT`.
2. **Create the schema.** Run `01_mon_schema.sql` against Billing_V2 on the primary (SFDBSLISTN01).
3. **Edit the config** to match the real GEORGE columns (this is the only adaptation needed):
   * `GeorgeTxnQuery` must return `TRAN_ID, TRAN_TS, APP_CODE, STATUS_CODE, AMOUNT, ERROR_CODE, ERROR_TEXT`.
     Replace the `<…_COL>` placeholders. If status or app source lives in BMADPNDP / BMCITMP, join it here.
   * `GeorgeProgressQuery` uses BMMASTP to count billed vs paid members.
   * `AppJobLogQuery` points at the .NET billing jobs' log table in Billing_V2.
   * Fill `mon.StatusMap` (status code → Completed / Failed / Pending / Cancelled) and `mon.AppMap` with the real codes.
   ```sql
   UPDATE mon.Config SET ConfigValue = N'…' WHERE ConfigKey = N'GeorgeTxnQuery';
   ```
4. **Create the procedures.** Run `02_mon_collect.sql` and `03_mon_dashboard_json.sql`.
   Test with `EXEC mon.usp_Collect; SELECT * FROM mon.CollectLog ORDER BY LogId DESC;`
5. **Create the Agent job.** Copy `Export-BillingDashboard.ps1` to the same path on **all 4 AG nodes**.
   Set `@ScriptPath` / `@OutFile` in `04_agent_job.sql` and run it on **each node**.
   The job runs only where Billing_V2 is primary, so it keeps working after a failover to DR.
6. **Host the page.** Put `billing_dashboard.html` in a folder on an **internal** IIS site
   (not SFWEBPRD11–14) with Windows Authentication. `data.json` gets written to the same folder.
   Grant read access to the IT and management AD groups.

## Permissions

* The SQL Agent service account (or a CmdExec proxy) needs a login mapping on `George_PRDT`, `VIEW SERVER STATE`,
  read access to `msdb` job history, and write access to the dashboard folder.
* The IIS site serves a static file only, so no database credentials sit on the web server.

## Thresholds (in `mon.Config`)

| Key | Default | Alert |
|---|---|---|
| FailRateWarnPct / FailRateCritPct | 5 / 15 | Failure rate in the last full hour (only when there were ≥ 20 attempts) |
| StuckPendingMinutes | 30 | Payment still pending: likely a missed gateway postback or a session lost on return |
| PingWarnMs / PingCritMs | 500 / 2000 | GEORGE linked-server round trip |
| RedoQueueWarnKb | 102400 | AG redo queue |
| BlockWarnSec | 30 | Blocking |

Outside the billing window, slow the job to every 15 minutes (see the tip at the end of `04_agent_job.sql`).
When today's date falls outside the cycle, the page shows the last 60 days.

## Answering the Western / South Central question with this dashboard

The **DMZ web servers** panel shows live connections from SFWEBPRD11–14 to Billing_V2, with the
Western vs South Central split. During cycle traffic, a sustained share on SFWEBPRD14 means both zones are serving at once
(active-active). Read that together with **Stuck pending** and the `SESSION_LOST` failure reason (if GEORGE records one)
to see whether cross-zone bouncing is hurting payments.
