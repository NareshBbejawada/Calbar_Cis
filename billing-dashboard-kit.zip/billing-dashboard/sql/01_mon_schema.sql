/* =====================================================================
   01_mon_schema.sql  -  Billing cycle monitoring schema
   Target : Billing_V2 via listener SFDBSLISTN01 (run on the PRIMARY)
   Needs  : SQL Server 2016+ (FOR JSON, STRING_AGG not required)
   Safe to re-run: objects are created only if missing; config rows are
   inserted only if missing (your edits are kept).
   ===================================================================== */
USE Billing_V2;
GO
IF SCHEMA_ID(N'mon') IS NULL EXEC (N'CREATE SCHEMA mon AUTHORIZATION dbo;');
GO

/* ---------- Configuration ------------------------------------------- */
IF OBJECT_ID(N'mon.Config') IS NULL
CREATE TABLE mon.Config (
    ConfigKey   sysname        NOT NULL CONSTRAINT PK_mon_Config PRIMARY KEY,
    ConfigValue nvarchar(max)  NOT NULL,
    Notes       nvarchar(500)  NULL
);
GO

/* Application codes as they appear in GEORGE -> friendly names */
IF OBJECT_ID(N'mon.AppMap') IS NULL
CREATE TABLE mon.AppMap (
    AppCode   nvarchar(50)  NOT NULL CONSTRAINT PK_mon_AppMap PRIMARY KEY,
    AppName   nvarchar(100) NOT NULL,
    SortOrder int           NOT NULL DEFAULT (99)
);
GO

/* Transaction status codes in GEORGE -> dashboard category */
IF OBJECT_ID(N'mon.StatusMap') IS NULL
CREATE TABLE mon.StatusMap (
    StatusCode  nvarchar(50)  NOT NULL CONSTRAINT PK_mon_StatusMap PRIMARY KEY,
    Category    varchar(20)   NOT NULL
        CONSTRAINT CK_mon_StatusMap_Cat CHECK (Category IN ('Completed','Failed','Pending','Cancelled')),
    Description nvarchar(200) NULL
);
GO

/* DMZ web servers -> zone */
IF OBJECT_ID(N'mon.ZoneMap') IS NULL
CREATE TABLE mon.ZoneMap (
    HostName sysname     NOT NULL CONSTRAINT PK_mon_ZoneMap PRIMARY KEY,
    Zone     varchar(30) NOT NULL
);
GO

/* ---------- Collected data ------------------------------------------ */
/* Local copy of recent GEORGE payment transactions (keeps dashboard
   queries off the linked server during peak load)                     */
IF OBJECT_ID(N'mon.PaymentTxn') IS NULL
CREATE TABLE mon.PaymentTxn (
    TranId       nvarchar(64)  NOT NULL CONSTRAINT PK_mon_PaymentTxn PRIMARY KEY,
    TranTs       datetime2(0)  NOT NULL,
    AppCode      nvarchar(50)  NULL,
    StatusCode   nvarchar(50)  NULL,
    Amount       decimal(12,2) NULL,
    ErrorCode    nvarchar(100) NULL,
    ErrorText    nvarchar(400) NULL,
    FirstSeenTs  datetime2(0)  NOT NULL DEFAULT (SYSDATETIME()),
    LastSeenTs   datetime2(0)  NOT NULL DEFAULT (SYSDATETIME())
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_mon_PaymentTxn_TranTs')
CREATE INDEX IX_mon_PaymentTxn_TranTs ON mon.PaymentTxn (TranTs)
    INCLUDE (AppCode, StatusCode, Amount, ErrorCode);
GO

IF OBJECT_ID(N'mon.BillingProgress') IS NULL
CREATE TABLE mon.BillingProgress (
    SnapTs        datetime2(0)  NOT NULL CONSTRAINT PK_mon_BillingProgress PRIMARY KEY,
    MembersBilled int           NULL,
    MembersPaid   int           NULL,
    AmountBilled  decimal(14,2) NULL,
    AmountPaid    decimal(14,2) NULL
);
GO

IF OBJECT_ID(N'mon.JobRun') IS NULL
CREATE TABLE mon.JobRun (
    Source        varchar(20)    NOT NULL,     -- 'AppLog' (Billing_V2) or 'SQLAgent'
    JobName       nvarchar(200)  NOT NULL,
    RunStart      datetime2(0)   NOT NULL,
    RunEnd        datetime2(0)   NULL,
    Status        varchar(20)    NOT NULL,     -- Succeeded / Failed / Running
    RowsProcessed int            NULL,
    Message       nvarchar(1000) NULL,
    CONSTRAINT PK_mon_JobRun PRIMARY KEY (Source, JobName, RunStart)
);
GO

IF OBJECT_ID(N'mon.LinkedServerPing') IS NULL
CREATE TABLE mon.LinkedServerPing (
    PingTs       datetime2(0)  NOT NULL,
    LinkedServer sysname       NOT NULL,
    DurationMs   int           NULL,
    Success      bit           NOT NULL,
    ErrorText    nvarchar(400) NULL,
    CONSTRAINT PK_mon_LinkedServerPing PRIMARY KEY (PingTs, LinkedServer)
);
GO

IF OBJECT_ID(N'mon.WebNodeSnapshot') IS NULL
CREATE TABLE mon.WebNodeSnapshot (
    SnapTs         datetime2(0) NOT NULL,
    HostName       sysname      NOT NULL,
    ProgramName    nvarchar(128) NOT NULL,
    DbName         sysname      NOT NULL,
    Sessions       int          NOT NULL,
    ActiveRequests int          NOT NULL,
    CpuMs          bigint       NOT NULL,
    CONSTRAINT PK_mon_WebNodeSnapshot PRIMARY KEY (SnapTs, HostName, ProgramName, DbName)
);
GO

IF OBJECT_ID(N'mon.AgSnapshot') IS NULL
CREATE TABLE mon.AgSnapshot (
    SnapTs         datetime2(0) NOT NULL,
    AgName         sysname      NOT NULL,
    ReplicaServer  sysname      NOT NULL,
    DbName         sysname      NOT NULL,
    RoleDesc       varchar(20)  NULL,
    AvailMode      varchar(30)  NULL,
    SyncState      varchar(30)  NULL,
    SyncHealth     varchar(30)  NULL,
    LogSendQueueKb bigint       NULL,
    RedoQueueKb    bigint       NULL,
    CONSTRAINT PK_mon_AgSnapshot PRIMARY KEY (SnapTs, AgName, ReplicaServer, DbName)
);
GO

IF OBJECT_ID(N'mon.InstanceSnapshot') IS NULL
CREATE TABLE mon.InstanceSnapshot (
    SnapTs          datetime2(0) NOT NULL CONSTRAINT PK_mon_InstanceSnapshot PRIMARY KEY,
    ActiveRequests  int NOT NULL,
    BlockedSessions int NOT NULL,
    LongestBlockSec int NOT NULL
);
GO

/* Cumulative wait stats (top N each run); deltas computed at read time */
IF OBJECT_ID(N'mon.WaitSnapshot') IS NULL
CREATE TABLE mon.WaitSnapshot (
    SnapTs   datetime2(0) NOT NULL,
    WaitType nvarchar(60) NOT NULL,
    WaitMs   bigint       NOT NULL,
    Tasks    bigint       NOT NULL,
    CONSTRAINT PK_mon_WaitSnapshot PRIMARY KEY (SnapTs, WaitType)
);
GO

IF OBJECT_ID(N'mon.CollectLog') IS NULL
CREATE TABLE mon.CollectLog (
    LogId      int IDENTITY(1,1) NOT NULL CONSTRAINT PK_mon_CollectLog PRIMARY KEY,
    RunTs      datetime2(0)   NOT NULL,
    Step       varchar(40)    NOT NULL,
    Status     varchar(10)    NOT NULL,   -- OK / ERROR / SKIP
    RowsAff    int            NULL,
    DurationMs int            NULL,
    Message    nvarchar(2000) NULL
);
GO

/* =====================================================================
   Seed data - EDIT THESE after running 00_discover_columns.sql
   ===================================================================== */
MERGE mon.Config AS t
USING (VALUES
 (N'CycleStart',        N'2027-01-01', N'First day of the billing cycle (local time)'),
 (N'CycleEnd',          N'2027-02-28', N'Last day of the billing cycle'),
 (N'GeorgeLinkedServer',N'George_PRDT', N'Linked server name used by OPENQUERY'),
 (N'TxnLookbackHours',  N'6',  N'Each run re-reads this many hours of GEORGE transactions, so status changes (pending -> completed) are picked up'),

 /* --- The ONE query you must adapt -------------------------------------
    Runs on GEORGE (pass-through, DB2 SQL dialect). It must return exactly
    these 7 columns, in this order:
        TRAN_ID, TRAN_TS (timestamp), APP_CODE, STATUS_CODE, AMOUNT,
        ERROR_CODE, ERROR_TEXT
    Tokens replaced at run time:
        {SINCE_TS}    -> '2027-01-20-08.00.00'  (DB2 timestamp literal)
        {SINCE_DATE8} -> 20270120               (for YYYYMMDD numeric dates)
    If BMTRANP stores date and time as numbers (common on IBM i), build the
    timestamp with TIMESTAMP_FORMAT(DIGITS(dt)||DIGITS(tm),'YYYYMMDDHH24MISS')
    and filter on the date column with {SINCE_DATE8} so the index is used.  */
 (N'GeorgeTxnQuery', N'SELECT T.<TRAN_ID_COL>                         AS TRAN_ID,
       TIMESTAMP_FORMAT(DIGITS(T.<TRAN_DATE_COL>) || DIGITS(T.<TRAN_TIME_COL>), ''YYYYMMDDHH24MISS'') AS TRAN_TS,
       T.<SOURCE_APP_COL>                                  AS APP_CODE,
       T.<STATUS_COL>                                      AS STATUS_CODE,
       T.<AMOUNT_COL>                                      AS AMOUNT,
       T.<ERROR_CODE_COL>                                  AS ERROR_CODE,
       T.<ERROR_TEXT_COL>                                  AS ERROR_TEXT
FROM   PRDT.BMTRANP T
WHERE  T.<TRAN_DATE_COL> >= {SINCE_DATE8}', N'Pass-through query against BMTRANP (join BMADPNDP / BMCITMP here if status or app lives there)'),

 /* Billing progress: who has been billed vs who has paid (BMMASTP).
    Must return MEMBERS_BILLED, MEMBERS_PAID, AMOUNT_BILLED, AMOUNT_PAID.
    Set to an empty string to disable.                                    */
 (N'GeorgeProgressQuery', N'SELECT COUNT(*)                                              AS MEMBERS_BILLED,
       SUM(CASE WHEN M.<BALANCE_COL> <= 0 THEN 1 ELSE 0 END) AS MEMBERS_PAID,
       SUM(M.<BILLED_AMT_COL>)                               AS AMOUNT_BILLED,
       SUM(M.<PAID_AMT_COL>)                                 AS AMOUNT_PAID
FROM   PRDT.BMMASTP M
WHERE  M.<BILL_YEAR_COL> = {CYCLE_YEAR}', N'Runs every ProgressEveryMinutes'),
 (N'ProgressEveryMinutes', N'30', NULL),

 (N'GeorgePingQuery', N'SELECT 1 AS OK FROM SYSIBM.SYSDUMMY1', N'Cheap round-trip used to time the linked server'),

 /* .NET billing job log in Billing_V2 (local T-SQL). Must return
    JOB_NAME, RUN_START, RUN_END, STATUS (Succeeded/Failed/Running),
    ROWS_PROCESSED, MESSAGE. Empty string = disabled.                   */
 (N'AppJobLogQuery', N'SELECT TOP (200)
       L.<JOB_NAME_COL>   AS JOB_NAME,
       L.<START_COL>      AS RUN_START,
       L.<END_COL>        AS RUN_END,
       CASE WHEN L.<STATUS_COL> IN (''S'',''Success'') THEN ''Succeeded''
            WHEN L.<END_COL> IS NULL THEN ''Running'' ELSE ''Failed'' END AS STATUS,
       L.<ROWS_COL>       AS ROWS_PROCESSED,
       LEFT(L.<MSG_COL>, 1000) AS MESSAGE
FROM   dbo.<JOB_LOG_TABLE> L
WHERE  L.<START_COL> >= DATEADD(DAY, -2, SYSDATETIME())
ORDER BY L.<START_COL> DESC', N'Billing_V2 log table for the .NET payment jobs'),
 (N'AgentJobNameLike', N'%Billing%', N'SQL Agent jobs whose name matches are also shown. Empty = none'),

 /* Alert thresholds (used by the dashboard) */
 (N'FailRateWarnPct',      N'5',      NULL),
 (N'FailRateCritPct',      N'15',     NULL),
 (N'StuckPendingMinutes',  N'30',     N'Pending longer than this = stuck'),
 (N'PingWarnMs',           N'500',    NULL),
 (N'PingCritMs',           N'2000',   NULL),
 (N'RedoQueueWarnKb',      N'102400', NULL),
 (N'BlockWarnSec',         N'30',     NULL),
 (N'RetentionDays',        N'400',    N'Keeps last year''s cycle for comparison')
) AS s (ConfigKey, ConfigValue, Notes)
ON t.ConfigKey = s.ConfigKey
WHEN NOT MATCHED THEN INSERT (ConfigKey, ConfigValue, Notes) VALUES (s.ConfigKey, s.ConfigValue, s.Notes);
GO

MERGE mon.ZoneMap AS t
USING (VALUES (N'SFWEBPRD11','Western'), (N'SFWEBPRD12','Western'),
              (N'SFWEBPRD13','Western'), (N'SFWEBPRD14','South Central')) AS s (HostName, Zone)
ON t.HostName = s.HostName
WHEN NOT MATCHED THEN INSERT (HostName, Zone) VALUES (s.HostName, s.Zone);
GO

/* Placeholder app codes - replace with the real values from BMTRANP */
MERGE mon.AppMap AS t
USING (VALUES (N'MSBP', N'My State Bar Profile', 1),
              (N'AGB',  N'Agency Billing',        2),
              (N'COS',  N'Certificate of Standing',3),
              (N'CRS',  N'Course Registration',   4),
              (N'MAW',  N'Members Admin (internal)',5)) AS s (AppCode, AppName, SortOrder)
ON t.AppCode = s.AppCode
WHEN NOT MATCHED THEN INSERT (AppCode, AppName, SortOrder) VALUES (s.AppCode, s.AppName, s.SortOrder);
GO

/* Placeholder status codes - replace with the real values */
MERGE mon.StatusMap AS t
USING (VALUES (N'C', 'Completed', N'Payment posted'),
              (N'F', 'Failed',    N'Payment failed'),
              (N'P', 'Pending',   N'Awaiting gateway response'),
              (N'X', 'Cancelled', N'Abandoned / cancelled by user')) AS s (StatusCode, Category, Description)
ON t.StatusCode = s.StatusCode
WHEN NOT MATCHED THEN INSERT (StatusCode, Category, Description) VALUES (s.StatusCode, s.Category, s.Description);
GO
