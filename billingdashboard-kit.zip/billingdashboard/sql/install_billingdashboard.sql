/* =====================================================================
   install_billingdashboard.sql  -  installs scripts 01-04 in one run
   >>> Run in SQLCMD MODE (SSMS: Query > SQLCMD Mode) <<<
   >>> Connect to the LISTENER SFDBSLISTN01 (lands on the primary) <<<

   Set KitPath to the folder where you unzipped the kit's sql folder.
   Safe to re-run: tables/config are created only if missing, procs are
   CREATE OR ALTER.
   ===================================================================== */
:setvar KitPath    "C:\billingdashboard\sql"
:setvar SvcAccount "CALSB\svc_billingdashboard"
:on error exit

PRINT '== 01 schema ==';                 :r $(KitPath)\01_schema.sql
PRINT '== 02 collector proc ==';         :r $(KitPath)\02_collect_proc.sql
PRINT '== 03 dashboard JSON proc ==';    :r $(KitPath)\03_dashboard_json_proc.sql
PRINT '== 04 GEORGE config ==';          :r $(KitPath)\04_config_george.sql

/* ---- service account access to Billing_V2 -------------------------- */
USE master;
GO
IF SUSER_ID(N'$(SvcAccount)') IS NULL
    CREATE LOGIN [$(SvcAccount)] FROM WINDOWS WITH DEFAULT_DATABASE = [Billing_V2];
GO
USE Billing_V2;
GO
IF DATABASE_PRINCIPAL_ID(N'$(SvcAccount)') IS NULL
    CREATE USER [$(SvcAccount)] FOR LOGIN [$(SvcAccount)];
ALTER ROLE billingdashboard_reader ADD MEMBER [$(SvcAccount)];
GO

/* ---- what got installed -------------------------------------------- */
SELECT o.type_desc, s.name + N'.' + o.name AS object_name
FROM sys.objects o JOIN sys.schemas s ON s.schema_id = o.schema_id
WHERE s.name = N'billingdashboard' AND o.type IN ('U','P','FN')
ORDER BY o.type_desc, o.name;
PRINT '== Done. Next: the login [$(SvcAccount)] must also be created on the other 3 nodes (see runbook step 6). ==';
