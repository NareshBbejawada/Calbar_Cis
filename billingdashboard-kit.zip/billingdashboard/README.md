# billingdashboard

Live dashboard for the State Bar Jan–Feb online fee billing cycle.
Full step-by-step instructions: the **billingdashboard: Deployment Runbook** document.

## Kit layout

| Path | What it is | Where it goes |
|---|---|---|
| `sql/00a_discover_george.sql` | Discovery: GEORGE table columns (done 2026-11-13) | Run once, any node |
| `sql/00b_discover_billing_v2.sql` | Discovery round 2: Billing_V2 payment tables | Run once, listener |
| `sql/install_billingdashboard.sql` | Installs 01–04 + service account access, one run (SQLCMD mode) | Listener SFDBSLISTN01 |
| `sql/01_schema.sql` … `04_config_george.sql` | Called by the installer | (no need to run separately) |
| `sql/05_agent_job.sql` | Credential, proxy, job, schedule (SQLCMD mode) | Each of the 4 AG nodes |
| `scripts/Export-billingdashboard.ps1` | Writes data.json | `D:\DBA\billingdashboard\` on each AG node |
| `web/index.html`, `web/web.config` | The dashboard page + IIS settings | `D:\inetpub\billingdashboard\` on AZDBAPRD01 |

## Names

| Item | Name |
|---|---|
| Service account | `CALSB\svc_billingdashboard` |
| Viewer groups | `CALSB\billingdashboard-IT`, `CALSB\billingdashboard-Management` |
| SQL schema / role | `Billing_V2.billingdashboard` / `billingdashboard_reader` |
| Agent credential / proxy | `billingdashboard_cred` / `billingdashboard_proxy` |
| Agent job / schedule | `billingdashboard - Collect` / `billingdashboard - every 2 min` |
| Web server / folder / share | `AZDBAPRD01` /  `D:\inetpub\billingdashboard` / `billingdashboard$` |
| IIS app pool / application | `billingdashboard` / `/billingdashboard` |
| Dashboard URL | `http://azdbaprd01/billingdashboard/` |
